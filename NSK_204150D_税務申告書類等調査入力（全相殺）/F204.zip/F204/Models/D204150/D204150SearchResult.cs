﻿using System.Data;
using System.Text;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using NskAppModelLibrary.Context;
using NskAppModelLibrary.Models;
using NskWeb.Areas.F204.Models.D204130;
using NskWeb.Common.Models;

namespace NskWeb.Areas.F204.Models.D204150
{
    // 検索結果の全体（ページングやソート、一覧など）を扱うクラス。
    public class D204150SearchResult : BasePager<D204150ResultRecord>
    {
        /// <summary>
        /// メッセージエリア２
        /// </summary>
        public string MessageArea2 { get; set; } = string.Empty;

        /// <summary>
        /// 類区分
        /// </summary>
        public List<List<SelectListItem>> RuiKbnSelectLists { get; set; } = new();

        /// <summary>
        /// 用途区分ドロップダウンリスト（行数分）
        /// </summary>
        public List<List<SelectListItem>> YoutoKbnSelectLists { get; set; } = new();

        public D204150SearchCondition SearchCondition { get; set; } = new();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D204150SearchResult()
        {
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="searchCondition">検索条件</param>
        public D204150SearchResult(D204150SearchCondition searchCondition)
        {
            SearchCondition = searchCondition;
        }

        /// <summary>
        /// 指定した位置に空白行を挿入する（共済目的コードに応じた初期化あり）
        /// </summary>
        /// <param name="insertIndex">挿入位置</param>
        public int AddPageData(int insertIndex)
        {
            var newRow = new D204150ResultRecord
            {
                IsNewRec = true,
                CheckSelect = false,
                KumiaiintoCd = string.Empty,
                FullNm = string.Empty,
                RuiKbn = string.Empty,
                YoutoKbn = string.Empty,
                HoshoWariai = string.Empty,
            };

            string mokutekiCd = SearchCondition.KyosaiMokutekiCd;
            switch (mokutekiCd)
            {
                case "11": // 水稲
                    // 全項目使用のため、初期値のままでOK
                    break;
                case "20": // 陸稲
                    newRow.RuiKbn = null;
                    newRow.YoutoKbn = null;
                    break;
                case "30": // 麦
                    newRow.KijyunSyukakuryo = null;
                    break;
                default:
                    // 想定外コードでも全項目を保持（初期値）
                    Console.WriteLine($"[警告] 想定外の共済目的コード: {mokutekiCd}");
                    break;
            }

            if (insertIndex >= 0 && insertIndex <= DispRecords.Count)
            {
                // index以降の要素の順番が一つ後ろにスライドされる
                DispRecords.Insert(insertIndex, newRow);
            }
            else
            {
                DispRecords.Add(newRow);
            }

            // 修正後（表示用件数をベースにPager構築）
            int displayCount = DispRecords.Count(x => !x.IsDelRec);
            int pageId = Pager.CurrentPage == 0 ? 1 : Pager.CurrentPage;

            Pager = displayCount == 0
                ? new()
                : new(pageId, DisplayCount, displayCount);

            return DispRecords.IndexOf(newRow);
        }

        /// <summary>
        /// 検索結果を取得する。
        /// </summary>
        /// <param name="dbContext">DBコンテキスト</param>
        /// <param name="session">セッション情報</param>
        public override List<D204150ResultRecord> GetResult(NskAppContext dbContext, BaseSessionInfo session)
        {
            // セッション情報の取得（型キャスト）
            D204150SessionInfo sessionInfo = (D204150SessionInfo)session;
            List<D204150ResultRecord> records = new();

            // SQL組み立て用
            StringBuilder query = new();

            // クエリパラメータの準備
            List<NpgsqlParameter> queryParams = new()
            {
                new("組合等コード", sessionInfo.KumiaitoCd),
                new("年産", sessionInfo.Nensan),
                new("共済目的コード", sessionInfo.KyosaiMokutekiCd),
                new("都道府県コード", sessionInfo.TodofukenCd)
            };

            # region SELECT句（画面に必要なカラムを選択）
            query.AppendLine("SELECT");
            query.AppendLine("  t_21130.組合等コード AS \"KumiaitoCd\",");
            query.AppendLine("  t_21130.年産 AS \"Nensan\",");
            query.AppendLine("  t_21130.共済目的コード AS \"KyosaiMokutekiCd\",");
            query.AppendLine("  t_21130.組合員等コード AS \"KumiaiintoCd\",");
            query.AppendLine("  nogyosha.hojin_full_nm AS \"FullNm\",");
            query.AppendLine("  m_20030.補償割合短縮名称 AS \"HoshoWariai\",");
            query.AppendLine("  t_21130.収穫量 AS \"HonnenSyukakuryo\",");
            query.AppendLine("  t_21130.売上数量 AS \"UriageSuryo\",");
            query.AppendLine("  t_21130.類区分 AS \"RuiKbn\",");
            query.AppendLine("  t_21130.用途区分 AS \"YoutoKbn\",");
            query.AppendLine("  m_00020.類短縮名称 AS \"RuiTanshukuNm\",");
            query.AppendLine("  m_10110.用途短縮名称 AS \"YoutoTanshukuNm\",");
            query.AppendLine("  t_21130.事業消費数量 AS \"JigyoShohiSuryo\",");
            query.AppendLine("  t_21130.廃棄亡失数量 AS \"HaikiSuryo\",");
            query.AppendLine("  t_21130.期末棚卸数量 AS \"KimatsuSyukakuryo\",");
            query.AppendLine("  t_21130.期首棚卸数量 AS \"KishuSyukakuryo\",");
            query.AppendLine("  t_12040.基準収穫量計 AS \"KijyunSyukakuryo\",");
            //query.AppendLine("  999::numeric AS \"KijyunSyukakuryo\",");
            query.AppendLine("  (t_21130.xmin::text)::bigint AS \"Xmin\"");
            #endregion

            #region FROM句（結合テーブル）
            query.AppendLine("FROM nouho_nsk_03.t_21130_税務申告全数調査 t_21130");
            query.AppendLine("INNER JOIN nouho_nsk_03.t_12040_組合員等別引受情報 t_12040");
            query.AppendLine("  ON t_12040.組合等コード = t_21130.組合等コード");
            query.AppendLine("  AND t_12040.年産 = t_21130.年産");
            query.AppendLine("  AND t_12040.共済目的コード = t_21130.共済目的コード");
            query.AppendLine("  AND t_12040.類区分 = t_21130.類区分");
            query.AppendLine("  AND t_12040.組合員等コード = t_21130.組合員等コード");
            query.AppendLine("INNER JOIN nouho_nsk_03.v_nogyosha nogyosha");
            query.AppendLine("  ON nogyosha.kumiaito_cd = t_21130.組合等コード");
            query.AppendLine("  AND nogyosha.kumiaiinto_cd = t_21130.組合員等コード");
            query.AppendLine("INNER JOIN nouho_nsk_03.m_20030_補償割合名称 m_20030");
            query.AppendLine("  ON t_12040.補償割合コード = m_20030.補償割合コード");
            query.AppendLine("INNER JOIN nouho_nsk_03.m_00020_類名称 m_00020");
            query.AppendLine("  ON m_00020.共済目的コード = t_12040.共済目的コード");
            query.AppendLine("  AND m_00020.類区分 = t_12040.類区分");
            query.AppendLine("INNER JOIN nouho_nsk_03.m_10110_用途区分名称 m_10110");
            query.AppendLine("  ON m_10110.共済目的コード = t_21130.共済目的コード");
            query.AppendLine("  AND m_10110.用途区分 = t_21130.用途区分");
            #endregion

            #region WHERE句（絞り込み条件）
            query.AppendLine("WHERE t_21130.組合等コード = @組合等コード");
            query.AppendLine("  AND t_21130.年産 = @年産");
            query.AppendLine("  AND t_21130.共済目的コード = @共済目的コード");

            // ※「画面：支所」の入力がある場合
            if (!string.IsNullOrEmpty(SearchCondition.TodofukenDropDownList.ShishoCd))
            {
                query.AppendLine("  AND t_12040.支所コード = @支所");
                queryParams.Add(new("支所", SearchCondition.TodofukenDropDownList.ShishoCd));
            }

            query.AppendLine("  AND t_12040.引受回 = (");
            query.AppendLine("    SELECT MAX(t_00010.引受回)");
            query.AppendLine("    FROM nouho_nsk_03.t_00010_引受回 t_00010");
            query.AppendLine("    INNER JOIN nouho_nsk_03.t_21130_税務申告全数調査 t_21130");
            query.AppendLine("      ON t_00010.組合等コード = t_21130.組合等コード");
            query.AppendLine("      AND t_00010.共済目的コード = t_21130.共済目的コード");
            query.AppendLine("      AND t_00010.年産 = t_21130.年産");
            query.AppendLine("    INNER JOIN nouho_nsk_03.v_nogyosha nogyosha");
            query.AppendLine("      ON nogyosha.kumiaito_cd = '" + sessionInfo.KumiaitoCd + "'");
            query.AppendLine("      AND nogyosha.kumiaiinto_cd = t_21130.組合員等コード");
            query.AppendLine("    WHERE nogyosha.shisho_cd = t_00010.支所コード");
            query.AppendLine("  )");
            query.AppendLine("  AND t_12040.引受方式 = '3'");
            query.AppendLine("  AND t_12040.統計単位地域コード = '0'");
            query.AppendLine("  AND t_12040.引受対象フラグ = '1'");

            // ※「画面：組合員等コード（開始）」のみ入力がある場合
            if (!string.IsNullOrEmpty(SearchCondition.KumiaiinToCdFrom) &&
                string.IsNullOrEmpty(SearchCondition.KumiaiinToCdTo))
            {
                query.AppendLine("  AND t_21130.組合員等コード = @組合員等コードFrom");
                queryParams.Add(new("組合員等コードFrom", SearchCondition.KumiaiinToCdFrom));
            }
            // ※「画面：組合員等コード（終了）」のみ入力がある場合
            else if (string.IsNullOrEmpty(SearchCondition.KumiaiinToCdFrom) &&
                     !string.IsNullOrEmpty(SearchCondition.KumiaiinToCdTo))
            {
                query.AppendLine("  AND t_21130.組合員等コード = @組合員等コードTo");
                queryParams.Add(new("組合員等コードTo", SearchCondition.KumiaiinToCdTo));
            }
            // ※「画面：組合員等コード（開始／終了）」の両方ある場合
            else if (!string.IsNullOrEmpty(SearchCondition.KumiaiinToCdFrom) &&
                     !string.IsNullOrEmpty(SearchCondition.KumiaiinToCdTo))
            {
                query.AppendLine("  AND (t_21130.組合員等コード >= @組合員等コードFrom");
                query.AppendLine("       AND t_21130.組合員等コード <= @組合員等コードTo)");
                queryParams.Add(new("組合員等コードFrom", SearchCondition.KumiaiinToCdFrom));
                queryParams.Add(new("組合員等コードTo", SearchCondition.KumiaiinToCdTo));
            }

            // ※「画面：大地区」の入力がある場合
            if (!string.IsNullOrEmpty(SearchCondition.TodofukenDropDownList.DaichikuCd))
            {
                query.AppendLine("  AND nogyosha.daichiku_cd = @大地区");
                queryParams.Add(new("大地区", SearchCondition.TodofukenDropDownList.DaichikuCd));
            }

            // ※「画面：小地区（開始）」のみ入力がある場合
            if (!string.IsNullOrEmpty(SearchCondition.TodofukenDropDownList.ShochikuCdFrom) &&
                string.IsNullOrEmpty(SearchCondition.TodofukenDropDownList.ShochikuCdTo))
            {
                query.AppendLine("  AND nogyosha.shochiku_cd = @小地区From");
                queryParams.Add(new("小地区From", SearchCondition.TodofukenDropDownList.ShochikuCdFrom));
            }
            // ※「画面：小地区（終了）」のみ入力がある場合
            else if (string.IsNullOrEmpty(SearchCondition.TodofukenDropDownList.ShochikuCdFrom) &&
                     !string.IsNullOrEmpty(SearchCondition.TodofukenDropDownList.ShochikuCdTo))
            {
                query.AppendLine("  AND nogyosha.shochiku_cd = @小地区To");
                queryParams.Add(new("小地区To", SearchCondition.TodofukenDropDownList.ShochikuCdTo));
            }
            // ※「画面：小地区（開始／終了）」の両方ある場合
            else if (!string.IsNullOrEmpty(SearchCondition.TodofukenDropDownList.ShochikuCdFrom) &&
                     !string.IsNullOrEmpty(SearchCondition.TodofukenDropDownList.ShochikuCdTo))
            {
                query.AppendLine("  AND (nogyosha.shochiku_cd >= @小地区From");
                query.AppendLine("       AND nogyosha.shochiku_cd <= @小地区To)");
                queryParams.Add(new("小地区From", SearchCondition.TodofukenDropDownList.ShochikuCdFrom));
                queryParams.Add(new("小地区To", SearchCondition.TodofukenDropDownList.ShochikuCdTo));
            }
            // ※「画面：類区分」の入力がある場合
            if (!string.IsNullOrEmpty(SearchCondition.RuiKbn))
            {
                query.AppendLine("  AND t_21130.類区分 = @類区分");
                queryParams.Add(new NpgsqlParameter("類区分", SearchCondition.RuiKbn));
            }
            // ※「画面：用途区分」の入力がある場合
            if (!string.IsNullOrEmpty(SearchCondition.YoutoKbn))
            {
                query.AppendLine("  AND t_21130.用途区分 = @用途区分");
                queryParams.Add(new NpgsqlParameter("用途区分", SearchCondition.YoutoKbn));
            }
            #endregion

            #region ソート条件
            query.Append(" ORDER BY ");

            bool ruikbnSort = false;
            bool youtoSort = false;
            bool shisyoSort = false;
            bool daichikuSort = false;
            bool shochikuSort = false;
            bool kumiaiintoSort = false;
            bool isPutOrder = false;

            // ※「画面：表示順キー１」「画面：表示順キー２」「画面：表示順キー３」のいずれかが選択されている場合
            if (SearchCondition.DisplaySort1.HasValue || SearchCondition.DisplaySort2.HasValue || SearchCondition.DisplaySort3.HasValue)
            {
                if (SearchCondition.DisplaySort1.HasValue)
                {
                    isPutOrder = true;
                    switch (SearchCondition.DisplaySort1)
                    {
                        case D204150SearchCondition.DisplaySortType.Ruikbn:
                            query.Append($" t_21130.類区分 {SearchCondition.DisplaySortOrder1} ");
                            ruikbnSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.YoutoKbn:
                            query.Append($" t_21130.用途区分 {SearchCondition.DisplaySortOrder1} ");
                            youtoSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Shisyo:
                            query.Append($" nogyosha.shisho_cd {SearchCondition.DisplaySortOrder1} ");
                            shisyoSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Daichiku:
                            query.Append($" nogyosha.daichiku_cd {SearchCondition.DisplaySortOrder1} ");
                            daichikuSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Shochiku:
                            query.Append($" nogyosha.shochiku_cd {SearchCondition.DisplaySortOrder1} ");
                            shochikuSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.KumiaiintoCd:
                            query.Append($" LPAD(t_21130.組合員等コード, 13, '0') {SearchCondition.DisplaySortOrder1} ");
                            kumiaiintoSort = true;
                            break;
                    }
                }
                if (SearchCondition.DisplaySort2.HasValue)
                {
                    if (isPutOrder)
                    {
                        // ソート条件1が出力されていた場合、カンマを付与する
                        query.Append(", ");
                    }
                    isPutOrder = true;
                    switch (SearchCondition.DisplaySort2)
                    {
                        case D204150SearchCondition.DisplaySortType.Ruikbn:
                            query.Append($" t_21130.類区分 {SearchCondition.DisplaySortOrder2} ");
                            ruikbnSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.YoutoKbn:
                            query.Append($" t_21130.用途区分 {SearchCondition.DisplaySortOrder2} ");
                            youtoSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Shisyo:
                            query.Append($" nogyosha.shisho_cd {SearchCondition.DisplaySortOrder2} ");
                            shisyoSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Daichiku:
                            query.Append($" nogyosha.daichiku_cd {SearchCondition.DisplaySortOrder2} ");
                            daichikuSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Shochiku:
                            query.Append($" nogyosha.shochiku_cd {SearchCondition.DisplaySortOrder2} ");
                            shochikuSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.KumiaiintoCd:
                            query.Append($" LPAD(t_21130.組合員等コード, 13, '0') {SearchCondition.DisplaySortOrder2} ");
                            kumiaiintoSort = true;
                            break;
                    }
                }
                if (SearchCondition.DisplaySort3.HasValue)
                {
                    if (isPutOrder)
                    {
                        // ソート条件1or2が出力されていた場合、カンマを付与する
                        query.Append(", ");
                    }
                    isPutOrder = true;
                    switch (SearchCondition.DisplaySort3)
                    {
                        case D204150SearchCondition.DisplaySortType.Ruikbn:
                            query.Append($" t_21130.類区分 {SearchCondition.DisplaySortOrder3} ");
                            ruikbnSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.YoutoKbn:
                            query.Append($" t_21130.用途区分 {SearchCondition.DisplaySortOrder3} ");
                            youtoSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Shisyo:
                            query.Append($" nogyosha.shisho_cd {SearchCondition.DisplaySortOrder3} ");
                            shisyoSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Daichiku:
                            query.Append($" nogyosha.daichiku_cd {SearchCondition.DisplaySortOrder3} ");
                            daichikuSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.Shochiku:
                            query.Append($" nogyosha.shochiku_cd {SearchCondition.DisplaySortOrder3} ");
                            shochikuSort = true;
                            break;
                        case D204150SearchCondition.DisplaySortType.KumiaiintoCd:
                            query.Append($" LPAD(t_21130.組合員等コード, 13, '0') {SearchCondition.DisplaySortOrder3} ");
                            kumiaiintoSort = true;
                            break;
                    }
                }
            }

            // 「画面：表示順キー」で類区分の指定がない場合
            if (!ruikbnSort)
            {
                if (isPutOrder)
                {
                    // ソート条件1or2or3が出力されていた場合、カンマを付与する
                    query.Append(", ");
                }
                query.Append(" t_21130.類区分 Asc ");
            }
            // 「画面：表示順キー」で用途区分の指定がない場合
            if (!youtoSort)
            {
                query.Append(", ");
                query.Append(" t_21130.用途区分 Asc ");
            }
            // 「画面：表示順キー」で支所の指定がない場合
            if (!shisyoSort)
            {
                query.Append(", ");
                query.Append(" nogyosha.shisho_cd Asc ");
            }
            // 「画面：表示順キー」で大地区の指定がない場合
            if (!daichikuSort)
            {
                query.Append(", ");
                query.Append(" nogyosha.daichiku_cd Asc ");
            }
            // 「画面：表示順キー」で小地区の指定がない場合
            if (!shochikuSort)
            {
                query.Append(", ");
                query.Append(" nogyosha.shochiku_cd Asc ");
            }
            // 「画面：表示順キー」で組合員等コードの指定がない場合
            if (!kumiaiintoSort)
            {
                query.Append(", ");
                query.Append(" LPAD(t_21130.組合員等コード, 13, '0') Asc ");
            }
            #endregion

            Console.WriteLine("==== 実行SQL ====");
            Console.WriteLine(query.ToString());
            foreach (var p in queryParams)
            {
                Console.WriteLine($"パラメータ: {p.ParameterName} = {p.Value}");
            }

            var resultList = dbContext.Database.SqlQueryRaw<D204150ResultRecord>(query.ToString(), queryParams.ToArray()).ToList();

            Console.WriteLine($"★★ SQL実行結果件数：{resultList.Count}");

            records.AddRange(resultList);

            return records;
        }

        /// <summary>
        /// 画面入力値をこのこのクラスに反映する
        /// </summary>
        /// <param name="src"></param>
        public void ApplyInput(D204150SearchResult src)
        {
            this.DisplayCount = src.DisplayCount;
            this.AllRecCount = src.AllRecCount;
            this.DispRecords = src.DispRecords;
        }

        /// <summary>
        /// t_21130_税務申告全数調査の対象レコードを削除する。
        /// </summary>
        /// <param name="dbContext"></param>
        /// <param name="sessionInfo"></param>
        /// <param name="delRecords"></param>
        /// <returns></returns>
        public int DeleteShinkoku(ref NskAppContext dbContext, D204150SessionInfo sessionInfo, ref List<D204150ResultRecord> delRecords)
        {
            int delCount = 0;

            // t_21130_税務申告全数調査の対象レコードを削除する。
            StringBuilder delShinkoku = new();
            delShinkoku.Append("DELETE FROM nouho_nsk_03.t_21130_税務申告全数調査 ");
            delShinkoku.Append("WHERE ");
            delShinkoku.Append("     組合等コード       = @組合等コード ");
            delShinkoku.Append(" AND 年産               = @年産 ");
            delShinkoku.Append(" AND 共済目的コード     = @共済目的コード ");
            delShinkoku.Append(" AND 組合員等コード     = @組合員等コード ");
            delShinkoku.Append(" AND 類区分             = @類区分 ");
            delShinkoku.Append(" AND 用途区分           = @用途区分 ");
            delShinkoku.Append(" AND xmin               = @xmin ");

            foreach (D204150ResultRecord target in delRecords)
            {
                if (!target.Xmin.HasValue)
                {
                    // xmin nullは処理対象外
                    continue;
                }

                // 水稲・陸稲時の補完
                FillDefaultRuiYoutoKbn(target, sessionInfo.KyosaiMokutekiCd);

                List<NpgsqlParameter> delParams =
                [
                    new NpgsqlParameter("組合等コード", sessionInfo.KumiaitoCd),
                    new NpgsqlParameter("年産", sessionInfo.Nensan),
                    new NpgsqlParameter("共済目的コード", sessionInfo.KyosaiMokutekiCd),
                    new NpgsqlParameter("組合員等コード", target.KumiaiintoCd),
                    new NpgsqlParameter("類区分", target.RuiKbn),
                    new NpgsqlParameter("用途区分", target.YoutoKbn)
                ];
                NpgsqlParameter xminParam = new("xmin", NpgsqlTypes.NpgsqlDbType.Xid) { Value = target.Xmin.Value };
                delParams.Add(xminParam);

                int cnt = dbContext.Database.ExecuteSqlRaw(delShinkoku.ToString(), delParams);
                if (cnt == 0)
                {
                    string message = "ME10083";
                    throw new DBConcurrencyException(message);
                }

                delCount += cnt;
            }

            return delCount;
        }

        /// <summary>
        /// 削除対象レコード取得
        /// </summary>
        /// <returns></returns>
        public List<D204150ResultRecord> GetDeleteRecs()
        {
            List<D204150ResultRecord> delRecs = new();
            foreach (var rec in DispRecords)
            {
                if (rec.IsDelRec && !rec.IsNewRec)
                {
                    delRecs.Add(rec);
                }
            }
            return delRecs;
        }

        /// <summary>
        /// t_21130_税務申告全数調査 の対象レコードを更新する。
        /// </summary>
        public int UpdateShinkoku(
            ref NskAppContext dbContext,
            D204150SessionInfo sessionInfo,
            string userId,
            DateTime sysDateTime,
            ref List<D204150ResultRecord> updRecords)
        {
            int updCount = 0;

            // t_21130_税務申告全数調査 の対象レコードを更新する
            StringBuilder sql = new();
            sql.AppendLine("UPDATE nouho_nsk_03.t_21130_税務申告全数調査 SET");
            sql.AppendLine("  事業消費数量   = @事業消費数量");
            sql.AppendLine(", 廃棄亡失数量   = @廃棄亡失数量");
            sql.AppendLine(", 期末棚卸数量   = @期末棚卸数量");
            sql.AppendLine(", 売上数量       = @売上数量");
            sql.AppendLine(", 期首棚卸数量   = @期首棚卸数量");
            sql.AppendLine(", 更新日時       = @更新日時");
            sql.AppendLine(", 更新ユーザid   = @更新ユーザid");
            sql.AppendLine("WHERE 組合等コード     = @組合等コード");
            sql.AppendLine("  AND 年産             = @年産");
            sql.AppendLine("  AND 共済目的コード   = @共済目的コード");
            sql.AppendLine("  AND 組合員等コード   = @組合員等コード");
            sql.AppendLine("  AND 類区分           = @類区分");
            sql.AppendLine("  AND 用途区分         = @用途区分");
            sql.AppendLine("  AND xmin             = @xmin");

            foreach (var target in updRecords)
            {
                if (!target.Xmin.HasValue) continue;

                // 水稲・陸稲時の補完
                FillDefaultRuiYoutoKbn(target, sessionInfo.KyosaiMokutekiCd);

                var parameters = new List<NpgsqlParameter>
        {
            new("組合等コード", sessionInfo.KumiaitoCd),
            new("年産", sessionInfo.Nensan),
            new("共済目的コード", sessionInfo.KyosaiMokutekiCd),
            new("組合員等コード", target.KumiaiintoCd),
            new("類区分", target.RuiKbn),
            new("用途区分", target.YoutoKbn),
            new("事業消費数量", target.JigyoShohiSuryo ?? (object)DBNull.Value),
            new("廃棄亡失数量", target.HaikiSuryo ?? (object)DBNull.Value),
            new("期末棚卸数量", target.KimatsuSyukakuryo ?? (object)DBNull.Value),
            new("売上数量", target.UriageSuryo ?? (object)DBNull.Value),
            new("期首棚卸数量", target.KishuSyukakuryo ?? (object)DBNull.Value),
            new("更新日時", sysDateTime),
            new("更新ユーザid", userId),
            new("xmin", NpgsqlTypes.NpgsqlDbType.Xid) { Value = target.Xmin.Value }
        };

                int cnt = dbContext.Database.ExecuteSqlRaw(sql.ToString(), parameters);
                if (cnt == 0)
                {
                    throw new DBConcurrencyException("ME10082"); // 排他エラー
                }

                updCount += cnt;
            }

            return updCount;
        }


        /// <summary>
        /// t_21130_税務申告全数調査 の対象レコードを登録する。
        /// </summary>
        /// <param name="dbContext">DBコンテキスト</param>
        /// <param name="sessionInfo">セッション情報</param>
        /// <param name="userId">登録ユーザID</param>
        /// <param name="sysDateTime">登録日時</param>
        /// <param name="addRecords">登録対象レコード</param>
        /// <returns>登録件数</returns>
        public int AppendShinkoku(
            ref NskAppContext dbContext,
            D204150SessionInfo sessionInfo,
            string userId,
            DateTime sysDateTime,
            ref List<D204150ResultRecord> addRecords)
        {
            int insCount = 0;

            // 登録用リストを作成
            List<T21130税務申告全数調査> newEntities = new();

            foreach (var record in addRecords)
            {
                // ★ 新規追加フラグが立っているものだけ対象とする
                if (!record.IsNewRec)
                    continue;

                // ★水稲・陸稲時の補完
                FillDefaultRuiYoutoKbn(record, sessionInfo.KyosaiMokutekiCd);

                // ★ 必須項目チェック
                if (string.IsNullOrWhiteSpace(record.KumiaiintoCd) ||
                    string.IsNullOrWhiteSpace(record.RuiKbn) ||
                    string.IsNullOrWhiteSpace(record.YoutoKbn))
                    continue;

                newEntities.Add(new T21130税務申告全数調査
                {
                    組合等コード = sessionInfo.KumiaitoCd,
                    年産 = (short)sessionInfo.Nensan,
                    共済目的コード = sessionInfo.KyosaiMokutekiCd,
                    類区分 = record.RuiKbn,
                    組合員等コード = record.KumiaiintoCd,
                    用途区分 = record.YoutoKbn,
                    事業消費数量 = record.JigyoShohiSuryo,
                    廃棄亡失数量 = record.HaikiSuryo,
                    期末棚卸数量 = record.KimatsuSyukakuryo,
                    売上数量 = record.UriageSuryo,
                    期首棚卸数量 = record.KishuSyukakuryo,
                    登録日時 = sysDateTime,
                    登録ユーザid = userId,
                    更新日時 = sysDateTime,
                    更新ユーザid = userId
                });
            }

            // DBへ反映
            if (newEntities.Any())
            {
                dbContext.T21130税務申告全数調査s.AddRange(newEntities);
                insCount = dbContext.SaveChanges();
            }

            return insCount;
        }




        /// <summary>
        /// 更新対象レコード取得
        /// </summary>
        /// <param name="dbContext"></param>
        /// <param name="session"></param>
        /// <returns></returns>
        public override List<D204150ResultRecord> GetUpdateRecs(ref NskAppContext dbContext, BaseSessionInfo session)
        {
            D204150SessionInfo sessionInfo = (D204150SessionInfo)session;

            List<D204150ResultRecord> updRecs = new();

            Console.WriteLine("★★★ GetUpdateRecs 開始 ★★★");

            // 検索結果取得
            List<D204150ResultRecord> dbResults = GetResult(dbContext, sessionInfo);
            Console.WriteLine($"DB結果件数: {dbResults.Count}");

            // 検索結果と画面入力値を比較
            foreach (D204150ResultRecord dispRec in DispRecords)
            {
                // 追加行、削除行以外を対象とする
                if (dispRec is BasePagerRecord pagerRec && !pagerRec.IsNewRec && !pagerRec.IsDelRec)
                {
                    // ★共済目的コードに応じて類区分・用途区分を補完
                    FillDefaultRuiYoutoKbn(dispRec, sessionInfo.KyosaiMokutekiCd);

                    D204150ResultRecord dbRec = dbResults.FirstOrDefault(x =>
                    x.KumiaiintoCd == dispRec.KumiaiintoCd &&
                    x.RuiKbn == dispRec.RuiKbn &&
                    x.YoutoKbn == dispRec.YoutoKbn &&
                    sessionInfo.KumiaitoCd == x.KumiaitoCd &&  // 組合等コード
                    sessionInfo.Nensan == x.Nensan &&          // 年産
                    sessionInfo.KyosaiMokutekiCd == x.KyosaiMokutekiCd
                );
                    // DB検索結果と比較し差分ありの場合、更新対象とする
                    if ((dbRec is not null) && !dispRec.Compare(dbRec))
                    {
                        // 画面入力を更新対象として追加
                        updRecs.Add(dispRec);
                    }
                }
            }
            Console.WriteLine("★★★ GetUpdateRecs 終了 ★★★");

            return updRecs;
        }

        /// <summary>
        /// 類区分ドロップダウンの再構築
        /// </summary>
        public void RebuildRuiKbnSelectLists(List<SelectListItem> sourceList)
        {
            RuiKbnSelectLists.Clear();
            foreach (var rec in DispRecords)
            {
                RuiKbnSelectLists.Add(sourceList);
            }
            // 足りない場合の補正（念のため）
            while (RuiKbnSelectLists.Count < DispRecords.Count)
            {
                RuiKbnSelectLists.Add(sourceList);
            }
        }

        /// <summary>
        /// 用途区分ドロップダウンの再構築
        /// </summary>
        public void RebuildYoutoKbnSelectLists(List<SelectListItem> sourceList)
        {
            YoutoKbnSelectLists.Clear();
            foreach (var rec in DispRecords)
            {
                if (string.IsNullOrEmpty(rec.RuiKbn))
                {
                    // 類区分が未選択 → 空リストを設定
                    YoutoKbnSelectLists.Add(new List<SelectListItem>());
                }
                else
                {
                    // 類区分が選択されていれば元データを設定
                    YoutoKbnSelectLists.Add(sourceList);
                }
            }

            // 念のため数を補正（異常時対策）
            while (YoutoKbnSelectLists.Count < DispRecords.Count)
            {
                YoutoKbnSelectLists.Add(new List<SelectListItem>());
            }
        }

        /// <summary>
        /// CheckSelect反映とドロップダウン再構築を同時に行う共通処理
        /// </summary>
        /// <param name="postRecs">画面からPOSTされた一覧</param>
        /// <param name="condition">ドロップダウンの元データを含む検索条件</param>
        public void ApplyInputAndRebuild(List<D204150ResultRecord> postRecs, D204150SearchCondition condition)
        {
            ApplyInput(new D204150SearchResult
            {
                DispRecords = postRecs,
                AllRecCount = postRecs.Count(x => !x.IsDelRec)  // ← 追加
            });

            RebuildAllDropDowns(condition);
        }

        /// <summary>
        /// 各行に Index を振り直す
        /// </summary>
        public void Reindex()
        {
            for (int i = 0; i < DispRecords.Count; i++)
            {
                DispRecords[i].Index = i;
            }
        }

        /// <summary>
        /// すべてのドロップダウンを一括で再構築する（D105190方式）
        /// </summary>
        /// <param name="condition">検索条件（ドロップダウンの元データ含む）</param>
        public void RebuildAllDropDowns(D204150SearchCondition condition)
        {
            // 類区分ドロップダウン再構築
            RebuildRuiKbnSelectLists(condition.RuiKbnLists);

            // 用途区分ドロップダウンがあれば再構築（麦の場合のみ）
            if (condition.YoutoKbnLists != null && condition.YoutoKbnLists.Any())
            {
                RebuildYoutoKbnSelectLists(condition.YoutoKbnLists);
            }

            Console.WriteLine($"[Check] DispRecords.Count = {DispRecords.Count}");
            Console.WriteLine($"[Check] RuiKbnSelectLists.Count = {RuiKbnSelectLists.Count}");
            Console.WriteLine($"[Check] YoutoKbnSelectLists.Count = {YoutoKbnSelectLists.Count}");

        }

        /// <summary>
        /// 類区分・用途区分の補完処理（共済目的コードに応じて "0" を設定）
        /// ・水稲（11）：用途区分を "0" に補完
        /// ・陸稲（20）：類区分と用途区分の両方を "0" に補完
        /// ・麦（30）：補完なし（画面入力あり）
        /// </summary>
        /// <param name="record">対象のレコード（1行）</param>
        /// <param name="mokutekiCd">共済目的コード（11, 20, 30）</param>
        private void FillDefaultRuiYoutoKbn(D204150ResultRecord record, string mokutekiCd)
        {
            if (string.IsNullOrEmpty(record.RuiKbn) && mokutekiCd == "20")
            {
                record.RuiKbn = "0";
            }

            if (string.IsNullOrEmpty(record.YoutoKbn) &&
                (mokutekiCd == "11" || mokutekiCd == "20"))
            {
                record.YoutoKbn = "0";
            }
        }
    }
}