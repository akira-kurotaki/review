using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace NskWeb.Areas.F204.Models.D204150
{
    /// <summary>
    /// 引受データ取得結果DTO（Ajaxで返却する内容）
    /// </summary>
    public class D204150HikiukeResultDto
    {
        /// <summary>組合員等氏名</summary>
        public string KumiaiinNm { get; set; }

        /// <summary>補償割合</summary>
        public string HoshoWariai { get; set; } = string.Empty;

        /// <summary>事業消費数量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? JigyoShohiSuryo { get; set; }

        /// <summary>基準収穫量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? KijyunSyukakuryo { get; set; }

        /// <summary>廃棄・亡失数量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? HaikiSuryo { get; set; }

        /// <summary>本年収穫量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? HonnenSyukakuryo { get; set; }

        /// <summary>期末棚卸数量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? KimatsuSyukakuryo { get; set; }

        /// <summary>売渡数量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? UriageSuryo { get; set; }

        /// <summary>期首棚卸数量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? KishuSyukakuryo { get; set; }

        /// <summary>Xmin</summary>
        public uint? Xmin { get; set; }
    }
}
