﻿using CoreLibrary.Core.Base;
using ModelLibrary.Models;
using NskWeb.Areas.F000.Models.D000000;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace NskWeb.Areas.F204.Models.D204111
{
    [Serializable]
    public class D204111Model : CoreViewModel
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D204111Model()
        {
            this.VSyokuinRecords = new VSyokuin();
            this.D204111Info = new NSKPortalInfoModel();  // $$$$$$$$$$$$$$$$$$$
        }

        /// <summary>
        /// 職員マスタの検索結果
        /// </summary>
        public VSyokuin VSyokuinRecords { get; set; }
        public NSKPortalInfoModel D204111Info { get; set; }

        [DisplayName("メッセージエリア")]
        public string MessageArea { get; set; }

        /// <summary>
        /// 年産
        /// </summary>
        [DisplayName("年産")]
        public string Nensan { get; set; }
        /// <summary>
        /// 共済目的名称
        /// </summary>
        [DisplayName("共済目的名称")]
        public string KyosaiMokutekiMeisho { get; set; }
        /// <summary>
        /// 共済目的コード
        /// </summary>
        [DisplayName("共済目的コード")]
        public string KyosaiMokutekiCd { get; set; }
        /// <summary>
        /// 組合員等コード
        /// </summary>
        [DisplayName("組合員等コード")]
        public string KumiaiintoCd { get; set; }
        /// <summary>
        /// 組合等コード
        /// </summary>
        [DisplayName("組合等コード")]
        public string KumiaitoCd { get; set; }
        /// <summary>
        /// 氏名
        /// </summary>
        [DisplayName("氏名")]
        public string HojinFullNm { get; set; }
        /// <summary>
        /// 支所コード
        /// </summary>
        [DisplayName("支所コード")]
        public string ShishoCd { get; set; }
        /// <summary>
        /// 支所名
        /// </summary>
        [DisplayName("支所名")]
        public string ShishoNm { get; set; }
        /// <summary>
        /// 市町村コード
        /// </summary>
        [DisplayName("市町村コード")]
        public string ShichosonCd { get; set; }
        /// <summary>
        /// 市町村名
        /// </summary>
        [DisplayName("市町村名")]
        public string ShichosonNm { get; set; } = string.Empty;
        /// <summary>
        /// 大地区コード
        /// </summary>
        [DisplayName("大地区コード")]
        public string DaichikuCd { get; set; }
        /// <summary>
        /// 大地区名
        /// </summary>
        [DisplayName("大地区名")]
        public string DaichikuNm { get; set; } = string.Empty;
        /// <summary>
        /// 小地区コード
        /// </summary>
        [DisplayName("小地区コード")]
        public string ShochikuCd { get; set; }
        /// <summary>
        /// 小地区名
        /// </summary>
        [DisplayName("小地区名")]
        public string ShochikuNm { get; set; } = string.Empty;
        /// <summary>
        /// 類区分
        /// </summary>
        [DisplayName("類区分")]
        public string RuiKbn { get; set; }
        /// <summary>
        /// 類名称
        /// </summary>
        [DisplayName("類名称")]
        public string RuiNm { get; set; }
        /// <summary>
        /// 用途
        /// </summary>
        [Display(Name = "用途")]
        public string YotoCd { get; set; }
        /// <summary>
        /// 用途区分
        /// </summary>
        [Display(Name = "用途区分")]
        public string YotoKbn { get; set; } = string.Empty;
        /// <summary>
        /// 施設搬入収穫量結果
        /// </summary>
        [DisplayName("施設搬入収穫量結果")]
        [RegularExpression(@"^\d{1,7}$")]
        public string ShisetsuHannyuSyukakuryoKekka { get; set; }
        /// <summary>
        /// T21120.xmin
        /// </summary>
        [DisplayName("T21120xmin")]
        public uint Xmin { get; set; }
        /// <summary>
        /// 更新権限フラグ
        /// </summary>
        public bool UpdateKengenFlg { get; set; }
    }
}