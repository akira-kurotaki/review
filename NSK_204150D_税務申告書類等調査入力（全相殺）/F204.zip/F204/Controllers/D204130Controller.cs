﻿using System.Collections.Generic;
using System.Data;
using System.Text.RegularExpressions;
using CoreLibrary.Core.Attributes;
using CoreLibrary.Core.Base;
using CoreLibrary.Core.Consts;
using CoreLibrary.Core.Exceptions;
using CoreLibrary.Core.Extensions;
using CoreLibrary.Core.Utility;
using CoreLibrary.Core.Validator;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using ModelLibrary.Models;
using NskAppModelLibrary.Context;
using NskWeb.Areas.F204.Consts;
using NskWeb.Areas.F204.Models.D204130;
using NuGet.Protocol.Core.Types;

namespace NskWeb.Areas.F204.Controllers
{
    [AllowAnonymous]
    [ExcludeAuthCheck]
    [Area("F204")]
    public class D204130Controller : CoreController
    {
        /// <summary>
        /// セッションキー(D204130)
        /// </summary>
        private const string SESS_D204130 = $"{F204Const.SCREEN_ID_D204130}_SCREEN";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="viewEngine"></param>
        public D204130Controller(ICompositeViewEngine viewEngine) : base(viewEngine)
        {
        }

        // GET: F204/D204130
        public ActionResult Index()
        {
            if (ConfigUtil.Get(CoreConst.D0000_DISPLAY_FLAG) == "true")
            {
                // 画面表示モードを設定
                SetScreenModeFromQueryString();

            }

            return RedirectToAction("Init", F204Const.SCREEN_ID_D204130, new { area = "F204" });
        }

        /// <summary>
        /// 初期表示
        /// </summary>
        /// <returns>加入申込書入力（水稲）画面表示結果</returns>
        public ActionResult Init()
        {

            // １．ログインユーザの参照・更新可否判定
            D204130Model model = SessionUtil.Get<D204130Model>(SESS_D204130, HttpContext);

            if (model is not null)
            {
                // セッション検索条件 あり
                // 検索結果をセッションから削除
                SessionUtil.Remove(SESS_D204130, HttpContext);
            }

            D204130SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);
            model = new(Syokuin, sessionInfo.ShishoLists);

            // １．１．権限チェック
            // (1)	ログインユーザの権限が「参照」「更新権限」いずれも許可されていない場合、メッセージを設定し業務エラー画面を表示する。
            bool dispKengen = ScreenSosaUtil.CanReference(F204Const.SCREEN_ID_D204130, HttpContext);
            bool updKengen = ScreenSosaUtil.CanUpdate(F204Const.SCREEN_ID_D204130, HttpContext);

            model.DispKengen = F204Const.Authority.None;
            model.UpdateKengenFlg = false;  // ← 初期値として false を設定

            if (updKengen)
            {
                model.DispKengen = F204Const.Authority.Update;// "更新権限";
                model.UpdateKengenFlg = true;                  // JS用
            }
            else if (dispKengen)
            {
                model.DispKengen = F204Const.Authority.ReadOnly;// "参照権限";
            }
            else
            {
                throw new AppException("ME10075", MessageUtil.Get("ME10075"));
            }

            NskAppContext dbContext = getJigyoDb<NskAppContext>();

            // ２．画面表示情報をDBから取得
            // ２．１．「共済目的名称」を取得する。
            model.KyosaiMokuteki = dbContext.M00010共済目的名称s.SingleOrDefault(x =>
                (x.共済目的コード == sessionInfo.KyosaiMokutekiCd))?.共済目的名称 ?? string.Empty;

            // ３．４．共済目的名称が取得できなかった場合
            if (string.IsNullOrWhiteSpace(model.KyosaiMokuteki))
            {
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // ２．２．「類区分情報リスト」を取得する。
            model.SearchCondition.RuiKbnLists.AddRange(dbContext.M00020類名称s.Where(m =>
                (m.共済目的コード == sessionInfo.KyosaiMokutekiCd))?.
                OrderBy(m => m.類区分).
                Select(m => new SelectListItem($"{m.類区分} {m.類名称}", $"{m.類区分}")));
            SelectListItem ruiSelected = model.SearchCondition.RuiKbnLists.First();

            // ２．３．「用途区分リスト」を取得する。 （共済目的コードでフィルタ）
            // 用途区分リストの構築
            model.SearchCondition.YoutoKbnLists = dbContext.M10110用途区分名称s
                .Where(m => m.共済目的コード == sessionInfo.KyosaiMokutekiCd)
                .OrderBy(m => m.用途区分)
                .Select(m => new SelectListItem($"{m.用途区分} {m.用途名称}", $"{m.用途区分}"))
                .ToList();

            string ruiKbn = model.SearchCondition.RuiKbnLists.FirstOrDefault()?.Value ?? string.Empty;

            // ※選択状態が必要なら（類区分と同様に）先頭をselectedにすることも可能
            var youtoSelected = model.SearchCondition.YoutoKbnLists.FirstOrDefault();

            // ３．画面項目設定
            // ３．１．「２．」で取得した値を設定する。
            // 「２．」で取得した値は取得時にそのまま設定
            // ポータルから連係された値を設定。
            model.KyosaiMokutekiCd = sessionInfo.KyosaiMokutekiCd;
            model.Nensan = $"{sessionInfo.Nensan}";

            // ３．２．[画面：表示数]、[画面：表示順１]、[画面：表示順２]、[画面：表示順３]を設定する。
            // 表示順リストを共済目的コードごとに切り替える
            var sortList = new List<SelectListItem>();
            switch (sessionInfo.KyosaiMokutekiCd)
            {
                case "11": // 水稲
                    sortList.Add(new SelectListItem { Text = "支所", Value = D204130SearchCondition.DisplaySortType.Shisyo.ToString() });
                    sortList.Add(new SelectListItem { Text = "大地区", Value = D204130SearchCondition.DisplaySortType.Daichiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "小地区", Value = D204130SearchCondition.DisplaySortType.Shochiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "組合員等コード", Value = D204130SearchCondition.DisplaySortType.KumiaiintoCd.ToString() });
                    sortList.Add(new SelectListItem { Text = "類区分", Value = D204130SearchCondition.DisplaySortType.Ruikbn.ToString() });
                    break;

                case "20": // 陸稲
                    sortList.Add(new SelectListItem { Text = "支所", Value = D204130SearchCondition.DisplaySortType.Shisyo.ToString() });
                    sortList.Add(new SelectListItem { Text = "大地区", Value = D204130SearchCondition.DisplaySortType.Daichiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "小地区", Value = D204130SearchCondition.DisplaySortType.Shochiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "組合員等コード", Value = D204130SearchCondition.DisplaySortType.KumiaiintoCd.ToString() });
                    break;

                case "30": // 麦
                    sortList.Add(new SelectListItem { Text = "支所", Value = D204130SearchCondition.DisplaySortType.Shisyo.ToString() });
                    sortList.Add(new SelectListItem { Text = "大地区", Value = D204130SearchCondition.DisplaySortType.Daichiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "小地区", Value = D204130SearchCondition.DisplaySortType.Shochiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "組合員等コード", Value = D204130SearchCondition.DisplaySortType.KumiaiintoCd.ToString() });
                    sortList.Add(new SelectListItem { Text = "類区分", Value = D204130SearchCondition.DisplaySortType.Ruikbn.ToString() });
                    sortList.Add(new SelectListItem { Text = "用途区分", Value = D204130SearchCondition.DisplaySortType.YoutoKbn.ToString() });
                    break;

                default:
                    // 何も追加しない（空リストのまま）
                    break;
            }

            // モデルに設定
            model.SearchCondition.DisplaySortLists = sortList;

            // ４～６は設計誤りのためコメントアウト

            // ４．セッションから検索条件を取得する。
            // ４．１．セッションに検索条件がない場合
            // ４．１．1．検索結果を表示する「■共済金額設定」カテゴリの画面項目を非表示にし、処理を終了する。
            // ※■共済金額設定」カテゴリの画面項目を非表示にすると戻るボタンも非表示することとなる。

            // ４．２．セッションに検索条件がある場合、処理を続行する。
            // ５．画面項目再設定
            // ５．１．「４．」で取得した値を設定する。

            // ６．「検索ボタン」イベントを実施する。
            //model.SearchResult.SearchCondition = model.SearchCondition;
            //model.SearchResult.GetPageDataList(dbContext, sessionInfo, F204Const.PAGE_1);

            // 検索結果からメッセージ設定
            //if (model.SearchResult.AllRecCount == 0)
            //{
            //    // エラーメッセージを「メッセージエリア２」に設定する。
            //    model.MessageArea2 = MessageUtil.Get("MI00011");
            //    ModelState.AddModelError("MessageArea2", model.MessageArea2);
            //}

            // 初期表示時、支所グループリストを持つ場合、初期選択状態を空欄に設定する。
            // [TODO] 共通部品に改修が入り処理が不要となった場合は削除をすること
            if (!model.SearchCondition.TodofukenDropDownList.ShishoList.IsNullOrEmpty())
            {
                model.SearchCondition.TodofukenDropDownList.ShishoCd = "";
            }
            else
            {
                // ３．４．支所リストが取得できなかった場合
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // ３．４．大地区リストが取得できなかった場合
            var daichikuList = DaichikuUtil.GetDaichikuList(
                model.SearchCondition.TodofukenDropDownList.TodofukenCd,
                model.SearchCondition.TodofukenDropDownList.KumiaitoCd
            );

            // 空チェックして業務エラー
            if (daichikuList == null || !daichikuList.Any())
            {
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // 検索結果を初期化（明示的に空データで構築）
            model.SearchResult = new(model.SearchCondition);

            // セッションに保存する
            SessionUtil.Set(SESS_D204130, model, HttpContext);

            ModelState.Clear();

            // 売渡数量全数調査野帳入力（全相殺）画面を表示する
            return View(F204Const.SCREEN_ID_D204130, model);        
        }

        #region ページャーイベント
        /// <summary>
        /// 検索結果ページャー
        /// </summary>
        /// <param name="id">ページID</param>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult ResultPager(string id)
        {
            // ページIDは数値以外のデータの場合
            if (!Regex.IsMatch(id, @"^[0-9]+$") || F204Const.PAGE_0 == id)
            {
                return BadRequest();
            }

            // セッションから共済金額設定モデルを取得する
            D204130Model model = SessionUtil.Get<D204130Model>(SESS_D204130, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }
            // メッセージをクリアする
            model.MessageArea1 = string.Empty;
            model.MessageArea2 = string.Empty;

            // モデル状態ディクショナリからすべての項目を削除します。
            ModelState.Clear();

            // 検索結果を取得する
            NskAppContext dbContext = getJigyoDb<NskAppContext>();
            D204130SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);
            model.SearchResult.GetPageDataList(dbContext, sessionInfo, int.Parse(id));

            model.SearchResult.ApplyInputAndRebuild(
                model.SearchResult.DispRecords,
                model.SearchCondition,
                sessionInfo,
                dbContext
            );
            model.SearchResult.Reindex();

            // 検索条件と検索結果をセッションに保存する
            SessionUtil.Set(SESS_D204130, model, HttpContext);

            return PartialViewAsJson("_D204130SearchResult", model);
        }
        #endregion

        /// <summary>
        /// 共済金額設定を検索する。													
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Search(D204130Model dispModel)
        {
            Console.WriteLine("Search呼ばれた");

            D204130SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            // セッションから加入申込書入力（水稲）モデルを取得する
            D204130Model model = SessionUtil.Get<D204130Model>(SESS_D204130, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }

            // 画面入力値 → モデルに反映
            model.SearchCondition.ApplyInput(dispModel.SearchCondition);
            // 結果表示フラグ 初期化
            model.SearchCondition.IsResultDisplay = false;

            // 検索結果クリア
            model.SearchResult = new(model.SearchCondition);
            // メッセージクリア
            model.MessageArea1 = string.Empty;
            model.MessageArea2 = string.Empty;
            ModelState.Clear();

            // ２．入力チェック
            // ２．１．属性チェック
            // 画面入力値をセッションモデルに反映
            model.SearchCondition.ApplyInput(dispModel.SearchCondition);
            // 必須チェック用クラス
            InputRequiredAttribute isInputRequired = new InputRequiredAttribute();

            // 組合員等コード（開始）
            if (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdFrom))
            {
                // 入力ありの場合属性チェック
                // 半角数値チェック用クラス
                NumericAttribute isNumeric = new NumericAttribute();
                // 桁数チェック用クラス
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                if (!isNumeric.IsValid(model.SearchCondition.KumiaiinToCdFrom))
                {
                    // 半角数値チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isNumeric.FormatErrorMessage("組合員等コード（開始）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                } 
                else if (!isDigitLength.IsValid(model.SearchCondition.KumiaiinToCdFrom))
                {
                    // 桁数チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isDigitLength.FormatErrorMessage("組合員等コード（開始）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
            }
            // 組合員等コード（終了）
            if (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdTo))
            {
                // 入力ありの場合属性チェック
                // 半角数値チェック用クラス
                NumericAttribute isNumeric = new NumericAttribute();
                // 桁数チェック用クラス
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                if (!isNumeric.IsValid(model.SearchCondition.KumiaiinToCdTo))
                {
                    // 半角数値チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isNumeric.FormatErrorMessage("組合員等コード（終了）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
                else if (!isDigitLength.IsValid(model.SearchCondition.KumiaiinToCdTo))
                {
                    // 桁数チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isDigitLength.FormatErrorMessage("組合員等コード（終了）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
            }

            // ２．２．独自チェック
            // ２．２．１．[画面：小地区（終了）]<[画面：小地区（開始）]の場合、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            if ((!string.IsNullOrEmpty(model.SearchCondition.TodofukenDropDownList.ShochikuCdFrom) &&
                (!string.IsNullOrEmpty(model.SearchCondition.TodofukenDropDownList.ShochikuCdTo))) &&
                (model.SearchCondition.TodofukenDropDownList.ShochikuCdFrom.CompareTo(
                 model.SearchCondition.TodofukenDropDownList.ShochikuCdTo) > 0))
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME10020", "小地区");

                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }

            // (２．２．２．[画面：組合員等コード（終了）]<[画面：組合員等コード（開始）]の場合、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            if ((!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdFrom) &&
                (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdTo))) &&
                (model.SearchCondition.KumiaiinToCdFrom.CompareTo(
                 model.SearchCondition.KumiaiinToCdTo) > 0))
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME10020", "組合員等コード");

                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }


            // ２．２．３．［画面：表示順］の選択値に重複がある場合（以下のいずれかの条件に該当する場合）、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            List<D204130SearchCondition.DisplaySortType> sortTypes = new List<D204130SearchCondition.DisplaySortType>();

            // ［画面：表示順］が選択されている場合、配列に格納
            if (model.SearchCondition.DisplaySort1.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort1.Value);
            }
            if (model.SearchCondition.DisplaySort2.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort2.Value);
            }
            if (model.SearchCondition.DisplaySort3.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort3.Value);
            }

            // 配列に格納した表示順の件数と重複除外した件数が一致するか判定し
            // 判定しない場合は重複と判断しエラーと判定する
            bool hasDuplicates = sortTypes.Count != sortTypes.Distinct().Count();

            if (hasDuplicates)
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME90018", "表示順");
                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }

            // 表示数の設定
            model.SearchResult.DisplayCount = model.SearchCondition.DisplayCount ?? CoreConst.PAGE_SIZE; ;

            // 共済目的コードに応じて不要なバリデーションを無効化
            var sortList = new List<SelectListItem>();

            switch (sessionInfo.KyosaiMokutekiCd)
            {
                case "11": // 水稲
                    sortList.Add(new SelectListItem("支所", D204130SearchCondition.DisplaySortType.Shisyo.ToString()));
                    sortList.Add(new SelectListItem("大地区", D204130SearchCondition.DisplaySortType.Daichiku.ToString()));
                    sortList.Add(new SelectListItem("小地区", D204130SearchCondition.DisplaySortType.Shochiku.ToString()));
                    sortList.Add(new SelectListItem("組合員等コード", D204130SearchCondition.DisplaySortType.KumiaiintoCd.ToString()));
                    break;

                case "30": // 麦
                    sortList.Add(new SelectListItem("類区分", D204130SearchCondition.DisplaySortType.Ruikbn.ToString()));
                    sortList.Add(new SelectListItem("用途区分", D204130SearchCondition.DisplaySortType.YoutoKbn.ToString()));
                    sortList.Add(new SelectListItem("組合員等コード", D204130SearchCondition.DisplaySortType.KumiaiintoCd.ToString()));
                    break;
            }

            // ２．３．「メッセージリスト」のメッセージの有無で下記の処理を行う。
            if (ModelState.IsValid)
            {
                // ３．データ検索SQLを実行（ログ出力：あり）
                // ３．１．「検索結果情報リスト」を取得する。
                NskAppContext dbContext = getJigyoDb<NskAppContext>();
                model.SearchResult.GetPageDataList(dbContext, sessionInfo, F204Const.PAGE_1);

                // データ取得失敗時のチェック（ここ追加）
                if (model.SearchResult.DispRecords == null)
                {
                    model.MessageArea2 = MessageUtil.Get("ME01645", "データの取得");
                    ModelState.AddModelError("MessageArea2", model.MessageArea2);

                    return Json(new
                    {
                        resultArea = "",
                        messageArea2 = ModelState["MessageArea2"]
                    });
                }

                // ★ここでログ出力
                Console.WriteLine($"[Search] 検索件数: {model.SearchResult.AllRecCount}");
                foreach (var rec in model.SearchResult.DispRecords)
                {
                    Console.WriteLine($"[Search] 組合員コード: {rec.KumiaiintoCd}, 氏名: {rec.FullNm}");
                }

                model.SearchResult.ApplyInputAndRebuild(
                    model.SearchResult.DispRecords,
                    model.SearchCondition,
                    sessionInfo,
                    dbContext
                );
                model.SearchResult.Reindex();

                // ４．検索結果の表示
                if (model.SearchResult.AllRecCount == 0)
                {
                    // エラーメッセージを「メッセージエリア２」に設定する。
                    model.MessageArea2 = MessageUtil.Get("MI00011");
                    ModelState.AddModelError("MessageArea2", model.MessageArea2);
                }

                // 結果表示フラグON
                model.SearchCondition.IsResultDisplay = true;
            }

            // ５．検索条件、検索結果件数の保持
            // ５．１．検索条件、検索結果件数をセッションに保存する。
            SessionUtil.Set(SESS_D204130, model, HttpContext);

            JsonResult resultArea = PartialViewAsJson("_D204130SearchResult", model);

            // ６．画面操作制御区分による表示
            // ６．１．画面操作制御区分により、下表の画面項目の活性制御を行う。

            return Json(new { resultArea = resultArea.Value, messageArea1 = ModelState["MessageArea1"], messageArea2 = ModelState["MessageArea2"] });
        }

        /// <summary>
        /// 行挿入処理
        /// </summary>
        /// <param name="dispModel">画面から送られてきたモデル（検索結果）</param>
        /// <returns>追加行のインデックスと再描画用HTMLを返却</returns>
        public ActionResult AddNewRowBtn(D204130Model dispModel)
        {
            Console.WriteLine("★AddNewRowBtn 呼び出しタイミング: " + DateTime.Now.ToString("HH:mm:ss.fff"));

            // ★調査ログ：画面からPOSTされたチェックボックスの状態を確認
            for (int i = 0; i < dispModel.SearchResult.DispRecords.Count; i++)
            {
                var row = dispModel.SearchResult.DispRecords[i];
                Console.WriteLine($"[POST] Index={i}, CheckSelect={row.CheckSelect}, KumiaiintoCd={row.KumiaiintoCd}");
            }

            // DBコンテキスト取得（業務DB）
            var dbContext = getJigyoDb<NskAppContext>();

            // セッション情報取得（共済目的コードなどが格納されている）
            D204130SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            // セッションから画面モデルを取得（SearchResultなどが含まれる）
            D204130Model model = SessionUtil.Get<D204130Model>(SESS_D204130, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }

            // POSTされたCheckSelectをセッションに反映
            ApplyCheckSelectFromPost(dispModel.SearchResult.DispRecords, model.SearchResult.DispRecords);

            // 共済目的コードを明示的にSearchConditionにセット（ビューに渡っていない可能性に備える）
            model.SearchResult.SearchCondition.KyosaiMokutekiCd = model.KyosaiMokutekiCd;

            // モデル状態ディクショナリからすべての項目を削除します。
            ModelState.Clear();

            // １．[画面：明細：行選択]チェックボックスがオンになっている明細行の次行に空白行を追加する。
            // オン状態の[画面：明細：行選択]チェックボックスがない場合は、明細行の最後に空白行を追加する。空白行の[画面：明細：行追加フラグ（非表示）]をtrueとする。
            // オン状態の[画面：明細：行選択]チェックボックス複数存在する場合は、なにもしない。

            // ★挿入インデックスの取得（ステップ3）
            int insertIndex = -1;
            if (int.TryParse(HttpContext.Request.Form["insertIndex"], out int parsedIndex))
            {
                insertIndex = parsedIndex;
                Console.WriteLine($"★画面側Index = {insertIndex}（※変換なしで使用）");
            }

            // ★修正6: チェックされた行を取得
            var selectedList = model.SearchResult.DispRecords
                .Select((r, idx) => new { r.CheckSelect, r.IsDelRec, idx })
                .Where(x => x.CheckSelect && !x.IsDelRec)
                .ToList();

            if (selectedList.Count > 1)
            {
                return Json(new { addRowIdx = -1, resultArea = PartialViewAsJson("_D204130SearchResult", model) });
            }
            else if (selectedList.Count == 1)
            {
                insertIndex = selectedList[0].idx + 1;
            }
            else
            {
                insertIndex = model.SearchResult.DispRecords.Count; // ← 末尾に追加
            }

            // 追加行のインデックスを取得
            int addRowIdx = model.SearchResult.AddPageData(insertIndex);

            // trueをセット
            if (addRowIdx >= 0 && addRowIdx < model.SearchResult.DispRecords.Count)
            {
                model.SearchResult.DispRecords[addRowIdx].IsNewRec = true;
            }

            model.SearchResult.ApplyInputAndRebuild(
                model.SearchResult.DispRecords,
                model.SearchCondition,
                sessionInfo,
                dbContext
            );

            // Indexを再振り（画面表示や削除時の整合性のため）
            model.SearchResult.Reindex();

            // ✅ ここにログを追加する
            Console.WriteLine("★行挿入直後ログ");
            Console.WriteLine("DispRecords.Count       = " + model.SearchResult.DispRecords.Count);
            Console.WriteLine("IsDelRec=false の件数    = " + model.SearchResult.DispRecords.Count(r => !r.IsDelRec));
            Console.WriteLine("AllRecCount（表示用）   = " + model.SearchResult.AllRecCount);

            Console.WriteLine("★AddPageData 後レコード数: " + model.SearchResult.DispRecords.Count);

            // ▼追加：AllRecCount を再計算
            model.SearchResult.AllRecCount = model.SearchResult.DispRecords.Count(r => !r.IsDelRec);

            Console.WriteLine($"【確認】再設定後 AllRecCount = {model.SearchResult.AllRecCount}");

            // 結果表示ON
            model.SearchCondition.IsResultDisplay = true;

            // 検索条件と検索結果をセッションに保存する
            SessionUtil.Set(SESS_D204130, model, HttpContext);

            // ２．フォーカスは追加行の先頭項目に当てる。
            return Json(new { addRowIdx, resultArea = PartialViewAsJson("_D204130SearchResult", model) });
        }

        /// <summary>
        /// チェックされた行を削除（非表示）する
        /// </summary>
        [HttpPost]
        public ActionResult DeleteSelectedRowsBtn(D204130Model dispModel)
        {
            // セッション取得
            var model = SessionUtil.Get<D204130Model>(SESS_D204130, HttpContext);
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }

            ModelState.Clear();

            // POSTされたCheckSelectをセッションに反映
            ApplyCheckSelectFromPost(dispModel.SearchResult.DispRecords, model.SearchResult.DispRecords);

            // ★調査ログ：セッションのCheckSelectが正しく反映されたか
            for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
            {
                Console.WriteLine($"[Session] Index={i}, CheckSelect={model.SearchResult.DispRecords[i].CheckSelect}, IsDelRec={model.SearchResult.DispRecords[i].IsDelRec}");
            }

            // CheckSelect = true の未削除行が1件もない場合は中止
            if (!model.SearchResult.DispRecords.Any(r => r.CheckSelect && !r.IsDelRec))
            {
                return Json(new { resultArea = (object?)null, message = "" });
            }

            // 未削除かつ選択されている行のみを削除
            for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
            {
                var row = model.SearchResult.DispRecords[i];
                if (row.CheckSelect && !row.IsDelRec)
                {
                    row.IsDelRec = true;
                    Console.WriteLine($"削除フラグ設定: {i} 行目 - {row.KumiaiintoCd}");
                }
            }

            // 未削除の行については選択解除（再表示後の混乱防止）
            foreach (var rec in model.SearchResult.DispRecords)
            {
                if (!rec.IsDelRec)
                {
                    rec.CheckSelect = false;
                }
            }

            // 表示対象ありフラグ
            model.SearchCondition.IsResultDisplay = true;

            // 非削除行の件数を再カウント
            model.SearchResult.AllRecCount = model.SearchResult.DispRecords.Count(r => !r.IsDelRec);
            model.SearchResult.AllRecCount = model.SearchResult.DispRecords.Count(r => !r.IsDelRec);

            model.SearchResult.Reindex();

            // セッション情報の取得
            D204130SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            model.SearchResult.ApplyInputAndRebuild(
                model.SearchResult.DispRecords,
                model.SearchCondition,
                sessionInfo,
                getJigyoDb<NskAppContext>() 
            );

            // 表示用ページャー再構築
            int currentPage = model.SearchResult.Pager.CurrentPage == 0 ? 1 : model.SearchResult.Pager.CurrentPage;
            model.SearchResult.Pager = new(currentPage, model.SearchResult.DisplayCount, model.SearchResult.AllRecCount);

            // セッション更新
            SessionUtil.Set(SESS_D204130, model, HttpContext);

            // 部分ビューをHTMLに変換して返却
            string html = RenderPartialViewToString("_D204130SearchResult", model);

            // 最初の未削除行のインデックス（フォーカス制御用）
            int firstRowIdx = model.SearchResult.DispRecords.FindIndex(r => !r.IsDelRec);

            return Json(new
            {
                resultArea = new { partialView = html },
                firstRowIdx
            });
        }


        #region 登録イベント

        /// <summary>
        /// 共済金額設定を登録
        /// </summary>
        /// <returns></returns>
        public ActionResult Insert(D204130Model dispModel)
        {
            IDbContextTransaction? transaction = null;
            string errMessage = string.Empty;
            try
            {
                D204130SessionInfo sessionInfo = new();
                sessionInfo.GetInfo(HttpContext);

                // セッションからモデルを取得
                D204130Model model = SessionUtil.Get<D204130Model>(SESS_D204130, HttpContext);
                if (model is null)
                {
                    throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
                }

                Console.WriteLine("▼▼ CheckSelect / IsDelRec / IsNewRec 状態（確認用） ▼▼");
                for (int i = 0; i < dispModel.SearchResult.DispRecords.Count; i++)
                {
                    var rec = dispModel.SearchResult.DispRecords[i];
                    Console.WriteLine($"[Post] Index={i}, CheckSelect={rec.CheckSelect}, IsDelRec={rec.IsDelRec}, IsNewRec={rec.IsNewRec}");
                }
                Console.WriteLine("▲▲ CheckSelect / IsDelRec / IsNewRec 状態（確認完了） ▲▲");

                // ApplyInputの前に、IsNewRec=true のIndexを保存
                var newRecIndexes = dispModel.SearchResult.DispRecords
                    .Select((r, idx) => new { r.IsNewRec, idx })
                    .Where(x => x.IsNewRec)
                    .Select(x => x.idx)
                    .ToHashSet(); // ← Set型で高速アクセス

                // 画面入力値をセッションモデルに反映
                model.SearchResult.ApplyInput(dispModel.SearchResult);

                foreach (var rec in model.SearchResult.DispRecords.Select((r, i) => new { r, i }))
                {
                    rec.r.IsNewRec = newRecIndexes.Contains(rec.i);
                }

                // 削除フラグ設定
                ApplyCheckSelectToDeleteFlag(model.SearchResult.DispRecords);

                // 再確認ログ（ApplyInput 後）
                Console.WriteLine("▼▼ ApplyInput 後のモデル状態 ▼▼");
                for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
                {
                    var rec = model.SearchResult.DispRecords[i];
                    Console.WriteLine($"[Model] Index={i}, CheckSelect={rec.CheckSelect}, IsDelRec={rec.IsDelRec}, IsNewRec={rec.IsNewRec}");
                }
                Console.WriteLine("▲▲ ApplyInput 後のモデル状態（確認完了） ▲▲");

                // 重複チェック（組合員等コード、類区分、用途区分）
                // 類区分：水稲・麦、用途区分：麦 のみチェック対象
                var duplicates = model.SearchResult.DispRecords
                    .Where(x => !x.IsDelRec) // 削除対象除外
                    .GroupBy(x => new
                    {
                        x.KumiaiintoCd,
                        RuiKbn = (model.KyosaiMokutekiCd == "11" || model.KyosaiMokutekiCd == "30") ? x.RuiKbn : null,
                        YoutoKbn = model.KyosaiMokutekiCd == "30" ? x.YoutoKbn : null
                    })
                    .Where(g => g.Count() > 1)
                    .ToList();

                if (duplicates.Any())
                {
                    errMessage = MessageUtil.Get("ME90018", "入力内容");
                    model.MessageArea2 = errMessage;
                    ModelState.AddModelError("MessageArea2", errMessage);
                    throw new AppException("ME90018", errMessage);
                }

                // 属性チェック
                InputRequiredAttribute isInputRequired = new InputRequiredAttribute();
                NumericAttribute isNumeric = new NumericAttribute();
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                string mokutekiCd = model.KyosaiMokutekiCd;

                // === 必須チェック・0自動セット ===
                foreach (var rec in model.SearchResult.DispRecords)
                {
                    if (rec.IsDelRec) continue;
                    if (!rec.IsNewRec) continue; // 新規登録のみ

                    // 必須・0自動セット分岐
                    switch (mokutekiCd)
                    {
                        case "20": // 陸稲
                                   // 必須：組合員等コード
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            // 数値/桁数チェックも既存同様
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            // 0自動セット
                            rec.RuiKbn = "0";
                            rec.YoutoKbn = "0";
                            break;

                        case "11": // 水稲
                                   // 必須：組合員等コード、類区分
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            if (!isInputRequired.IsValid(rec.RuiKbn))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("類区分");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            // 0自動セット
                            rec.YoutoKbn = "0";
                            break;

                        case "30": // 麦
                                   // 必須：組合員等コード、類区分、用途区分（現状どおり）
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            if (!isInputRequired.IsValid(rec.RuiKbn))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("類区分");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            if (!isInputRequired.IsValid(rec.YoutoKbn))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("用途区分");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            break;
                    }
                }

                // トランザクション開始
                NskAppContext dbContext = getJigyoDb<NskAppContext>();
                transaction = dbContext.Database.BeginTransaction();

                var delRecords = model.SearchResult.GetDeleteRecs();

                Console.WriteLine($"【削除候補件数】{delRecords.Count}");
                foreach (var rec in delRecords)
                {
                    Console.WriteLine($"削除対象: Index={rec.Index}, KumiaiintoCd={rec.KumiaiintoCd}, IsDelRec={rec.IsDelRec}, IsNewRec={rec.IsNewRec}");
                }

                int delCount = 0;
                if (delRecords.Count > 0)
                {
                    delCount += model.SearchResult.DeleteUriwatashi(ref dbContext, sessionInfo, ref delRecords);
                }

                // 入力再反映・整合性再構築
                model.SearchResult.ApplyInputAndRebuild(
                    model.SearchResult.DispRecords,
                    model.SearchCondition,
                    sessionInfo,
                    dbContext
                );
                model.SearchResult.Reindex();

                int updCount = 0;
                List<D204130ResultRecord> updRecords = model.SearchResult.GetUpdateRecs(ref dbContext, sessionInfo);
                if (updRecords.Count > 0)
                {
                    updCount += model.SearchResult.UpdateUriwatashi(
                        ref dbContext,
                        sessionInfo,
                        GetUserId(),
                        DateUtil.GetSysDateTime(),
                        ref updRecords);
                }

                int insCount = 0;
                List<D204130ResultRecord> addRecords = model.SearchResult.GetAddRecs();
                if (addRecords.Count > 0)
                {
                    insCount += model.SearchResult.AppendUriwatashi(
                        ref dbContext,
                        sessionInfo,
                        GetUserId(),
                        DateUtil.GetSysDateTime(),
                        ref addRecords);
                }

                foreach (var rec in model.SearchResult.DispRecords)
                {
                    rec.IsNewRec = false;
                }

                if (delCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "削除");
                }
                if (updCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "更新");
                }
                if (insCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "登録");
                }
                if (delCount == 0 && updCount == 0 && insCount == 0)
                {
                    errMessage = MessageUtil.Get("MI00012");
                }

                transaction.CommitAsync();

                SessionUtil.Set(SESS_D204130, model, HttpContext);
            }
            catch (Exception ex)
            {
                transaction?.RollbackAsync();

                if (string.IsNullOrEmpty(errMessage))
                {
                    if (ex is DBConcurrencyException)
                    {
                        errMessage = !string.IsNullOrEmpty(ex.Message)
                            ? MessageUtil.Get(ex.Message)
                            : MessageUtil.Get("ME10081");
                    }
                    else if (ex is DbUpdateException)
                    {
                        errMessage = MessageUtil.Get("ME10081");
                    }
                    else
                    {
                        errMessage = MessageUtil.Get("MF00001");
                    }
                }
            }

            return Json(new { message = errMessage });
        }

        #endregion


        #region 戻るイベント
        /// <summary>
        /// 戻る
        /// ポータルへ遷移する。
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Back()
        {
            // ポータル

            return Json(new { result = "success" });
        }
        #endregion


        /// <summary>
        /// 組合員等名更新
        /// </summary>
        /// <param name="kumiaiintoCd">組合員等コード</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult UpdateKumiaiintoName(string kumiaiintoCd)
        {
            // 組合員等名を取得 
            // t_農業者情報から「組合員等コード」に該当する「氏名又は法人名」を取得する。
            D204130SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);
            NskAppContext dbContext = getJigyoDb<NskAppContext>();
            VNogyosha? kumiaiinto = dbContext.VNogyoshas.SingleOrDefault(x =>
                (x.TodofukenCd == sessionInfo.TodofukenCd) &&
                (x.KumiaitoCd == sessionInfo.KumiaitoCd) &&
                (x.KumiaiintoCd == kumiaiintoCd)
                );
            string kumiaiintoNm = kumiaiinto?.HojinFullNm ?? string.Empty;

            // 「組合員等名」をJSON化して返送する。
            return Json(new { kumiaiintoNm });
        }

        /// <summary>
        /// 類区分に応じた用途区分のリストを取得して返すAjax用アクション
        /// </summary>
        [HttpPost]
        public JsonResult GetYoutoKbnList(string ruiKbn)
        {
            var dbContext = getJigyoDb<NskAppContext>();
            D204130SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            var result = GetYoutoKbnSelectList(dbContext, sessionInfo.KyosaiMokutekiCd, ruiKbn);
            return Json(new { list = result });
        }

        /// <summary>
        /// 類区分に応じた用途区分のドロップダウンリストを取得する共通関数。
        /// 共済目的コードに応じて、用途区分名称マスタ（m_10110）から用途区分を取得する。
        /// 類区分が指定されている場合は、用途区分選択マスタ（m_10120）との突合で絞り込む。
        /// </summary>
        /// <param name="dbContext">DBコンテキスト</param>
        /// <param name="kyosaiMokutekiCd">共済目的コード（セッションより取得）</param>
        /// <param name="ruiKbn">選択された類区分（空欄の場合は全件取得）</param>
        /// <returns>用途区分のSelectList（Value: 用途区分, Text: 用途短縮名称）</returns>
        private List<SelectListItem> GetYoutoKbnSelectList(NskAppContext dbContext, string kyosaiMokutekiCd, string ruiKbn)
        {
            var list = (
                from m in dbContext.M10110用途区分名称s
                where m.共済目的コード == kyosaiMokutekiCd &&
                      (string.IsNullOrEmpty(ruiKbn) || dbContext.M10120用途区分選択s
                          .Where(x => x.共済目的コード == kyosaiMokutekiCd && x.類区分 == ruiKbn)
                          .Select(x => x.用途区分).Contains(m.用途区分))
                select new SelectListItem
                {
                    Value = m.用途区分,
                    Text = m.用途短縮名称
                }).ToList();

            foreach (var item in list)
            {
                Console.WriteLine($"[用途区分リスト] Value={item.Value}, Text={item.Text}");
            }

            return list;
        }

        /// <summary>
        /// CheckSelect が true の行に対して IsDelRec = true を設定する
        /// </summary>
        private void ApplyCheckSelectToDeleteFlag(List<D204130ResultRecord> dispRecords)
        {
            for (int i = 0; i < dispRecords.Count; i++)
            {
                var rec = dispRecords[i];
                if (rec.CheckSelect)
                {
                    rec.IsDelRec = true;
                    Console.WriteLine($"[削除フラグ設定] Index={i}, 組合員等コード={rec.KumiaiintoCd}");
                }
            }
        }

        /// <summary>
        /// POSTされたチェック状態（CheckSelect）をセッション側に反映する共通メソッド（Indexベース）
        /// 削除済み行も含め、Indexに一致する行のCheckSelectを上書きする。
        /// </summary>
        private void ApplyCheckSelectFromPost(List<D204130ResultRecord> from, List<D204130ResultRecord> to)
        {
            foreach (var postRow in from)
            {
                int idx = postRow.Index;
                if (idx < to.Count)
                {
                    Console.WriteLine($"★ApplyCheckSelect: Index={idx}, FromPost={postRow.CheckSelect}");
                    to[idx].CheckSelect = postRow.CheckSelect;
                }
            }
        }

        /// <summary>
        /// 指定された部分ビューをHTML文字列としてレンダリングします。
        /// JavaScriptからのAjaxで部分更新するために使用します。
        /// </summary>
        /// <param name="viewName">部分ビューの名前（例：_D204130SearchResult）</param>
        /// <param name="model">ビューに渡すモデルオブジェクト</param>
        /// <returns>レンダリングされたHTML文字列</returns>
        protected string RenderPartialViewToString(string viewName, object model)
        {
            ViewData.Model = model;

            using var sw = new StringWriter();

            // ビューを探す（注：ViewEngineではなく _viewEngine）
            var viewResult = _viewEngine.FindView(ControllerContext, viewName, false);
            if (viewResult.View == null)
            {
                throw new ArgumentNullException($"ビュー '{viewName}' が見つかりません。");
            }

            var viewContext = new ViewContext(
                ControllerContext,
                viewResult.View,
                ViewData,
                TempData,
                sw,
                new HtmlHelperOptions()
            );

            viewResult.View.RenderAsync(viewContext).Wait();

            return sw.ToString();
        }
    }
}
