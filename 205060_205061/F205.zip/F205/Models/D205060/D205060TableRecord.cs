﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NskWeb.Areas.F205.Models.D205060
{
    /// <summary>
    /// 仮渡し金対象者項目モデル（検索結果明細データ）
    /// </summary>
    [Serializable]
    public class D205060TableRecord
    {
        /// <summary>
        /// 行選択用ボタン
        /// </summary>
        [NotMapped]
        public bool SelectCheck { get; set; }

        /// <summary>
        /// 組合員等コード
        /// </summary>
        public string 組合員等コード { get; set; }

        /// <summary>
        /// 組合員等氏名
        /// </summary>
        public string 組合員等氏名 { get; set; }

        /// <summary>
        /// 仮渡回
        /// </summary>
        public string? 仮渡回 { get; set; }

        /// <summary>
        /// 仮渡し計算額
        /// </summary>
        public string? 仮渡し計算額 { get; set; }

        /// <summary>
        /// 既支払仮渡額
        /// </summary>
        public string? 既支払仮渡額 { get; set; }

        /// <summary>
        /// 支払対象
        /// </summary>
        public bool 支払対象 { get; set; }

        /// <summary>
        /// 申告単収
        /// </summary>
        public string? 仮渡し支払額 { get; set; }

        /// <summary>
        /// 支払日
        /// </summary>
        public DateTime? 支払日 { get; set; }
    }
}
