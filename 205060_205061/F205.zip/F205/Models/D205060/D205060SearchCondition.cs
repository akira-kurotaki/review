﻿using CoreLibrary.Core.DropDown;
using CoreLibrary.Core.Dto;
using CoreLibrary.Core.Validator;
using Microsoft.AspNetCore.Mvc.Rendering;
using NskCommonLibrary.Core.Consts;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NskWeb.Areas.F205.Models.D205060
{
    /// <summary>
    /// 仮渡し金対象者設定処理項目
    /// </summary>
    [Serializable]
    public class D205060SearchCondition
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D205060SearchCondition()
        {
            // 都道府県マルチドロップダウンリスト
            this.TodofukenDropDownList = new TodofukenDropDownList("SearchCondition");
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="syokuin">職員マスタ</param>
        public D205060SearchCondition(Syokuin syokuin, List<Shisho> shishoList)
        {
            // 都道府県マルチドロップダウンリスト
            this.TodofukenDropDownList = new TodofukenDropDownList("SearchCondition", syokuin, shishoList);
        }

        /// <summary>
        /// 都道府県マルチドロップダウンリスト
        /// </summary>
        [NotMapped]
        public TodofukenDropDownList TodofukenDropDownList { get; set; }

        public HaraiStatus HaraiSts { get; set; }

        /// <summary>
        /// ソート順1
        /// </summary>
        public CoreConst.SortOrder DisplaySortOrder1 { get; set; }

        /// <summary>
        /// ソート順2
        /// </summary>
        public CoreConst.SortOrder DisplaySortOrder2 { get; set; }

        /// <summary>
        /// ソート順3
        /// </summary>
        public CoreConst.SortOrder DisplaySortOrder3 { get; set; }

        /// <summary>
        /// 表示順1
        /// </summary>
        public DisplaySortType? DisplaySort1 { get; set; }

        /// <summary>
        /// 表示順2
        /// </summary>
        public DisplaySortType? DisplaySort2 { get; set; }

        /// <summary>
        /// 表示順3
        /// </summary>
        public DisplaySortType? DisplaySort3 { get; set; }

        /// <summary>
        /// 表示数
        /// </summary>
        [Display(Name = "表示数")]
        public int? DisplayCount { get; set; }

        /// <summary>
        /// 表示順
        /// </summary>
        [Display(Name = "表示順")]
        public string TargetSortOrder { get; set; }

        /// <summary>
        /// 年産
        /// </summary>
        [Display(Name = "年産")]
        public string Nensan { get; set; }

        /// <summary>
        /// 共済目的
        /// </summary>
        [Display(Name = "共済目的")]
        public string KyosaiMokuteki { get; set; }

        /// <summary>
        /// 共済目的コード
        /// </summary>
        [Display(Name = "共済目的コード")]
        public string KyosaiMokutekiCd { get; set; }

        /// <summary>
        /// 組合員等コード
        /// </summary>
        [Display(Name = "組合等コード")]
        public string KumiaitoCd { get; set; }

        /// <summary>
        /// 大地区
        /// </summary>
        [Display(Name = "大地区")]
        public string DaichikuCd { get; set; }

        /// <summary>
        /// 大地区名
        /// </summary>
        [Display(Name = "大地区名")]
        public string DaichikuNm { get; set; }

        /// <summary>
        /// 大地区リスト
        /// </summary>
        [NotMapped]
        public List<SelectListItem> DaichikuList { get; set; }

        /// <summary>
        /// 小地区コード
        /// </summary>
        [Display(Name = "小地区コード")]
        public string ShochikuCd { get; set; }

        /// <summary>
        /// 支所コード
        /// </summary>
        [Display(Name = "支所")]
        public string ShishoCd { get; set; }

        /// <summary>
        /// 支所リスト
        /// </summary>
        [NotMapped]
        public List<SelectListItem> ShishoList { get; set; }

        /// <summary>
        /// 組合員等コード（開始）
        /// </summary>
        [Display(Name = "組合員等コード（開始）")]
        public string KumiaiinInfoCdFrom { get; set; }

        /// <summary>
        /// 組合員等コード（終了）
        /// </summary>
        [Display(Name = "組合員等コード（終了）")]
        public string KumiaiinInfoCdTo { get; set; }

        /// <summary>
        /// 仮渡し対象者
        /// </summary>
        [Display(Name = "仮渡し対象者")]
        public string KariwatashiTaishosha { get; set; }

        /// <summary>
        /// 仮渡し対象者
        /// </summary>
        [Display(Name = "仮渡し対象者")]
        public bool KariwatashiTaishoshaFlg { get; set; }

        /// <summary>
        /// 仮渡し支払い
        /// </summary>
        [Display(Name = "仮渡し支払い")]
        public string KariwatashiHarai { get; set; }

        /// <summary>
        /// 仮渡回
        /// </summary>
        [Display(Name = "仮渡回")]
        public string KariwatashiKai { get; set; }

        /// <summary>
        /// 検索結果表示フラグ
        /// </summary>
        public bool IsResultDisplay { get; set; }

        /// <summary>
        /// ユーザＩＤ
        /// </summary>
        [Display(Name = "ユーザＩＤ")]
        public string UserId { get; set; }

        /// <summary>
        /// パスワード
        /// </summary>
        [Display(Name = "パスワード")]
        public string Password { get; set; }

        /// <summary>
        /// 都道府県コード
        /// </summary>
        [Display(Name = "都道府県コード")]
        [WithinStringLength(2)]
        public string TodofukenCd { get; set; }

        /// <summary>
        /// 仮渡し支払い要素
        /// </summary>
        [Flags]
        public enum HaraiStatus
        {
            [Description("対象外")]
            Taishogai,
            [Description("対象")]
            Taisho,
            [Description("未払い")]
            Miharai,
            [Description("支払済み")]
            ShiharaiZumi
        }

        /// <summary>
        /// 表示順ドロップダウンリスト要素
        /// </summary>
        [Flags]
        public enum DisplaySortType
        {
            [Description("支所")]
            支所,
            [Description("大地区")]
            大地区,
            [Description("小地区")]
            小地区,
            [Description("組合員等")]
            組合員等,
            [Description("仮渡回")]
            仮渡回
        }
    }
}
