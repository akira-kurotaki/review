﻿
using CoreLibrary.Core.Base;
using ModelLibrary.Models;
using NskWeb.Areas.F000.Models.D000000;
using System.ComponentModel.DataAnnotations;

namespace NskWeb.Areas.F205.Models.D205060
{
    /// <summary>
    /// 仮渡し金対象者設定処理入力出力画面項目モデル
    /// </summary>
    [Serializable]
    public class D205060Model: CoreViewModel
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D205060Model()
        {
            this.SearchResult = new D205060SearchResult();
            this.SearchCondition = new D205060SearchCondition();
            this.D205060Info = new NSKPortalInfoModel();
        }

        /// <summary>
        /// 職員マスタの検索結果
        /// </summary>
        public VSyokuin VSyokuinRecords { get; set; }
        public NSKPortalInfoModel D205060Info { get; set; }
        public D205060SearchCondition SearchCondition { get; set; }
        public D205060SearchResult SearchResult { get; set; }
        public D205060TableRecord TableRecord { get; set; }

        /// <summary>
        /// サブタイトル
        /// </summary>
        [Display(Name = "検索条件")]
        public string Subtitle { get; set; }

        /// <summary>
        /// サブタイトル2
        /// </summary>
        [Display(Name = "仮渡し金対象者設定")]
        public string Subtitle2 { get; set; }

        /// <summary>
        /// メッセージエリア1
        /// </summary>
        public string MessageArea1 { get; set; }

        /// <summary>
        /// メッセージエリア2
        /// </summary>
        public string MessageArea2 { get; set; }

        /// <summary>
        /// 処理Id(画面区分)
        /// </summary>
        [Display(Name = "処理Id")]
        public string OpeId { get; set; }

        /// <summary>
        /// 更新チェックフラグ
        /// </summary>
        public bool UpdateKengenFlg { get; internal set; }

        /// <summary>
        /// 参照チェックフラグ
        /// </summary>
        public bool ReferKengenFlg { get; internal set; }
    }
}
