﻿using CoreLibrary.Core.Pager;

namespace NskWeb.Areas.F205.Models.D205061
{
    /// <summary>
    /// 仮渡し金対象者設定処理詳細設定画面項目モデル（検索結果部分）
    /// </summary>
    [Serializable]
    public class D205061SearchResult
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D205061SearchResult()
        {
            TableRecords = new List<D205061TableRecord>();
        }

        /// <summary>
        /// 検索結果一覧
        /// </summary>
        public List<D205061TableRecord> TableRecords { get; set; }

        /// <summary>
        /// ページャー
        /// </summary>
        public Pagination Pager { get; set; }

        /// <summary>
        /// 検索結果全件数
        /// </summary>
        public int TotalCount { get; set; }

        /// <summary>
        /// チェックオンにした明細データのindex
        /// </summary>
        public List<string> SelectCheckBoxes { get; set; }
    }
}
