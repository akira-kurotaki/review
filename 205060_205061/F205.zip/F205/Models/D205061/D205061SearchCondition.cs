﻿using CoreLibrary.Core.DropDown;
using CoreLibrary.Core.Dto;
using CoreLibrary.Core.Validator;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NskWeb.Areas.F205.Models.D205061
{
    /// <summary>
    /// 仮渡し金対象者設定処理詳細設定項目
    /// </summary>
    [Serializable]
    public class D205061SearchCondition
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D205061SearchCondition()
        {
            // 都道府県マルチドロップダウンリスト
            this.TodofukenDropDownList = new TodofukenDropDownList("SearchCondition");
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="syokuin">職員マスタ</param>
        public D205061SearchCondition(Syokuin syokuin, List<Shisho> shishoList)
        {
            // 都道府県マルチドロップダウンリスト
            this.TodofukenDropDownList = new TodofukenDropDownList("SearchCondition", syokuin, shishoList);
        }

        /// <summary>
        /// 都道府県マルチドロップダウンリスト
        /// </summary>
        [NotMapped]
        public TodofukenDropDownList TodofukenDropDownList { get; set; }

        /// <summary>
        /// 年産
        /// </summary>
        [Display(Name = "年産")]
        public string Nensan { get; set; }

        /// <summary>
        /// 共済目的
        /// </summary>
        [Display(Name = "共済目的")]
        public string KyosaiMokuteki { get; set; }

        /// <summary>
        /// 共済目的コード
        /// </summary>
        [Display(Name = "共済目的コード")]
        public string KyosaiMokutekiCd { get; set; }

        /// <summary>
        /// 組合員等コード
        /// </summary>
        [Display(Name = "組合等コード")]
        public string KumiaitoCd { get; set; }

        /// <summary>
        /// 組合員等コード
        /// </summary>
        [Display(Name = "組合員等コード")]
        public string KumiaiintoCd { get; set; }

        /// <summary>
        /// 氏名
        /// </summary>
        [Display(Name = "氏名")]
        public string Shimei { get; set; }

        /// <summary>
        /// 大地区
        /// </summary>
        [Display(Name = "大地区")]
        public string DaichikuCd { get; set; }

        /// <summary>
        /// 大地区名
        /// </summary>
        [Display(Name = "大地区名")]
        public string DaichikuNm { get; set; }

        /// <summary>
        /// 小地区コード
        /// </summary>
        [Display(Name = "小地区コード")]
        public string ShochikuCd { get; set; }

        /// <summary>
        /// 支所コード
        /// </summary>
        [Display(Name = "支所")]
        public string ShishoCd { get; set; }

        /// <summary>
        /// 市町村
        /// </summary>
        [Display(Name = "市町村")]
        public string ShichosonCd { get; set; }

        /// <summary>
        /// 仮渡支払回数
        /// </summary>
        [Display(Name = "仮渡支払回数")]
        public string KariwatashiShiharaiKaisu { get; set; }

        /// <summary>
        /// 類区分
        /// </summary>
        [Display(Name = "類区分")]
        public string RuiKubun { get; set; }

        /// <summary>
        /// 引受方式等
        /// </summary>
        [Display(Name = "引受方式等")]
        public string HikiukeHoshikito { get; set; }

        /// <summary>
        /// 共済金額
        /// </summary>
        [Display(Name = "共済金額")]
        public string KyosaiKingaku { get; set; }

        /// <summary>
        /// 支払対象区分
        /// </summary>
        [Display(Name = "支払対象区分")]
        public string ShiharaiTaishoKubun { get; set; }

        /// <summary>
        /// 仮渡計算額(前)
        /// </summary>
        [Display(Name = "仮渡計算額(前)")]
        public string KariwatashiKesangakuZEN { get; set; }

        /// <summary>
        /// 被害率
        /// </summary>
        [Display(Name = "被害率")]
        public string HigaiRitsu { get; set; }

        /// <summary>
        /// 実施被害割合
        /// </summary>
        [Display(Name = "実施被害割合")]
        public string JisshiHigaiWariai { get; set; }

        /// <summary>
        /// 仮渡支払率
        /// </summary>
        [Display(Name = "仮渡支払率")] 
        public string KariwatashiShiharaiRitsu { get; set; }

        /// <summary>
        /// 端数処理
        /// </summary>
        [Display(Name = "端数処理")]
        public string HasuShori { get; set; }

        /// <summary>
        /// 仮渡計算額（適）
        /// </summary>
        [Display(Name = "仮渡計算額（適）")]
        public string KariwatashiKesangakuTEKI { get; set; }

        /// <summary>
        /// 支払上限
        /// </summary>
        [Display(Name = "支払上限")]
        public string ShiharaiJogen { get; set; }

        /// <summary>
        /// 仮渡計算額
        /// </summary>
        [Display(Name = "仮渡計算額(前)")]
        public string KariwatashiKesangaku { get; set; }

        /// <summary>
        /// 既支払金額
        /// </summary>
        [Display(Name = "既支払金額")]
        public string KishiHaraiKingaku { get; set; }

        /// <summary>
        /// 今回支払金額
        /// </summary>
        [Display(Name = "今回支払金額")]
        public string KonkaiShiharaiKingaku { get; set; }

        /// <summary>
        /// 支払確定
        /// </summary>
        [Display(Name = "支払確定")]
        public bool ShiharaiKakuteFlg { get; set; }

        /// <summary>
        /// 備考
        /// </summary>
        [Display(Name = "備考")]
        public string Biko { get; set; }

        /// <summary>
        /// 仮渡支払日
        /// </summary>
        [Display(Name = "仮渡支払日")]
        public string KariwatashiShiharaibi { get; set; }

        /// <summary>
        /// ユーザＩＤ
        /// </summary>
        [Display(Name = "ユーザＩＤ")]
        public string UserId { get; set; }

        /// <summary>
        /// パスワード
        /// </summary>
        [Display(Name = "パスワード")]
        public string Password { get; set; }

        /// <summary>
        /// 都道府県コード
        /// </summary>
        [Display(Name = "都道府県コード")]
        [WithinStringLength(2)]
        public string TodofukenCd { get; set; }

    }
}
