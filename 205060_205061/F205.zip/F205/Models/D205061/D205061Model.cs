﻿
using CoreLibrary.Core.Base;
using ModelLibrary.Models;
using NskWeb.Areas.F000.Models.D000000;
using System.ComponentModel.DataAnnotations;

namespace NskWeb.Areas.F205.Models.D205061
{
    /// <summary>
    /// 仮渡し金対象者設定処理詳細設定画面項目モデル
    /// </summary>
    [Serializable]
    public class D205061Model : CoreViewModel
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D205061Model()
        {
            this.SearchResult = new D205061SearchResult();
            this.SearchCondition = new D205061SearchCondition();
            this.D205061Info = new NSKPortalInfoModel();
        }

        /// <summary>
        /// 職員マスタの検索結果
        /// </summary>
        public VSyokuin VSyokuinRecords { get; set; }
        public NSKPortalInfoModel D205061Info { get; set; }
        public D205061SearchCondition SearchCondition { get; set; }
        public D205061SearchResult SearchResult { get; set; }
        public D205061TableRecord TableRecord { get; set; }

        /// <summary>
        /// サブタイトル
        /// </summary>
        [Display(Name = "詳細設定")]
        public string Subtitle { get; set; }

        /// <summary>
        /// メッセージエリア1
        /// </summary>
        public string MessageArea1 { get; set; }

        /// <summary>
        /// 処理Id(画面区分)
        /// </summary>
        [Display(Name = "処理Id")]
        public string OpeId { get; set; }

        /// <summary>
        /// 更新チェックフラグ
        /// </summary>
        public bool UpdateKengenFlg { get; internal set; }

        /// <summary>
        /// 参照チェックフラグ
        /// </summary>
        public bool ReferKengenFlg { get; internal set; }
    }
}
