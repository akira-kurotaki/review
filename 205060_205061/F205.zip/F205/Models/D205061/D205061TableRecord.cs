﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NskWeb.Areas.F205.Models.D205061
{
    /// <summary>
    /// 仮渡し金対象者設定処理詳細設定画面項目モデル（検索結果明細データ）
    /// </summary>
    [Serializable]
    public class D205061TableRecord
    {
        /// <summary>
        /// 行選択用チェックボックス
        /// </summary>
        [NotMapped]
        public bool SelectCheck { get; set; }

        /// <summary>
        /// 耕地番号
        /// </summary>
        public string 耕地番号 { get; set; }

        /// <summary>
        /// 分筆番号
        /// </summary>
        public string 分筆番号 { get; set; }

        /// <summary>
        /// 引受面積
        /// </summary>
        public decimal? 引受面積 { get; set; }

        /// <summary>
        /// 地名地番
        /// </summary>
        public string 地名地番 { get; set; }

        /// <summary>
        /// 評価地区コード
        /// </summary>
        public string? 評価地区コード { get; set; }

        /// <summary>
        /// 申告収穫量
        /// </summary>
        public decimal? 申告収穫量 { get; set; }

        /// <summary>
        /// 申告単収
        /// </summary>
        public decimal? 申告単収 { get; set; }

        /// <summary>
        /// 被害判定コード
        /// </summary>
        public string 被害判定コード { get; set; }

        /// <summary>
        /// 評価年月日
        /// </summary>
        [NotMapped]
        public string StrHyokaNengappi { get; set; }

        /// <summary>
        /// 評価年月日
        /// </summary>
        public DateTime? 評価年月日 { get; set; }

        /// <summary>
        /// 評価者
        /// </summary>
        public string 評価者 { get; set; }

        /// <summary>
        /// 共済事故
        /// </summary>
        public string 共済事故 { get; set; }

        /// <summary>
        /// 災害種類
        /// </summary>
        public string 災害種類 { get; set; }

        /// <summary>
        /// 災害発生年月日
        /// </summary>
        [NotMapped]
        public string StrSaigaiHasseNengappi { get; set; }

        /// <summary>
        /// 災害発生年月日
        /// </summary>
        public DateTime? 災害発生年月日 { get; set; }

        /// <summary>
        /// 分割割合
        /// </summary>
        public decimal? 分割割合 { get; set; }

        /// <summary>
        /// 分割事由
        /// </summary>
        public string 分割事由 { get; set; }

        ///// <summary>
        ///// 用途区分
        ///// </summary>
        //public string? 用途区分 { get; set; } = string.Empty;

        /// <summary>
        /// 用途名称
        /// </summary>
        public string 用途名称 { get; set; }

        /// <summary>
        /// 一筆全半判定
        /// </summary>
        public string 一筆全半判定 { get; set; }

        /// <summary>
        /// 抜取単収
        /// </summary>
        public decimal? 抜取単収 { get; set; }

    }
}
