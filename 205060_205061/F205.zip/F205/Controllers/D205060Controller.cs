﻿using CoreLibrary.Core.Attributes;
using CoreLibrary.Core.Base;
using CoreLibrary.Core.Exceptions;
using CoreLibrary.Core.Pager;
using CoreLibrary.Core.Utility;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.EntityFrameworkCore;
using ModelLibrary.Models;
using Npgsql;
using NskAppModelLibrary.Context;
using NskAppModelLibrary.Models;
using NskWeb.Areas.F000.Models.D000000;
using NskWeb.Areas.F205.Consts;
using NskWeb.Areas.F205.Models.D205060;
using NskWeb.Common.Consts;
using ReportService.Core;
using System.Text;
using System.Text.RegularExpressions;
using CoreConst = NskCommonLibrary.Core.Consts.CoreConst;
using Math = System.Math;

namespace NskWeb.Areas.F205.Controllers
{
    /// <summary>
    /// 仮渡し金対象者設定処理
    /// </summary>
    [SessionOutCheck]
    [Area("F205")]
    public class D205060Controller : CoreController
    {
        #region メンバー定数
        /// <summary>
        /// 画面ID(D205060)
        /// </summary>
        private static readonly string SCREEN_ID_D205060 = "D205060";

        /// <summary>
        /// セッションキー(D205060)
        /// </summary>
        private static readonly string SESS_D205060 = SCREEN_ID_D205060 + "_" + "SCREEN";

        /// <summary>
        /// ページ0
        /// </summary>
        private static readonly string PAGE_0 = "0";
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="viewEngine"></param>
        /// <param name="serviceClient"></param>
        public D205060Controller(ICompositeViewEngine viewEngine, ReportServiceClient serviceClient) : base(viewEngine, serviceClient)
        {
        }
        #endregion

        #region 初期表示イベント
        /// <summary>
        /// イベント：初期化
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Init()
        {
            //画面操作制限区分コードによる表示
            var updateKengen = ScreenSosaUtil.CanUpdate(SCREEN_ID_D205060, HttpContext);
            var referKengen = ScreenSosaUtil.CanReference(SCREEN_ID_D205060, HttpContext);

            NSKPortalInfoModel model_portal = SessionUtil.Get<NSKPortalInfoModel>(AppConst.SESS_NSK_PORTAL, HttpContext);
            if (model_portal == null)
            {
                throw new AppException("ME90003", MessageUtil.Get("ME90003"));
            }

            D205060Model model = SessionUtil.Get<D205060Model>(SESS_D205060, HttpContext);
            if (model == null)
            {
                model = new D205060Model();
                // 自画面のセッション情報が無いとき、postされたデータから処理IDを取得する
                if (HttpContext.Session.GetString("OpeId") != null)
                {
                    model.OpeId = HttpContext.Session.GetString("OpeId");
                }
                else
                {
                    model.OpeId = (string)TempData[InfraConst.MENU_POST_OPEID];
                }
                SessionUtil.Set(SESS_D205060, model, HttpContext);
            }
            else if(model != null && model.SearchCondition.IsResultDisplay)
            {
                // セッションに検索条件がある場合
                return View(SCREEN_ID_D205060, GetPageDataList(model.SearchResult.Pager?.CurrentPage, model));
            }

            // モデル状態ディクショナリからすべての項目を削除します。       
            ModelState.Clear();
            // セッション情報から検索条件、検索結果件数をクリアする            
            SessionUtil.Remove(SESS_D205060, HttpContext);

            /////////////////////////D204092で保存したパラメータ確認//////////////////////////////////
            var kyosaiMokutekiMap = new Dictionary<string, string>
            {
                { "水稲", "11" },
                { "陸稲", "20" },
                { "麦", "30" }
            };
            var data = SessionUtil.Get<D205060SearchCondition>(F205Const.SESS_D204092_DATA, HttpContext);
            D205060SearchCondition session = new D205060SearchCondition();
            if (data != null)
            {
                session.Nensan = data.Nensan;
                session.KyosaiMokuteki = data.KyosaiMokuteki;
                session.KyosaiMokutekiCd = kyosaiMokutekiMap[data.KyosaiMokuteki];
                session.KumiaitoCd = data.KumiaitoCd;
                session.TodofukenCd = data.TodofukenCd;
                session.ShishoCd = data.ShishoCd;
                session.DaichikuCd = data.DaichikuCd;
                session.ShochikuCd = data.ShochikuCd;
            }
            ////////////////////////////////////////////////////////////////////////////////////////

            model.SearchCondition.ShishoList = SetDropDownListName("支所", "");
            model.SearchCondition.DaichikuList = SetDropDownListName("大地区", "");
            model.VSyokuinRecords = getJigyoDb<NskAppContext>().VSyokuins.Where(t => t.UserId == Syokuin.UserId).Single();

            var pager = new Pagination();
            pager.CurrentPage = 0;
            pager.CurrentPageFrom = 0;
            pager.CurrentPageFrom = 0;
            model.SearchResult.Pager = pager;

            NSKPortalInfoModel md = SessionUtil.Get<NSKPortalInfoModel>(AppConst.SESS_NSK_PORTAL, HttpContext);
            if (md != null)
            {
                model.SearchCondition.KyosaiMokuteki = GetSKyosaiMokutekiCd(md.SKyosaiMokutekiCd);
                model.SearchCondition.Nensan = md.SNensanHikiuke;
                model.SearchCondition.KyosaiMokutekiCd = md.SKyosaiMokutekiCd;
                model.D205060Info.SNensanHikiuke = md.SNensanHikiuke;
                model.D205060Info.SNensanHyoka = md.SNensanHyoka;
            }
            SessionUtil.Set(SESS_D205060, model, HttpContext);

            return View(SCREEN_ID_D205060, model);
        }
        #endregion

        #region ページ分データ取得メソッド
        /// <summary>
        /// メソッド：ページ分データを取得する
        /// </summary>
        /// <param name="pageId">ページID</param>
        /// <param name="model">ビューモデル</param>
        /// <returns>検索結果モデル</returns>
        private D205060Model GetPageDataList(int? pageId, D205060Model model)
        {
            // モデル状態ディクショナリからすべての項目を削除します。
            ModelState.Clear();
            // 検索結果をクリアする
            model.SearchResult = new D205060SearchResult();
            // 検索フラグ設定
            model.SearchCondition.IsResultDisplay = true;

            // ページIDの取得（pageIdが指定されていない場合はデフォルト値1）
            int currentPageId = pageId ?? 1;

            // 検索結果表示数の取得
            // ４．１．1ページの最大表示件数は4件とする。
            var displayCount = CoreConst.PAGE_SIZE;
            int offset = Math.Max(0, displayCount * (currentPageId - 1));

            // 検索結果ページ分の取得
            var result = SelSongaihyokaYachoList(model, displayCount, offset);

            // 検索結果は0件の場合
            if (result.TableRecords.Count == 0)
            {
                model.MessageArea2 = MessageUtil.Get("MI00011");
                // 画面エラーメッセージエリアにメッセージ設定
                ModelState.AddModelError("MessageArea2", MessageUtil.Get("MI00011"));
                // 検索条件をセッションに保存する
                SessionUtil.Set(SESS_D205060, model, HttpContext);
                return model;
            }

            model.SearchResult.TableRecords = result.TableRecords;
            //model.SearchResult.TotalCount = result.TableRecords.Count;
            model.SearchResult.TotalCount = SelCntSongaihyokaQuery(model);

            foreach (var record in result.TableRecords)
            {
                //record.StrHyokaNengappi = record.支払日?.ToString("yyyy-MM-dd");
            }

            // ページャーの初期化
            model.SearchResult.Pager = new Pagination(currentPageId, displayCount, model.SearchResult.TotalCount);

            // 検索条件と検索結果をセッションに保存する
            SessionUtil.Set(SESS_D205060, model, HttpContext);

            return model;
        }
        #endregion

        #region 検索イベント
        /// <summary>
        /// イベント名：検索
        /// </summary>
        /// <param name="model">一括帳票出力モデル</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Search([Bind("SearchCondition")] D205060Model model)
        {
            var session = SessionUtil.Get<D205060Model>(SESS_D205060, HttpContext);
            // 保持している検索結果をクリアする
            if (session.SearchCondition.IsResultDisplay)
            {
                session.MessageArea2 = null;
                session.SearchCondition.IsResultDisplay = false;
                session.SearchCondition.DisplayCount = CoreConst.PAGE_SIZE; // default
            }

            // 検索して、画面に返す
            return View(SCREEN_ID_D205060, GetPageDataList(1, session));
        }
        #endregion

        #region 検索情報取得メソッド
        /// <summary>
        /// メソッド：検索情報を取得する
        /// </summary>
        /// <param name="model">ビューモデル</param>
        /// <param name="offset">範囲指定</param>
        /// <returns>検索情報</returns>
        private D205060SearchResult SelSongaihyokaYachoList(D205060Model model, int displayCount, int offset = 0)
        {
            string kyosaiMokutekiCd = model.SearchCondition.KyosaiMokutekiCd;
            string opeId = model.OpeId;
            var sql = new StringBuilder();

            sql.AppendLine($@"SELECT");
            sql.AppendLine($@"    t_21080.耕地番号,");
            sql.AppendLine($@"    t_21080.分筆番号,");
            sql.AppendLine($@"    t_12010.引受面積,");
            sql.AppendLine($@"    t_12010.地名地番,");
            sql.AppendLine($@"    t_21080.評価地区コード,");
            sql.AppendLine($@"    t_21080.申告収穫量,");
            sql.AppendLine($@"    t_21080.申告単収,");
            sql.AppendLine($@"    t_21080.被害判定コード,");
            sql.AppendLine($@"    t_21080.評価年月日,");
            sql.AppendLine($@"    t_21080.評価者,");
            sql.AppendLine($@"    t_21080.共済事故,");
            sql.AppendLine($@"    t_21080.災害種類,");
            sql.AppendLine($@"    t_21080.災害発生年月日,");
            sql.AppendLine($@"    t_21080.分割割合,");
            sql.AppendLine($@"    t_21080.分割事由,");
            if (kyosaiMokutekiCd == "30")
            {
                sql.AppendLine($@"    m_10110.用途名称,");
            }
            else
            {
                sql.AppendLine($@"    NULL AS 用途名称,");
            }
            sql.AppendLine($@"    t_21080.一筆全半判定,");
            sql.AppendLine($@"    t_21080.抜取単収 ");
            sql.AppendLine($@"FROM ");
            sql.AppendLine($@"     t_21080_農単抜取調査     t_21080 ");
            sql.AppendLine($@"INNER JOIN t_12010_引受結果       t_12010 ");
            sql.AppendLine($@"    ON t_12010.組合等コード       = t_21080.組合等コード");
            sql.AppendLine($@"    AND t_12010.年産             = t_21080.年産");
            sql.AppendLine($@"    AND t_12010.共済目的コード    = t_21080.共済目的コード");
            sql.AppendLine($@"    AND t_12010.組合員等コード    = t_21080.組合員等コード");
            sql.AppendLine($@"    AND t_12010.耕地番号         = t_21080.耕地番号 ");
            sql.AppendLine($@"    AND t_12010.分筆番号         = t_21080.分筆番号 ");
            sql.AppendLine($@"INNER JOIN t_12040_組合員等別引受情報      t_12040 ");
            sql.AppendLine($@"    ON t_12040.組合等コード       = t_21080.組合等コード");
            sql.AppendLine($@"    AND t_12040.年産             = t_21080.年産");
            sql.AppendLine($@"    AND t_12040.共済目的コード    = t_21080.共済目的コード");
            sql.AppendLine($@"    AND t_12040.組合員等コード    = t_21080.組合員等コード");
            sql.AppendLine($@"    AND t_12040.類区分           = t_21080.類区分");
            sql.AppendLine($@"INNER JOIN m_00030_区分名称               m_00030 ");
            sql.AppendLine($@"    ON m_00030.組合等コード      = t_12010.組合等コード");
            sql.AppendLine($@"    AND m_00030.年産            = t_12010.年産 ");
            sql.AppendLine($@"    AND m_00030.共済目的コード   = t_12010.共済目的コード ");
            sql.AppendLine($@"    AND m_00030.区分コード       = t_12010.区分コード ");
            if (kyosaiMokutekiCd == "30")
            {
                sql.AppendLine($@"INNER JOIN m_10110_用途区分名称       m_10110 ");
                sql.AppendLine($@"  ON m_10110.共済目的コード   = t_12010.共済目的コード");
                sql.AppendLine($@"  AND m_10110.用途区分        = t_12010.麦用途区分");
            }
            sql.AppendLine("WHERE");
            sql.AppendLine($@"    t_21080.組合等コード           = @KumiaitoCd ");
            sql.AppendLine($@"    AND t_21080.年産              = @Nensan ");
            sql.AppendLine($@"    AND t_21080.共済目的コード     = @KyosaiMokuteki ");
            sql.AppendLine($@"    AND t_21080.組合員等コード     = @KumiaiintoCd ");
            if(kyosaiMokutekiCd == "30")
            { 
                sql.AppendLine($@"    AND (@RuiKubun IS NULL OR  t_21080.類区分   = @RuiKubun) ");
            }
            sql.AppendLine($@"        AND (@Kaiso    IS NULL OR  t_21080.階層区分 = @Kaiso) ");
            sql.AppendLine($@"        AND t_12040.引受方式       = '2' ");
            sql.AppendLine($@"        AND m_00030.引受フラグ     = '1' ");
            sql.AppendLine($@"ORDER BY    t_21080.耕地番号,  t_21080.分筆番号 ");
            sql.AppendLine($@"LIMIT  @displayCount ");
            sql.AppendLine($@"OFFSET @offset ");

            var parameters = new List<NpgsqlParameter>
            {
                new("@KumiaitoCd", Syokuin.KumiaitoCd),
                new("@Nensan", int.Parse(model.SearchCondition.Nensan)),
                new("@KyosaiMokuteki", kyosaiMokutekiCd),
                new("@displayCount", displayCount),
                new("@offset", offset)
            };

            logger.Info("「損害評価野帳リスト」を取得する。");
            var record = new D205060SearchResult();
            try
            {
                record.TableRecords = getJigyoDb<NskAppContext>().Database.SqlQueryRaw<D205060TableRecord>(sql.ToString(), parameters.ToArray()).ToList();
            }
            catch (Exception e)
            {
                logger.Error(e.Message);
            }

            return record;
        }

        private int SelCntSongaihyokaQuery(D205060Model model)
        {
            string kyosaiMokutekiCd = model.SearchCondition.KyosaiMokutekiCd;
            var sql = new StringBuilder();

            sql.AppendLine("SELECT COUNT(*) ");
            sql.AppendLine("FROM   t_21080_農単抜取調査    t_21080 ");
            sql.AppendLine("INNER JOIN    t_12010_引受結果 t_12010 ");
            sql.AppendLine("        ON  t_12010.組合等コード   = t_21080.組合等コード");
            sql.AppendLine("        AND t_12010.年産          = t_21080.年産");
            sql.AppendLine("        AND t_12010.共済目的コード = t_21080.共済目的コード");
            sql.AppendLine("        AND t_12010.組合員等コード = t_21080.組合員等コード");
            sql.AppendLine("        AND t_12010.耕地番号       = t_21080.耕地番号");
            sql.AppendLine("        AND t_12010.分筆番号       = t_21080.分筆番号");
            sql.AppendLine("INNER JOIN    t_12040_組合員等別引受情報 t_12040");
            sql.AppendLine("        ON  t_12040.組合等コード   = t_21080.組合等コード");
            sql.AppendLine("        AND t_12040.年産          = t_21080.年産");
            sql.AppendLine("        AND t_12040.共済目的コード = t_21080.共済目的コード");
            sql.AppendLine("        AND t_12040.組合員等コード = t_21080.組合員等コード");
            sql.AppendLine("        AND t_12040.類区分        = t_21080.類区分");
            sql.AppendLine("INNER JOIN m_00030_区分名称 m_00030");
            sql.AppendLine("        ON  m_00030.組合等コード   = t_12010.組合等コード");
            sql.AppendLine("        AND m_00030.年産          = t_12010.年産");
            sql.AppendLine("        AND m_00030.共済目的コード = t_12010.共済目的コード");
            sql.AppendLine("        AND m_00030.区分コード     = t_12010.区分コード");
            if (kyosaiMokutekiCd == "30")
            {
                sql.AppendLine("INNER JOIN m_10110_用途区分名称 m_10110");
                sql.AppendLine("        ON m_10110.共済目的コード = t_12010.共済目的コード");
                sql.AppendLine("        AND m_10110.用途区分     = t_12010.麦用途区分");
            }
            sql.AppendLine("WHERE t_21080.組合等コード   = @KumiaitoCd");
            sql.AppendLine("  AND t_21080.年産          = @Nensan");
            sql.AppendLine("  AND t_21080.共済目的コード = @KyosaiMokuteki");
            sql.AppendLine("  AND t_21080.組合員等コード = @KumiaiintoCd");
            if (kyosaiMokutekiCd == "30")
            {
                sql.AppendLine("  AND (@RuiKubun IS NULL OR t_21080.類区分 = @RuiKubun)");
            }
            sql.AppendLine("  AND (@Kaiso IS NULL OR t_21080.階層区分 = @Kaiso)");
            sql.AppendLine("  AND t_12040.引受方式       = '2'");
            sql.AppendLine("  AND m_00030.引受フラグ     = '1'");

            var parameters = new List<NpgsqlParameter>
            {
                new("@KumiaitoCd", Syokuin.KumiaitoCd),
                new("@Nensan", int.Parse(model.SearchCondition.Nensan)),
                new("@KyosaiMokuteki", kyosaiMokutekiCd)
            };

            int res = getJigyoDb<NskAppContext>().Database.SqlQueryRaw<int>(sql.ToString(), parameters.ToArray()).ToList().FirstOrDefault();
            return res;
        }
        #endregion

        #region ドロップダウンリストデータ加工
        /// <summary>
        /// イベント名：取得したドロップダウンリストデータを加工する
        /// </summary>
        /// <returns>SelectList</returns>
        public List<SelectListItem> SetDropDownListName(string param, string code)
        {
            if (string.IsNullOrEmpty(param))
            {
                throw new ArgumentNullException(MessageUtil.Get("ME01645", "業務分類の取得"));
            }

            List<SelectListItem> selectListItem = new List<SelectListItem>();
            try
            {
                switch (param)
                {
                    case "支所":
                        IEnumerable<VShishoNm> list1 = getJigyoDb<NskAppContext>().VShishoNms.Where(data => data.TodofukenCd == Syokuin.TodofukenCd &&
                                                                                                            data.KumiaitoCd == Syokuin.KumiaitoCd).ToList();
                        foreach (var item in list1)
                        {
                            selectListItem.Add(new SelectListItem { Value = item.ShishoCd, Text = item.ShishoCd + CoreConst.SEPARATOR + item.ShishoNm });
                        }
                        break;

                    case "大地区":
                        IEnumerable<VDaichikuNm> list2 = getJigyoDb<NskAppContext>().VDaichikuNms.Where(data => data.TodofukenCd == Syokuin.TodofukenCd &&
                                                                                                                data.KumiaitoCd == Syokuin.KumiaitoCd).ToList();
                        foreach (var item in list2)
                        {
                            selectListItem.Add(new SelectListItem { Value = item.DaichikuCd, Text = item.DaichikuCd + CoreConst.SEPARATOR + item.DaichikuNm });
                        }
                        break;
                }
            }
            catch (Exception e)
            {
                logger.Error(e.Message);
            }

            return selectListItem;
        }
        #endregion

        #region 共済目的コード取得
        /// <summary>
        /// 共済目的コードを取得する
        /// </summary>
        /// <param name="SKyosaiMokutekiCd">共済目的コード</param>
        public string GetSKyosaiMokutekiCd(string SKyosaiMokutekiCd)
        {
            if (string.IsNullOrEmpty(SKyosaiMokutekiCd))
            {
                throw new ArgumentNullException(MessageUtil.Get("ME01645", "共済目的コードの取得"));
            }

            logger.Info("共済目的コード　:　" + "( " + SKyosaiMokutekiCd + " )");

            //DBから共済目的名称取得する
            M00010共済目的名称 result = getJigyoDb<NskAppContext>().M00010共済目的名称s.Where(a => a.共済目的コード == SKyosaiMokutekiCd).OrderBy(a => a.共済目的コード).FirstOrDefault();
            if (result == null)
            {
                throw new ArgumentException(SystemMessageUtil.Get("ME90003", MessageUtil.Get("ME01644", "該当の共済目的コード")));
            }
            return result.共済目的名称;
        }
        #endregion

        #region 小地区リスト取得
        /// <summary>
        /// イベント名：小地区リストを取得する
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public JsonResult SelChangeDaichiku([FromBody] ShochikuRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.TodofukenCd) ||
                string.IsNullOrEmpty(request.KumiaitoCd) || string.IsNullOrEmpty(request.DaichikuCd))
            {
                return Json(new { error = "Invalid input" });
            }

            // 小地区リストを取得
            var shochikuList = ShochikuUtil.GetShochikuList(request.TodofukenCd, request.KumiaitoCd, request.DaichikuCd);
            return Json(shochikuList);
        }
        public class ShochikuRequest
        {
            public string TodofukenCd { get; set; }
            public string KumiaitoCd { get; set; }
            public string DaichikuCd { get; set; }
        }
        #endregion

        #region 戻るイベント
        /// <summary>
        /// イベント名：戻る 
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Back()
        {
            // セッション情報から検索条件、検索結果件数をクリアする
            SessionUtil.Remove(SESS_D205060, HttpContext);

            return Json(new { result = "success" });
        }
        #endregion

        #region クリアイベント
        /// <summary>
        /// イベント名：クリア
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Clear()
        {
            // 画面区分コード
            //string opeId = SessionUtil.Get<D205060Model>(SESS_D205060, HttpContext).OpeId;

            SessionClear();

            // コード設定
            //HttpContext.Session.SetString("OpeId", opeId);
            return Json(new { result = "success" });
        }

        /// <summary>
        /// セッションをクリアする
        /// </summary>
        private void SessionClear()
        {
            // セッションをクリアする
            SessionUtil.Remove(SESS_D205060, HttpContext);
            SessionUtil.Remove(AppConst.SESS_NOGYOSHA_ID, HttpContext);
            SessionUtil.Remove(AppConst.SESS_NENDO, HttpContext);
        }
        #endregion

        #region ページャーイベント
        /// <summary>
        /// イベント名：ページャー
        /// </summary>
        /// <param name="id">ページID</param>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Pager(string id)
        {
            // ページIDは数値以外のデータの場合
            if (!Regex.IsMatch(id, @"^[0-9]+$") || PAGE_0 == id)
            {
                return BadRequest();
            }

            // セッションから加入者一覧モデルを取得する
            D205060Model model = SessionUtil.Get<D205060Model>(SESS_D205060, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model == null)
            {
                throw new SystemException(MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }

            // 検索結果を取得する
            model = GetPageDataList(int.Parse(id), model);
            // 検索条件と検索結果をセッションに保存する
            SessionUtil.Set(SESS_D205060, model, HttpContext);
            return PartialViewAsJson("_D205060SearchResult", model);
        }
        #endregion
    }
}
