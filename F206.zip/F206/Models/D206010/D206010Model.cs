﻿using CoreLibrary.Core.Base;
using CoreLibrary.Core.Validator;
using ModelLibrary.Models;
using NskWeb.Areas.F000.Models.D000000;
using System.ComponentModel;

namespace NskWeb.Areas.F206.Models.D206010
{
    [Serializable]
    public class D206010Model : CoreViewModel
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D206010Model()
        {
            this.VSyokuinRecords = new VSyokuin();
            this.D206010Info = new NSKPortalInfoModel();  // $$$$$$$$$$$$$$$$$$$
        }

        /// <summary>
        /// 職員マスタの検索結果
        /// </summary>
        public VSyokuin VSyokuinRecords { get; set; }
        public NSKPortalInfoModel D206010Info { get; set; }

        [DisplayName("メッセージエリア")]
        public string MessageArea { get; set; }

        /// <summary>
        /// 年産
        /// </summary>
        [DisplayName("年産")]
        public string Nensan { get; set; }
        /// <summary>
        /// 共済目的名称
        /// </summary>
        [DisplayName("共済目的名称")]
        public string KyosaiMokutekiMeisho { get; set; }
        /// <summary>
        /// 共済目的コード
        /// </summary>
        [DisplayName("共済目的コード")]
        public string KyosaiMokutekiCd { get; set; }
        /// <summary>
        /// 組合員等コード
        /// </summary>
        [DisplayName("組合員等コード")]
        public string KumiaiintoCd { get; set; }
        /// <summary>
        /// 組合等コード
        /// </summary>
        [DisplayName("組合等コード")]
        public string KumiaitoCd { get; set; }
        /// <summary>
        /// 氏名
        /// </summary>
        [DisplayName("氏名")]
        public string HojinFullNm { get; set; }
        /// <summary>
        /// 引受方式
        /// </summary>
        [DisplayName("引受方式")]
        public string HikiukeHousiki { get; set; }
        /// <summary>
        /// 引受方式名称
        /// </summary>
        [DisplayName("引受方式名称")]
        public string HikiukeHousikiNm { get; set; }
        /// <summary>
        /// 補償割合コード
        /// </summary>
        [DisplayName("補償割合コード")]
        public string HoshoWariaiCd { get; set; }
        /// <summary>
        /// 補償割合名称
        /// </summary>
        [DisplayName("補償割合名称")]
        public string HoshoWariaiNm { get; set; }
        /// <summary>
        /// 耕地番号
        /// </summary>
        [DisplayName("耕地番号")]
        public string KouchiNum { get; set; }
        /// <summary>
        /// 分筆番号
        /// </summary>
        [DisplayName("分筆番号")]
        public string BunpituNum { get; set; }
        /// <summary>
        /// 類区分
        /// </summary>
        [DisplayName("類区分")]
        public string RuiKbn { get; set; }
        /// <summary>
        /// 類名称
        /// </summary>
        [DisplayName("類名称")]
        public string RuiNm { get; set; }
        /// 地名地番
        /// </summary>
        [DisplayName("地名地番")]
        public string ChiNmChiNum { get; set; }
        /// <summary>
        /// 評価地区コード
        /// </summary>
        [DisplayName("評価地区コード")]
        public string HyokachikuCd { get; set; }
        /// <summary>
        /// 評価地区名
        /// </summary>
        [DisplayName("評価地区名")]
        public string HyokachikuNm { get; set; }
        /// <summary>
        /// 階層区分
        /// </summary>
        [DisplayName("階層区分")]
        public string KaisoKbn { get; set; }
        /// <summary>
        /// 階層区分名
        /// </summary>
        [DisplayName("階層区分名")]
        public string KaisoKbnNm { get; set; }
        /// <summary>
        /// 悉皆単収
        /// </summary>
        [DisplayName("悉皆単収")]
        public string ShikaiTanshu { get; set; }
        /// <summary>
        /// 申告抜取(全筆)単収
        /// </summary>
        [DisplayName("申告抜取(全筆)単収")]
        public string SinkokuNukitoriZenpitsuTanshu { get; set; }
        /// <summary>
        /// 検見単収
        /// </summary>
        [Numeric]
        [FullStringLength(3)]
        [DisplayName("検見単収")]
        public string KenmiTanshu { get; set; }

        /// <summary>
        /// 調整班区分
        /// </summary>
        [DisplayName("調整班区分")]
        public string ChoseihanKbn { get; set; }

        /// <summary>
        /// T23010.xmin
        /// </summary>
        [DisplayName("T23010xmin")]
        public uint T23010xmin { get; set; }

        /// <summary>
        /// 更新権限フラグ
        /// </summary>
        public bool UpdateKengenFlg { get; set; }

        public string TorikomiFilePath { get; set; }
    }
}