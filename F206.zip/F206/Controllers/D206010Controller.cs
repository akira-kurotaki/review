﻿using NskWeb.Common.Consts;
using CoreLibrary.Core.Attributes;
using CoreLibrary.Core.Base;
using CoreLibrary.Core.Dto;
using CoreLibrary.Core.Exceptions;
using CoreLibrary.Core.Utility;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.CodeAnalysis;
using Pipelines.Sockets.Unofficial.Arenas;
using CoreLibrary.Core.Consts;
using NskWeb.Areas.F206.Models.D206010;
using NskWeb.Areas.F000.Models.D000000;
using ModelLibrary.Models;
using NskAppModelLibrary.Models;
using NskAppModelLibrary.Context;
using NskWeb.Areas.F000.Models.D000999;
using System.IO.Compression;
using Microsoft.EntityFrameworkCore;
using NskWeb.Areas.F104.Models.D104010;
using Npgsql;
using System.Text;

namespace NskWeb.Areas.F206.Controllers
{
    /// <summary>
    /// NSK_206010D_検見野帳入力
    /// </summary>
    /// <remarks>
    /// 作成日：2025/03/25
    /// 作成者：ジョンジュンヒョ
    /// </remarks>
    [ExcludeAuthCheck]
    [AllowAnonymous]
    [Area("F206")]
    public class D206010Controller : CoreController
    {
        #region メンバー定数
        /// <summary>
        /// 画面ID(D2010)
        /// </summary>
        private static readonly string SCREEN_ID_D206010 = "D206010";

        /// <summary>
        /// セッションキー(D206010)
        /// </summary>
        private static readonly string SESS_D206010 = "D206010_SCREEN";

        private static readonly string SESS_D206021 = "D206021_SCREEN";

        #endregion



        // GET: F206/D206010/Init
        public ActionResult Init()
        {
            SessionUtil.Remove(SESS_D206010, HttpContext);
            ModelState.Clear();
            // ログインユーザの参照・更新可否判定
            // 画面IDをキーとして、画面マスタ、画面機能権限マスタを参照し、ログインユーザに本画面の権限がない場合は業務エラー画面を表示する。
            if (!ScreenSosaUtil.CanReference(SCREEN_ID_D206010, HttpContext))
            {
                throw new AppException("ME90003", MessageUtil.Get("ME90003"));
            }

            var syokuin = SessionUtil.Get<Syokuin>("_D9000_LOGIN_USER", HttpContext);
            if (syokuin == null)
            {
                ModelState.AddModelError("MessageArea", MessageUtil.Get("ME01033"));
                D000999Model d000999Model = GetInitModel();
                d000999Model.UserId = "";
                return View("D000999_Pre", d000999Model);
            }
            //// モデル初期化 D206021Model 
            D206010Model model = new D206010Model
            {
                // 「ログイン情報」を取得する
                VSyokuinRecords = getJigyoDb<NskAppContext>().VSyokuins.Where(t => t.UserId == Syokuin.UserId).Single()
            };
            var updateKengen = ScreenSosaUtil.CanUpdate(SCREEN_ID_D206010, HttpContext);
            model.UpdateKengenFlg = updateKengen;

            NSKPortalInfoModel md = SessionUtil.Get<NSKPortalInfoModel>(AppConst.SESS_NSK_PORTAL, HttpContext);
            if (md != null)
            {
                model.KyosaiMokutekiCd = md.SKyosaiMokutekiCd;
                model.Nensan = md.SNensanHikiuke;
            }

            // DB 接続情報（各環境に合わせる）
            var dbConnectionInfo = DBUtil.GetDbConnectionInfo(
                ConfigUtil.Get("SystemKbn"), syokuin.TodofukenCd, syokuin.KumiaitoCd, syokuin.ShishoCd);

            using (var db = new NskAppContext(dbConnectionInfo.ConnectionString, dbConnectionInfo.DefaultSchema))
            {
                try
                {
                    // セッションまたは他の方法で条件値を取得（例）
                    var sessionKumiaitoCd = "[セッション：組合等コード]";
                    var sessionNensan = "[セッション：引受年産]";
                    var sessionKyosaiMokutekiCd = "[セッション：共済目的コード]";
                    var sessionKumiaintoCd = "[セッション：組合員等コード]";
                    var sessionKouchiNum = "[セッション：耕地番号]";
                    var sessionBunpituNum = "[セッション：分筆番号]";
                    var sessionShoriId = "[セッション：処理id]";
                    // CASE による調整班区分の結合値を決定
                    var joinChoseihanKbn = "";
                    if (sessionShoriId == "1")
                    {
                        joinChoseihanKbn = "0";
                    }
                    else if (sessionShoriId == "4")
                    {
                        joinChoseihanKbn = "1";
                    }

                    // 複数テーブルを結合したクエリ（左外部結合含む）
                    var result = (
                        from t21040 in db.Set<T21040悉皆評価>()
                        join t12010 in db.Set<T12010引受結果>()
                            on new { t21040.組合等コード, t21040.年産, t21040.共済目的コード, t21040.組合員等コード, t21040.耕地番号, t21040.分筆番号 }
                            equals new { t12010.組合等コード, t12010.年産, t12010.共済目的コード, t12010.組合員等コード, t12010.耕地番号, t12010.分筆番号 }
                        join t12040 in db.Set<T12040組合員等別引受情報>()
                            on new { t12010.組合等コード, t12010.年産, t12010.共済目的コード, t12010.組合員等コード, t12010.類区分, t12010.統計単位地域コード }
                            equals new { t12040.組合等コード, t12040.年産, t12040.共済目的コード, t12040.組合員等コード, t12040.類区分, t12040.統計単位地域コード }
                            // 「引受回」が最新のレコードを抽出
                        where t12040.引受回 ==
                              db.Set<T12040組合員等別引受情報>()
                                .Where(x => x.組合等コード == t12010.組合等コード &&
                                            x.年産 == t12010.年産 &&
                                            x.共済目的コード == t12010.共済目的コード &&
                                            x.類区分 == t12010.類区分 &&
                                            x.組合員等コード == t12010.組合員等コード &&
                                            x.統計単位地域コード == t12010.統計単位地域コード)
                                .Max(x => x.引受回)
                        join nogyosha in db.Set<VNogyosha>()
                            on new { t21040.組合等コード, t21040.組合員等コード }
                            equals new { 組合等コード = nogyosha.KumiaitoCd, 組合員等コード = nogyosha.KumiaiintoCd }
                        join m20120 in db.Set<M20120階層区分>()
                            on new { t21040.組合等コード, t21040.年産, t21040.共済目的コード, t21040.階層区分 }
                            equals new { m20120.組合等コード, m20120.年産, m20120.共済目的コード, m20120.階層区分 }
                        join m10080 in db.Set<M10080引受方式名称>()
                            on t12040.引受方式 equals m10080.引受方式
                        join m20030 in db.Set<M20030補償割合名称>()
                            on t12040.補償割合コード equals m20030.補償割合コード
                        join m00020 in db.Set<M00020類名称>()
                            on new { t21040.共済目的コード, t21040.類区分 }
                            equals new { m00020.共済目的コード, m00020.類区分 }
                        join m20130 in db.Set<M20130評価地区>()
                            on new { t21040.組合等コード, t21040.年産, t21040.共済目的コード, t21040.評価地区コード }
                            equals new { m20130.組合等コード, m20130.年産, m20130.共済目的コード, m20130.評価地区コード }
                        join m00010 in db.Set<M00010共済目的名称>()
                            on t21040.共済目的コード equals m00010.共済目的コード
                        // LEFT JOIN t_23010_検見抜取評価
                        join t23010 in db.Set<T23010検見抜取評価>()
                        on new
                        {
                            t21040.組合等コード,
                            t21040.年産,
                            t21040.共済目的コード,
                            t21040.耕地番号,
                            t21040.分筆番号,
                            ChoseihanKbn = joinChoseihanKbn
                        }
                        equals new
                        {
                            t23010.組合等コード,
                            t23010.年産,
                            t23010.共済目的コード,
                            t23010.耕地番号,
                            t23010.分筆番号,
                            ChoseihanKbn = t23010.調整班区分
                        }
                        into t23010Group
                        from t23010 in t23010Group.DefaultIfEmpty()
                            // 条件（セッション値で絞り込み）
                        where t21040.組合等コード == sessionKumiaitoCd
                              //&& t21040.年産 == sessionNensan
                              && t21040.共済目的コード == sessionKyosaiMokutekiCd
                              && t21040.組合員等コード == sessionKumiaintoCd
                              && t21040.耕地番号 == sessionKouchiNum
                              && t21040.分筆番号 == sessionBunpituNum
                        select new D206010Model
                        {
                            // 各テーブルから取得した値を、モデルの各プロパティにマッピング
                            //Nensan = t21040.年産,
                            KumiaiintoCd = t21040.組合員等コード,
                            KouchiNum = t21040.耕地番号,
                            BunpituNum = t21040.分筆番号,
                            KyosaiMokutekiMeisho = m00010.共済目的名称,
                            HojinFullNm = nogyosha.HojinFullNm,
                            HikiukeHousiki = t12040.引受方式,
                            HikiukeHousikiNm = m10080.引受方式名称,
                            HoshoWariaiCd = t12040.補償割合コード,
                            HoshoWariaiNm = m20030.補償割合名称,
                            // 共済目的コードが "20" の場合は空白、それ以外は t21040.類区分
                            RuiKbn = m00010.共済目的コード == "20" ? " " : t21040.類区分,
                            RuiNm = m00010.共済目的コード == "20" ? " " : m00020.類名称,
                            ChiNmChiNum = t12010.地名地番,
                            HyokachikuCd = t21040.評価地区コード,
                            HyokachikuNm = m20130.評価地区名,
                            KaisoKbn = t21040.階層区分,
                            KaisoKbnNm = m20120.階層区分名,
                            ShikaiTanshu = t21040.悉皆単収.ToString(),
                            // t23010 が null の場合は "0" を返す（COALESCE 相当）
                            KenmiTanshu = t23010 == null ? "0" : t23010.検見単収.ToString(),
                            KumiaitoCd = t21040.組合等コード,
                            KyosaiMokutekiCd = t21040.共済目的コード,
                            // セッションの処理id による CASE 処理
                            ChoseihanKbn = sessionShoriId == "1" ? "0" :
                                           sessionShoriId == "4" ? "1" : null
                        }
                    ).FirstOrDefault();

                    
                }
                catch (Exception ex)
                {
                    logger.Debug(ex.StackTrace);
                    throw new AppException("MF80002", MessageUtil.Get("MF80002", "対象データ"));
                }
            }
            


            try
            {
                var kyosai = getJigyoDb<NskAppContext>().M00010共済目的名称s
                              .Where(t => t.共済目的コード == md.SKyosaiMokutekiCd)
                              .Single();

                model.KyosaiMokutekiMeisho = kyosai.共済目的名称;
            }
            catch (Exception ex)
            {
                logger.Debug(ex.StackTrace);
                throw new AppException("MF80002", MessageUtil.Get("MF80002", "共済目的"));
            }

            // 初期表示情報をセッションに保存する
            SessionUtil.Set(SESS_D206010, model, HttpContext);
            return View(SCREEN_ID_D206010, model);
        }

        #region 登録メソッド
        /// <summary>
        /// 登録イベント
        /// </summary>
        /// <param name="model">ビューモデル</param>
        /// <returns>結果メッセージ</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(D206010Model model)
        {
            //属性チェック


            var resultMessage = string.Empty;
            // ※ セッションからユーザ情報などを取得（例）
            var syokuin = SessionUtil.Get<Syokuin>(CoreConst.SESS_LOGIN_USER, HttpContext);


            // DB 接続情報（各環境に合わせる）
            var dbConnectionInfo = DBUtil.GetDbConnectionInfo(
                ConfigUtil.Get("SystemKbn"), syokuin.TodofukenCd, syokuin.KumiaitoCd, syokuin.ShishoCd);

            using (var db = new NskAppContext(dbConnectionInfo.ConnectionString, dbConnectionInfo.DefaultSchema))
            {
                var transaction = db.Database.BeginTransaction();
                try
                {
                    // 画面（または入力モデル）から値を取得（例: inputModel）
                    //var 組合等コード = model.KumiaitoCd;
                    //var 年産 = model.Nensan;
                    //var 共済目的コード = model.KyosaiMokutekiCd;
                    //var 調整班区分 = model.ChoseihanKbn;
                    //var 組合員等コード = model.KumiaiintoCd;
                    //var 耕地番号 = model.KouchiNum;
                    //var 分筆番号 = model.BunpituNum;
                    //var 検見単収 = model.KenmiTanshu;
                    //var xmin = model.T23010xmin;

                    var 組合等コード = "2";
                    var 年産 = "2";
                    var 共済目的コード = "2";
                    var 調整班区分 = "2";
                    var 組合員等コード = "2";
                    var 耕地番号 = "2";
                    var 分筆番号 = "2"  ;
                    var 検見単収 = "2";
                    uint xmin = 1;
                    int xminInt = (int)xmin;


                    // 対象レコードを検索（複合キーで検索）
                    var record = db.T23010検見抜取評価s
                        .Where(r => r.組合等コード == 組合等コード &&
                                    r.年産 == short.Parse(年産) &&
                                    r.共済目的コード == 共済目的コード &&
                                    r.調整班区分 == 調整班区分 &&
                                    r.組合員等コード == 組合員等コード &&
                                    r.耕地番号 == 耕地番号 &&
                                    r.分筆番号 == 分筆番号)
                        .SingleOrDefault();

                    if (record != null)
                    {
                        // 既存レコードが見つかった場合
                        // ※ 楽観的同時実行制御のため、xmin の比較を行います
                        if (record.Xmin != xmin)
                        {
                            resultMessage = MessageUtil.Get("ME10082");
                            transaction.Rollback();
                            return Json(new { message = resultMessage });
                        }

                        // レコードの更新
                        record.検見単収 = decimal.Parse(検見単収);
                        db.Update(record);
                    }
                    else
                    {
                        // 該当レコードが存在しない場合は新規に追加
                        var newRecord = new T23010検見抜取評価
                        {
                            組合等コード = 組合等コード,
                            年産 = short.Parse(年産),
                            共済目的コード = 共済目的コード,
                            調整班区分 = 調整班区分,
                            組合員等コード = 組合員等コード,
                            耕地番号 = 耕地番号,
                            分筆番号 = 分筆番号,
                            検見単収 = decimal.Parse(検見単収),
                        };
                        db.Add(newRecord);
                    }

                    // SaveChanges() の結果（影響を受けた行数）を取得
                    int affectedRows = db.SaveChanges();
                    if (affectedRows == 0)
                    {
                        // 更新や挿入が 0 件の場合
                        transaction.Rollback();
                        resultMessage = MessageUtil.Get("ME01645", "更新");
                        return Json(new { message = resultMessage });
                    }
                    transaction.Commit();
                }
                catch (DbUpdateConcurrencyException e)
                {
                    logger.Error(e.StackTrace);
                    transaction.Rollback();
                    resultMessage = MessageUtil.Get("ME10082");
                    return Json(new { message = resultMessage });
                }
                catch (Exception e)
                {
                    logger.Error(e.StackTrace);
                    transaction.Rollback();
                    resultMessage = MessageUtil.Get("ME01645", "更新");
                    return Json(new { message = resultMessage });
                }

            }

            resultMessage = MessageUtil.Get("MI10005");

            return Json(new { message = resultMessage });
        }
        #endregion

        #region 削除メソッド
        /// <summary>
        /// 削除イベント
        /// </summary>
        /// <param name="model">ビューモデル</param>
        /// <returns>結果メッセージ</returns>
        [HttpPost]
        public ActionResult Delete(D206010Model model)
        {
            var resultMessage = string.Empty;
            // ※ セッションからユーザ情報などを取得（例）
            var syokuin = SessionUtil.Get<Syokuin>(CoreConst.SESS_LOGIN_USER, HttpContext);


            // DB 接続情報（各環境に合わせる）
            var dbConnectionInfo = DBUtil.GetDbConnectionInfo(
                ConfigUtil.Get("SystemKbn"), syokuin.TodofukenCd, syokuin.KumiaitoCd, syokuin.ShishoCd);

            using (var db = new NskAppContext(dbConnectionInfo.ConnectionString, dbConnectionInfo.DefaultSchema))
            {
                var transaction = db.Database.BeginTransaction();
                try
                {
                    // 画面（または入力モデル）から値を取得（例: inputModel）
                    //var 組合等コード = model.KumiaiintoCd;
                    //var 年産 = model.Nensan;
                    //var 共済目的コード = model.KyosaiMokutekiCd;
                    //var 調整班区分 = model.ChoseihanKbn;
                    //var 組合員等コード = model.KumiaiintoCd;
                    //var 耕地番号 = model.KouchiNum;
                    //var 分筆番号 = model.BunpituNum;

                    var 組合等コード = "2";
                    var 年産 = "2";
                    var 共済目的コード = "2";
                    var 調整班区分 = "2";
                    var 組合員等コード = "2";
                    var 耕地番号 = "2";
                    var 分筆番号 = "2";


                    // 対象レコードを検索（複合キーで検索）
                    var record = db.T23010検見抜取評価s
                        .Where(r => r.組合等コード == 組合等コード &&
                                    r.年産 == short.Parse(年産) &&
                                    r.共済目的コード == 共済目的コード &&
                                    r.調整班区分 == 調整班区分 &&
                                    r.組合員等コード == 組合員等コード &&
                                    r.耕地番号 == 耕地番号 &&
                                    r.分筆番号 == 分筆番号)
                        .SingleOrDefault();

                    if (record == null)
                    {
                        // 該当レコードが存在しない場合
                        transaction.Rollback();
                        resultMessage = MessageUtil.Get("ME01645", "削除");
                        return Json(new { message = resultMessage });
                    }
                    // レコードの削除
                    db.Remove(record);

                    // SaveChanges() の結果（影響を受けた行数）を確認
                    int affectedRows = db.SaveChanges();
                    if (affectedRows == 0)
                    {
                        transaction.Rollback();
                        resultMessage = MessageUtil.Get("ME01645", "削除");
                        return Json(new { message = resultMessage });
                    }

                    transaction.Commit();
                }
                catch (Exception e)
                {
                    logger.Error(e.StackTrace);
                    transaction.Rollback();
                    resultMessage = MessageUtil.Get("ME01645", "削除");
                    return Json(new { message = resultMessage });
                }

            }

            resultMessage = MessageUtil.Get("MI00004", "削除");

            return Json(new { message = resultMessage });
        }
        #endregion


        #region 戻るイベント
        /// <summary>
        /// イベント名：戻る 
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Back()
        {
            // セッション情報から検索条件、検索結果件数をクリアする
            SessionUtil.Remove(SESS_D206010, HttpContext);

            return Json(new { result = "success" });
        }
        #endregion

        /// <summary>
        /// 初期モデルの取得メソッド。
        /// </summary>
        /// <returns>初期モデル</returns>
        private D000999Model GetInitModel()
        {
            D000999Model model = new D000999Model();

            List<MTodofuken> todofukenList = TodofukenUtil.GetTodofukenList().ToList();
            if (todofukenList.Count() > 0)
            {
                model.TodofukenCd = todofukenList[0].TodofukenCd;
                model.TodofukenNm = todofukenList[0].TodofukenNm;
                List<MKumiaito> kumiaitoList = KumiaitoUtil.GetKumiaitoList(model.TodofukenCd);
                if (kumiaitoList.Count() > 0)
                {
                    model.KumiaitoCd = kumiaitoList[0].KumiaitoCd;
                    model.KumiaitoNm = kumiaitoList[0].KumiaitoNm;
                    List<MShishoNm> shishoList = ShishoUtil.GetShishoList(model.TodofukenCd, model.KumiaitoCd);
                    if (shishoList.Count() > 0)
                    {
                        model.ShishoCd = shishoList[0].ShishoCd;
                        model.ShishoNm = shishoList[0].ShishoNm;
                    }
                }
            }

            model.ScreenMode = "1";

            return model;
        }

    }
}