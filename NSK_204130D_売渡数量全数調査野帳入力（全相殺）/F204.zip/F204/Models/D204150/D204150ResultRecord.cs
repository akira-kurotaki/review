﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreLibrary.Core.Validator;
using NskWeb.Common.Models;

namespace NskWeb.Areas.F204.Models.D204150
{
    //　検索結果1件分のデータ定義。テーブル1行分の内容を定義。
    public class D204150ResultRecord : BasePagerRecord
    {
        /// <summary>組合等コード</summary>
        [Display(Name = "組合等コード")]
        public string KumiaitoCd { get; set; } = string.Empty;

        /// <summary>年産</summary>
        [Display(Name = "年産")]
        public int Nensan { get; set; }

        /// <summary>共済目的コード</summary>
        [Display(Name = "共済目的コード")]
        public string KyosaiMokutekiCd { get; set; } = string.Empty;

        /// <summary>組合員等コード</summary>
        [Display(Name = "組合員等コード")]
        [NumberSign(13)]
        [Required]
        public string KumiaiintoCd { get; set; } = string.Empty;

        /// <summary>氏名</summary>
        [Display(Name = "氏名")]
        public string FullNm { get; set; } = string.Empty;

        [DisplayName("T21130xmin")]
        public uint? Xmin { get; set; }

        [NotMapped]
        public int Index { get; set; }
        //public int Index { get; set; }

        /// <summary>類短縮名称</summary>
        [Display(Name = "類短縮名称")]
        public string RuiTanshukuNm { get; set; } = string.Empty;

        /// <summary>類区分</summary>
        [Display(Name = "類区分")]
        [Required]
        public string RuiKbn { get; set; } = string.Empty;

        /// <summary>用途短縮名称</summary>
        [Display(Name = "用途短縮名称")]
        public string YoutoTanshukuNm { get; set; } = string.Empty;

        /// <summary>用途区分</summary>
        [Display(Name = "用途区分")]
        [Required]
        public string YoutoKbn { get; set; } = string.Empty;

        /// <summary>補償割合</summary>
        [Display(Name = "補償割合")]
        public string HoshoWariai { get; set; } = string.Empty;

        /// <summary>事業消費数量</summary>
        [Display(Name = "事業消費数量")]
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? JigyoShohiSuryo { get; set; }

        /// <summary>基準収穫量</summary>
        [Display(Name = "基準収穫量")]
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? KijyunSyukakuryo { get; set; }

        /// <summary>廃棄・亡失数量</summary>
        [Display(Name = "廃棄・亡失数量")]
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? HaikiSuryo { get; set; }

        /// <summary>本年収穫量</summary>
        [Display(Name = "本年収穫量")]
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? HonnenSyukakuryo { get; set; }

        /// <summary>期末棚卸数量</summary>
        [Display(Name = "期末棚卸数量")]
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? KimatsuSyukakuryo { get; set; }

        /// <summary>売渡数量</summary>
        [Display(Name = "売上数量")]
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? UriageSuryo { get; set; }

        /// <summary>期首棚卸数量</summary>
        [Display(Name = "期首棚卸数量")]
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? KishuSyukakuryo { get; set; }

        /// <summary>削除フラグ</summary>
        [Display(Name = "削除フラグ")]
        [NotMapped]
        public new bool IsDelRec { get; set; } = false;

        /// <summary>行選択（チェックボックス）</summary>
        [Display(Name = "選択")]
        [NotMapped]
        public new bool CheckSelect { get; set; } = false;

        /// <summary>
        /// srcオブジェクトとの比較
        /// </summary>
        /// <param name="src"></param>
        /// <returns></returns>
        public bool Compare(D204150ResultRecord src)
        {
            return
                KumiaiintoCd == src.KumiaiintoCd &&
                RuiKbn == src.RuiKbn &&
                YoutoKbn == src.YoutoKbn &&
                JigyoShohiSuryo == src.JigyoShohiSuryo &&
                HaikiSuryo == src.HaikiSuryo &&
                KimatsuSyukakuryo == src.KimatsuSyukakuryo &&
                UriageSuryo == src.UriageSuryo &&
                KishuSyukakuryo == src.KishuSyukakuryo;
        }
    }
}