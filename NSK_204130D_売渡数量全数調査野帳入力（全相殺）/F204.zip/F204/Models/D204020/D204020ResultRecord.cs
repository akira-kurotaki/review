﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreLibrary.Core.Validator;
using NskWeb.Common.Models;

namespace NskWeb.Areas.F204.Models.D204020
{
    //　検索結果1件分のデータ定義。テーブル1行分の内容を定義。
    public class D204020ResultRecord : BasePagerRecord
    {
        /// <summary>組合等コード</summary>
        [Display(Name = "組合等コード")]
        public string KumiaitoCd { get; set; } = string.Empty;

        /// <summary>年産</summary>
        [Display(Name = "年産")]
        public int Nensan { get; set; }

        /// <summary>共済目的コード</summary>
        [Display(Name = "共済目的コード")]
        public string KyosaiMokutekiCd { get; set; } = string.Empty;

        /// <summary>組合員等コード</summary>
        [Display(Name = "組合員等コード")]
        [NumberSign(13)]
        [Required]
        public string KumiaiintoCd { get; set; } = string.Empty;

        /// <summary>氏名</summary>
        [Display(Name = "氏名")]
        public string FullNm { get; set; } = string.Empty;

        [DisplayName("T21130xmin")]
        public uint? Xmin { get; set; }

        [NotMapped]
        public int Index { get; set; }

        /// <summary>
        /// 支所コード
        /// </summary>
        [Display(Name = "支所コード")] 
        public string ShishoCd { get; set; } = string.Empty;
        /// <summary>
        /// 支所名
        /// </summary>
        [Display(Name = "支所名")] 
        public string ShishoNm { get; set; } = string.Empty;
        /// <summary>
        /// 大地区コード
        /// </summary>
        [Display(Name = "大地区コード")]
        public string DaichikuCd { get; set; } = string.Empty;
        /// <summary>
        /// 大地区名
        /// </summary>
        [Display(Name = "大地区名")]
        public string DaichikuNm { get; set; } = string.Empty;
        /// <summary>
        /// 小地区コード
        /// </summary>
        [Display(Name = "小地区コード")]
        public string ShochikuCd { get; set; } = string.Empty;
        /// <summary>
        /// 小地区名
        /// </summary>
        [Display(Name = "小地区名")]
        public string ShochikuNm { get; set; } = string.Empty;

        /// <summary>類区分</summary>
        [Display(Name = "類区分")]
        [Required]
        public string RuiKbn { get; set; } = string.Empty;

        /// <summary>類短縮名称</summary>
        [Display(Name = "類短縮名称")]
        public string RuiTanshukuNm { get; set; } = string.Empty;

        /// <summary>収穫量確認方法</summary>
        [Display(Name = "収穫量確認方法")]
        public string SyukakuryoKakunin { get; set; } = string.Empty;

        /// <summary>全相殺計算方法</summary>
        [Display(Name = "全相殺計算方法")]
        public string ZensousaiKeisan { get; set; } = string.Empty;

        /// <summary>政府保険認定区分</summary>
        [Display(Name = "政府保険認定区分")]
        public string SeihuHokenNinkeiKbn { get; set; } = string.Empty;

        /// <summary>削除フラグ</summary>
        [Display(Name = "削除フラグ")]
        [NotMapped]
        public new bool IsDelRec { get; set; } = false;

        /// <summary>行選択（チェックボックス）</summary>
        [Display(Name = "選択")]
        [NotMapped]
        public new bool CheckSelect { get; set; } = false;

        /// <summary>
        /// srcオブジェクトとの比較
        /// </summary>
        /// <param name="src"></param>
        /// <returns></returns>
        public bool Compare(D204020ResultRecord src)
        {
            return
                KumiaiintoCd == src.KumiaiintoCd &&
                RuiKbn == src.RuiKbn;
                //YoutoKbn == src.YoutoKbn &&
                //JyutakusyatoCd == src.JyutakusyatoCd &&
                //UriwatashiSuryo == src.UriwatashiSuryo;
        }
    }
}