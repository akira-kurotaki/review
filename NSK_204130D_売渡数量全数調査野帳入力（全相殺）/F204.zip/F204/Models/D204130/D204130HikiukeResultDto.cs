using System.ComponentModel.DataAnnotations;

namespace NskWeb.Areas.F204.Models.D204130
{
    /// <summary>
    /// D204130画面 引受データ取得結果DTO（Ajax返却用）
    /// </summary>
    public class D204130HikiukeResultDto
    {
        /// <summary>組合員等氏名</summary>
        public string FullNm { get; set; } = string.Empty;

        /// <summary>補償割合</summary>
        public string HoshoWariai { get; set; } = string.Empty;

        /// <summary>基準収穫量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? KijyunSyukakuryo { get; set; }

        /// <summary>売渡数量</summary>
        [DisplayFormat(DataFormatString = "{0:0}", ApplyFormatInEditMode = true)]
        public decimal? UriwatashiSuryo { get; set; }

        /// <summary>受託者等</summary>
        public string Jyutakusyato { get; set; } = string.Empty;

        /// <summary>受託者等コード</summary>
        public string JyutakusyatoCd { get; set; } = string.Empty;

        /// <summary>Xmin</summary>
        public uint? Xmin { get; set; }
    }
}
