﻿using System.ComponentModel.DataAnnotations;
using CoreLibrary.Core.Base;
using CoreLibrary.Core.Dto;
using NskWeb.Areas.F204.Consts;

namespace NskWeb.Areas.F204.Models.D204130
{
    // 画面全体のViewModel。ヘッダ・検索条件・結果などまとめる親モデル。
    [Serializable]
    public class D204130Model : CoreViewModel
    {
        /// <summary>
        /// メッセージエリア1
        /// </summary>
        public string MessageArea1 { get; set; } = string.Empty;

        /// <summary>
        /// メッセージエリア2
        /// </summary>
        public string MessageArea2 { get; set; } = string.Empty;


        #region "ヘッダ部"
        /// <summary>
        /// 年産
        /// </summary>
        public string Nensan { get; set; } = string.Empty;
        /// <summary>
        /// 共済目的
        /// </summary>
        public string KyosaiMokuteki { get; set; } = string.Empty;
        /// <summary>
        /// 共済目的コード
        /// </summary>
        public string KyosaiMokutekiCd { get; set; } = string.Empty;
        #endregion

        #region "検索条件"
        /// <summary>
        /// 引受情報入力タブ：条件選択
        /// </summary>
        [Display(Name = "検索条件")]
        public D204130SearchCondition SearchCondition { get; set; } = new();
        #endregion

        #region "検索結果"
        /// <summary>
        /// 検索結果
        /// </summary>
        public D204130SearchResult SearchResult { get; set; } = new();
        #endregion

        /// <summary>
        /// 画面権限
        /// </summary>
        public F204Const.Authority DispKengen { get; set; } = F204Const.Authority.None;

        /// <summary>
        /// 更新権限フラグ
        /// </summary>
        public bool UpdateKengenFlg { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D204130Model() { }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public D204130Model(Syokuin syokuin, List<Shisho> shishoList)
        {
            this.SearchCondition = new(syokuin, shishoList);
        }
    }
}
