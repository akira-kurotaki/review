﻿using System.Collections.Generic;
using System.Data;
using System.Text.RegularExpressions;
using CoreLibrary.Core.Attributes;
using CoreLibrary.Core.Base;
using CoreLibrary.Core.Consts;
using CoreLibrary.Core.Exceptions;
using CoreLibrary.Core.Extensions;
using CoreLibrary.Core.Utility;
using CoreLibrary.Core.Validator;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using ModelLibrary.Models;
using NskAppModelLibrary.Context;
using NskWeb.Areas.F204.Consts;
using NskWeb.Areas.F204.Models.D204020;
using NskWeb.Areas.F204.Models.D204150;
using NuGet.Protocol.Core.Types;

namespace NskWeb.Areas.F204.Controllers
{
    [AllowAnonymous]
    [ExcludeAuthCheck]
    [Area("F204")]
    public class D204020Controller : CoreController
    {
        /// <summary>
        /// セッションキー(D204020)
        /// </summary>
        private const string SESS_D204020 = $"{F204Const.SCREEN_ID_D204020}_SCREEN";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="viewEngine"></param>
        public D204020Controller(ICompositeViewEngine viewEngine) : base(viewEngine)
        {
        }

        // GET: F204/D204020
        public ActionResult Index()
        {
            if (ConfigUtil.Get(CoreConst.D0000_DISPLAY_FLAG) == "true")
            {
                // 画面表示モードを設定
                SetScreenModeFromQueryString();

            }

            return RedirectToAction("Init", F204Const.SCREEN_ID_D204020, new { area = "F204" });
        }

        /// <summary>
        /// 初期表示
        /// </summary>
        /// <returns>加入申込書入力（水稲）画面表示結果</returns>
        public ActionResult Init()
        {

            // １．セッション情報をチェックする。
            D204020Model model = SessionUtil.Get<D204020Model>(SESS_D204020, HttpContext);

            // １．１．セッション情報が取得できなかった場合、業務エラー画面を表示する。
            if (model is not null)
            {
                // セッション検索条件 あり
                // 検索結果をセッションから削除
                SessionUtil.Remove(SESS_D204020, HttpContext);
            }

            D204020SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);
            model = new(Syokuin, sessionInfo.ShishoLists);

            // ２．ログインユーザの参照・更新可否判定
            // ２．１．画面参照可否制御
            bool dispKengen = ScreenSosaUtil.CanReference(F204Const.SCREEN_ID_D204020, HttpContext);
            bool updKengen = ScreenSosaUtil.CanUpdate(F204Const.SCREEN_ID_D204020, HttpContext);

            model.DispKengen = F204Const.Authority.None;
            model.UpdateKengenFlg = false;  // ← 初期値として false を設定

            if (updKengen)
            {
                model.DispKengen = F204Const.Authority.Update;// "更新権限";
                model.UpdateKengenFlg = true;                  // JS用
            }
            else if (dispKengen)
            {
                model.DispKengen = F204Const.Authority.ReadOnly;// "参照権限";
            }
            else
            {
                throw new AppException("ME10075", MessageUtil.Get("ME10075"));
            }

            NskAppContext dbContext = getJigyoDb<NskAppContext>();

            // ３．画面表示情報をDBから取得
            // ３．１．「共済目的名称」を取得する。
            model.KyosaiMokuteki = dbContext.M00010共済目的名称s.SingleOrDefault(x =>
                (x.共済目的コード == sessionInfo.KyosaiMokutekiCd))?.共済目的名称 ?? string.Empty;

            // ３．４．共済目的名称が取得できなかった場合
            if (string.IsNullOrWhiteSpace(model.KyosaiMokuteki))
            {
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // ３．２．「収穫量確認方法リスト」を取得する。
            model.SearchCondition.SyukakuryoKakuninLists = dbContext.M00070収穫量確認方法名称s
                .OrderBy(m => m.収穫量確認方法)
                .Select(m => new SelectListItem($"{m.収穫量確認方法} {m.収穫量確認方法名称}", $"{m.収穫量確認方法}"))
                .ToList();

            // ３．３．「全相殺計算方法リスト」を取得する。
            model.SearchCondition.ZensousaiKeisanLists = dbContext.M00060全相殺計算方法名称s
                .OrderBy(m => m.全相殺計算方法)
                .Select(m => new SelectListItem($"{m.全相殺計算方法} {m.全相殺計算方法名称}", $"{m.全相殺計算方法}"))
                .ToList();

            // 「政府保険認定区分リスト」を取得する。
            //model.SearchCondition.SeihuHokenNinkeiKbnLists = dbContext.M20160政府保険認定区分s
            //    .Where(m =>
            //        m.共済目的コード == sessionInfo.KyosaiMokutekiCd &&
            //        m.組合等コード == sessionInfo.KumiaitoCd &&
            //        m.年産 == sessionInfo.Nensan)
            //    .OrderBy(m => m.政府保険認定区分)
            //    .Select(m => new SelectListItem($"{m.政府保険認定区分} {m.短縮名称}", m.政府保険認定区分))
            //    .ToList();

            // ３．４．「３．１．～３．３．」のうちいずれかが取得できない場合、業務エラー画面を表示する。
            if (string.IsNullOrEmpty(model.KyosaiMokuteki) ||
                model.SearchCondition.SyukakuryoKakuninLists == null || !model.SearchCondition.SyukakuryoKakuninLists.Any() ||
                model.SearchCondition.ZensousaiKeisanLists == null || !model.SearchCondition.ZensousaiKeisanLists.Any())
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした")); //正しいか確認 
            }

            // 「類区分情報リスト」を取得する。
            model.SearchCondition.RuiKbnLists.AddRange(dbContext.M00020類名称s.Where(m =>
                (m.共済目的コード == sessionInfo.KyosaiMokutekiCd))?.
                OrderBy(m => m.類区分).
                Select(m => new SelectListItem($"{m.類区分} {m.類名称}", $"{m.類区分}")));
            SelectListItem ruiSelected = model.SearchCondition.RuiKbnLists.First();

            string ruiKbn = model.SearchCondition.RuiKbnLists.FirstOrDefault()?.Value ?? string.Empty;


            // ３．画面項目設定
            // ３．１．「２．」で取得した値を設定する。
            // 「２．」で取得した値は取得時にそのまま設定
            // ポータルから連係された値を設定。
            model.KyosaiMokutekiCd = sessionInfo.KyosaiMokutekiCd;
            model.Nensan = $"{sessionInfo.Nensan}";

            // ３．２．[画面：表示数]、[画面：表示順１]、[画面：表示順２]、[画面：表示順３]を設定する。
            // 表示順リストを共済目的コードごとに切り替える
            var sortList = new List<SelectListItem>();
            switch (sessionInfo.KyosaiMokutekiCd)
            {
                case "11": // 水稲
                case "30": // 麦（用途区分は使わないので水稲と同等に扱う）
                    sortList.Add(new SelectListItem { Text = "支所", Value = D204020SearchCondition.DisplaySortType.Shisyo.ToString() });
                    sortList.Add(new SelectListItem { Text = "大地区", Value = D204020SearchCondition.DisplaySortType.Daichiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "小地区", Value = D204020SearchCondition.DisplaySortType.Shochiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "組合員等コード", Value = D204020SearchCondition.DisplaySortType.KumiaiintoCd.ToString() });
                    sortList.Add(new SelectListItem { Text = "類区分", Value = D204020SearchCondition.DisplaySortType.Ruikbn.ToString() });
                    break;

                case "20": // 陸稲
                    sortList.Add(new SelectListItem { Text = "支所", Value = D204020SearchCondition.DisplaySortType.Shisyo.ToString() });
                    sortList.Add(new SelectListItem { Text = "大地区", Value = D204020SearchCondition.DisplaySortType.Daichiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "小地区", Value = D204020SearchCondition.DisplaySortType.Shochiku.ToString() });
                    sortList.Add(new SelectListItem { Text = "組合員等コード", Value = D204020SearchCondition.DisplaySortType.KumiaiintoCd.ToString() });
                    break;

                default:
                    // 何も追加しない（空リストのまま）
                    break;
            }

            // モデルに設定
            model.SearchCondition.DisplaySortLists = sortList;

            // 初期表示時、支所グループリストを持つ場合、初期選択状態を空欄に設定する。
            // [TODO] 共通部品に改修が入り処理が不要となった場合は削除をすること
            if (!model.SearchCondition.TodofukenDropDownList.ShishoList.IsNullOrEmpty())
            {
                model.SearchCondition.TodofukenDropDownList.ShishoCd = "";
            }
            else
            {
                // ３．４．支所リストが取得できなかった場合
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // ３．４．大地区リストが取得できなかった場合
            var daichikuList = DaichikuUtil.GetDaichikuList(
                model.SearchCondition.TodofukenDropDownList.TodofukenCd,
                model.SearchCondition.TodofukenDropDownList.KumiaitoCd
            );

            // 空チェックして業務エラー
            if (daichikuList == null || !daichikuList.Any())
            {
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // 検索結果を初期化（明示的に空データで構築）
            model.SearchResult = new(model.SearchCondition);

            // 政府保険認定区分リストの構築
            RebuildSeihuSelectLists(model.SearchResult.DispRecords, model.SearchResult.SeihuHokenNinkeiKbnSelectLists, dbContext, sessionInfo);

            // 政府保険認定区分リストの構築（収穫量確認方法＆類区分に応じて行単位で構築）
            //model.SearchResult.SeihuHokenNinkeiKbnSelectLists.Clear();
            //foreach (var rec in model.SearchResult.DispRecords)
            //{
            //    // デフォルトは空リストにしておく
            //    var seifuList = new List<SelectListItem>();

            //    if (!string.IsNullOrEmpty(rec.SyukakuryoKakunin))
            //    {
            //        string aoshinFlg = dbContext.M00070収穫量確認方法名称s
            //            .Where(x => x.収穫量確認方法 == rec.SyukakuryoKakunin)
            //            .Select(x => x.青申区分 == "2" ? "1" : "0")
            //            .FirstOrDefault();

            //        if (!string.IsNullOrEmpty(aoshinFlg))
            //        {
            //            seifuList = dbContext.M20160政府保険認定区分s
            //                .Where(x =>
            //                    x.組合等コード == sessionInfo.KumiaitoCd &&
            //                    x.年産 == sessionInfo.Nensan &&
            //                    x.共済目的コード == sessionInfo.KyosaiMokutekiCd &&
            //                    x.引受方式 == "3" &&
            //                    (x.共済目的コード == "20" || x.類区分 == rec.RuiKbn) &&
            //                    x.青申フラグ == aoshinFlg)
            //                .OrderBy(x => x.政府保険認定区分)
            //                .Select(x => new SelectListItem($"{x.政府保険認定区分} {x.短縮名称}", x.政府保険認定区分))
            //                .ToList();
            //        }
            //    }

            //    // 空または取得結果のいずれかを追加
            //    model.SearchResult.SeihuHokenNinkeiKbnSelectLists.Add(seifuList);
            //}

            // セッションに保存する
            SessionUtil.Set(SESS_D204020, model, HttpContext);

            ModelState.Clear();

            // 被害申告設定（全相殺）画面を表示する
            return View(F204Const.SCREEN_ID_D204020, model);        
        }

        #region ページャーイベント
        /// <summary>
        /// 検索結果ページャー
        /// </summary>
        /// <param name="id">ページID</param>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult ResultPager(string id)
        {
            // ページIDは数値以外のデータの場合
            if (!Regex.IsMatch(id, @"^[0-9]+$") || F204Const.PAGE_0 == id)
            {
                return BadRequest();
            }

            // セッションから共済金額設定モデルを取得する
            D204020Model model = SessionUtil.Get<D204020Model>(SESS_D204020, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }
            // メッセージをクリアする
            model.MessageArea1 = string.Empty;
            model.MessageArea2 = string.Empty;

            // モデル状態ディクショナリからすべての項目を削除します。
            ModelState.Clear();

            // 検索結果を取得する
            NskAppContext dbContext = getJigyoDb<NskAppContext>();
            D204020SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            // 対象ページの検索結果を取得
            model.SearchResult.GetPageDataList(dbContext, sessionInfo, int.Parse(id));

            // ✅ 政府保険認定区分リストを再構築
            RebuildSeihuSelectLists(
                model.SearchResult.DispRecords,
                model.SearchResult.SeihuHokenNinkeiKbnSelectLists,
                dbContext,
                sessionInfo
            );

            model.SearchResult.Reindex();

            // 検索条件と検索結果をセッションに保存する
            SessionUtil.Set(SESS_D204020, model, HttpContext);

            return PartialViewAsJson("_D204020SearchResult", model);
        }
        #endregion

        /// <summary>
        /// 共済金額設定を検索する。													
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Search(D204020Model dispModel)
        {
            Console.WriteLine("Search呼ばれた");

            D204020SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            // セッションから加入申込書入力（水稲）モデルを取得する
            D204020Model model = SessionUtil.Get<D204020Model>(SESS_D204020, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }

            // 画面入力値 → モデルに反映
            model.SearchCondition.ApplyInput(dispModel.SearchCondition);
            // 結果表示フラグ 初期化
            model.SearchCondition.IsResultDisplay = false;

            // 検索結果クリア
            model.SearchResult = new(model.SearchCondition);
            // メッセージクリア
            model.MessageArea1 = string.Empty;
            model.MessageArea2 = string.Empty;
            ModelState.Clear();

            // ２．入力チェック
            // ２．１．属性チェック
            // 画面入力値をセッションモデルに反映
            model.SearchCondition.ApplyInput(dispModel.SearchCondition);
            // 必須チェック用クラス
            InputRequiredAttribute isInputRequired = new InputRequiredAttribute();

            // 組合員等コード（開始）
            if (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdFrom))
            {
                // 入力ありの場合属性チェック
                // 半角数値チェック用クラス
                NumericAttribute isNumeric = new NumericAttribute();
                // 桁数チェック用クラス
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                if (!isNumeric.IsValid(model.SearchCondition.KumiaiinToCdFrom))
                {
                    // 半角数値チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isNumeric.FormatErrorMessage("組合員等コード（開始）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                } 
                else if (!isDigitLength.IsValid(model.SearchCondition.KumiaiinToCdFrom))
                {
                    // 桁数チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isDigitLength.FormatErrorMessage("組合員等コード（開始）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
            }
            // 組合員等コード（終了）
            if (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdTo))
            {
                // 入力ありの場合属性チェック
                // 半角数値チェック用クラス
                NumericAttribute isNumeric = new NumericAttribute();
                // 桁数チェック用クラス
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                if (!isNumeric.IsValid(model.SearchCondition.KumiaiinToCdTo))
                {
                    // 半角数値チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isNumeric.FormatErrorMessage("組合員等コード（終了）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
                else if (!isDigitLength.IsValid(model.SearchCondition.KumiaiinToCdTo))
                {
                    // 桁数チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isDigitLength.FormatErrorMessage("組合員等コード（終了）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
            }

            // ２．２．独自チェック
            // ２．２．１．[画面：小地区（終了）]<[画面：小地区（開始）]の場合、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            if ((!string.IsNullOrEmpty(model.SearchCondition.TodofukenDropDownList.ShochikuCdFrom) &&
                (!string.IsNullOrEmpty(model.SearchCondition.TodofukenDropDownList.ShochikuCdTo))) &&
                (model.SearchCondition.TodofukenDropDownList.ShochikuCdFrom.CompareTo(
                 model.SearchCondition.TodofukenDropDownList.ShochikuCdTo) > 0))
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME10020", "小地区");

                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }

            // (２．２．２．[画面：組合員等コード（終了）]<[画面：組合員等コード（開始）]の場合、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            if ((!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdFrom) &&
                (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdTo))) &&
                (model.SearchCondition.KumiaiinToCdFrom.CompareTo(
                 model.SearchCondition.KumiaiinToCdTo) > 0))
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME10020", "組合員等コード");

                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }


            // ２．２．３．［画面：表示順］の選択値に重複がある場合（以下のいずれかの条件に該当する場合）、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            List<D204020SearchCondition.DisplaySortType> sortTypes = new List<D204020SearchCondition.DisplaySortType>();

            // ［画面：表示順］が選択されている場合、配列に格納
            if (model.SearchCondition.DisplaySort1.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort1.Value);
            }
            if (model.SearchCondition.DisplaySort2.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort2.Value);
            }
            if (model.SearchCondition.DisplaySort3.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort3.Value);
            }

            // 配列に格納した表示順の件数と重複除外した件数が一致するか判定し
            // 判定しない場合は重複と判断しエラーと判定する
            bool hasDuplicates = sortTypes.Count != sortTypes.Distinct().Count();

            if (hasDuplicates)
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME90018", "表示順");
                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }

            // 表示数の設定
            model.SearchResult.DisplayCount = model.SearchCondition.DisplayCount ?? CoreConst.PAGE_SIZE; ;

            // 共済目的コードに応じて不要なバリデーションを無効化
            var sortList = new List<SelectListItem>();

            switch (sessionInfo.KyosaiMokutekiCd)
            {
                case "11": // 水稲
                    sortList.Add(new SelectListItem("支所", D204020SearchCondition.DisplaySortType.Shisyo.ToString()));
                    sortList.Add(new SelectListItem("大地区", D204020SearchCondition.DisplaySortType.Daichiku.ToString()));
                    sortList.Add(new SelectListItem("小地区", D204020SearchCondition.DisplaySortType.Shochiku.ToString()));
                    sortList.Add(new SelectListItem("組合員等コード", D204020SearchCondition.DisplaySortType.KumiaiintoCd.ToString()));
                    break;

                case "30": // 麦
                    sortList.Add(new SelectListItem("類区分", D204020SearchCondition.DisplaySortType.Ruikbn.ToString()));
                    sortList.Add(new SelectListItem("用途区分", D204020SearchCondition.DisplaySortType.YoutoKbn.ToString()));
                    sortList.Add(new SelectListItem("組合員等コード", D204020SearchCondition.DisplaySortType.KumiaiintoCd.ToString()));
                    break;
            }

            // ２．３．「メッセージリスト」のメッセージの有無で下記の処理を行う。
            if (ModelState.IsValid)
            {
                // ３．データ検索SQLを実行（ログ出力：あり）
                // ３．１．「検索結果情報リスト」を取得する。
                NskAppContext dbContext = getJigyoDb<NskAppContext>();
                model.SearchResult.GetPageDataList(dbContext, sessionInfo, F204Const.PAGE_1);

                // データ取得失敗時のチェック
                if (model.SearchResult.DispRecords == null)
                {
                    model.MessageArea2 = MessageUtil.Get("ME01645", "データの取得");
                    ModelState.AddModelError("MessageArea2", model.MessageArea2);

                    return Json(new
                    {
                        resultArea = "",
                        messageArea2 = ModelState["MessageArea2"]
                    });
                }

                // ★ここでログ出力
                Console.WriteLine($"[Search] 検索件数: {model.SearchResult.AllRecCount}");
                foreach (var rec in model.SearchResult.DispRecords)
                {
                    Console.WriteLine($"[Search] 組合員コード: {rec.KumiaiintoCd}, 氏名: {rec.FullNm}");
                }
                model.SearchResult.Reindex();

                // 行ごとの政府保険認定区分リストを構築
                //model.SearchResult.GetPageDataList(dbContext, sessionInfo, 1);
                RebuildSeihuSelectLists(model.SearchResult.DispRecords, model.SearchResult.SeihuHokenNinkeiKbnSelectLists, dbContext, sessionInfo);

                // --- ✅ 調査用ログ出力ここから ---
                Console.WriteLine($"[再構築後の確認] DispRecords.Count = {model.SearchResult.DispRecords.Count}");
                Console.WriteLine($"[再構築後の確認] SeihuHokenNinkeiKbnSelectLists.Count = {model.SearchResult.SeihuHokenNinkeiKbnSelectLists.Count}");

                for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
                {
                    var disp = model.SearchResult.DispRecords[i];
                    var list = model.SearchResult.SeihuHokenNinkeiKbnSelectLists.ElementAtOrDefault(i);
                    var selected = disp.SeihuHokenNinkeiKbn ?? "(null)";
                    Console.WriteLine($"[表示確認] 行{i}: SeihuHokenKbn={selected}, List件数={list?.Count ?? -1}");
                }
                // --- ✅ 調査用ログ出力ここまで ---

                // Index を再設定
                model.SearchResult.Reindex();

                // ４．検索結果の表示
                if (model.SearchResult.AllRecCount == 0)
                {
                    // エラーメッセージを「メッセージエリア２」に設定する。
                    model.MessageArea2 = MessageUtil.Get("MI00011");
                    ModelState.AddModelError("MessageArea2", model.MessageArea2);
                }

                // 結果表示フラグON
                model.SearchCondition.IsResultDisplay = true;
            }

            // ５．検索条件、検索結果件数の保持
            // ５．１．検索条件、検索結果件数をセッションに保存する。
            SessionUtil.Set(SESS_D204020, model, HttpContext);

            JsonResult resultArea = PartialViewAsJson("_D204020SearchResult", model);

            // ６．画面操作制御区分による表示
            // ６．１．画面操作制御区分により、下表の画面項目の活性制御を行う。

            return Json(new { resultArea = resultArea.Value, messageArea1 = ModelState["MessageArea1"], messageArea2 = ModelState["MessageArea2"] });
        }

        #region 登録イベント

        /// <summary>
        /// 共済金額設定を登録
        /// </summary>
        /// <returns></returns>
        public ActionResult Insert(D204020Model dispModel)
        {
            IDbContextTransaction? transaction = null;
            string errMessage = string.Empty;
            try
            {
                D204020SessionInfo sessionInfo = new();
                sessionInfo.GetInfo(HttpContext);

                // セッションからモデルを取得
                D204020Model model = SessionUtil.Get<D204020Model>(SESS_D204020, HttpContext);
                if (model is null)
                {
                    throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
                }

                Console.WriteLine("▼▼ CheckSelect / IsDelRec / IsNewRec 状態（確認用） ▼▼");
                for (int i = 0; i < dispModel.SearchResult.DispRecords.Count; i++)
                {
                    var rec = dispModel.SearchResult.DispRecords[i];
                    Console.WriteLine($"[Post] Index={i}, CheckSelect={rec.CheckSelect}, IsDelRec={rec.IsDelRec}, IsNewRec={rec.IsNewRec}");
                }
                Console.WriteLine("▲▲ CheckSelect / IsDelRec / IsNewRec 状態（確認完了） ▲▲");

                // ApplyInputの前に、IsNewRec=true のIndexを保存
                var newRecIndexes = dispModel.SearchResult.DispRecords
                    .Select((r, idx) => new { r.IsNewRec, idx })
                    .Where(x => x.IsNewRec)
                    .Select(x => x.idx)
                    .ToHashSet(); // ← Set型で高速アクセス

                // 画面入力値をセッションモデルに反映
                model.SearchResult.ApplyInput(dispModel.SearchResult);

                foreach (var rec in model.SearchResult.DispRecords.Select((r, i) => new { r, i }))
                {
                    rec.r.IsNewRec = newRecIndexes.Contains(rec.i);
                }

                // 削除フラグ設定
                ApplyCheckSelectToDeleteFlag(model.SearchResult.DispRecords);

                // 再確認ログ（ApplyInput 後）
                Console.WriteLine("▼▼ ApplyInput 後のモデル状態 ▼▼");
                for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
                {
                    var rec = model.SearchResult.DispRecords[i];
                    Console.WriteLine($"[Model] Index={i}, CheckSelect={rec.CheckSelect}, IsDelRec={rec.IsDelRec}, IsNewRec={rec.IsNewRec}");
                }
                Console.WriteLine("▲▲ ApplyInput 後のモデル状態（確認完了） ▲▲");

                // 重複チェック（組合員等コード、類区分）
                // 類区分：水稲・麦
                var duplicates = model.SearchResult.DispRecords
                    .Where(x => !x.IsDelRec) // 削除対象除外
                    .GroupBy(x => new
                    {
                        x.KumiaiintoCd,
                        RuiKbn = (model.KyosaiMokutekiCd == "11" || model.KyosaiMokutekiCd == "30") ? x.RuiKbn : null
                    })
                    .Where(g => g.Count() > 1)
                    .ToList();

                if (duplicates.Any())
                {
                    errMessage = MessageUtil.Get("ME90018", "入力内容");
                    model.MessageArea2 = errMessage;
                    ModelState.AddModelError("MessageArea2", errMessage);
                    throw new AppException("ME90018", errMessage);
                }

                // 属性チェック
                InputRequiredAttribute isInputRequired = new InputRequiredAttribute();
                NumericAttribute isNumeric = new NumericAttribute();
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                string mokutekiCd = model.KyosaiMokutekiCd;

                // === 必須チェック・0自動セット ===
                foreach (var rec in model.SearchResult.DispRecords)
                {
                    if (rec.IsDelRec) continue;
                    if (!rec.IsNewRec) continue; // 新規登録のみ

                    // 必須・0自動セット分岐
                    switch (mokutekiCd)
                    {
                        case "20": // 陸稲
                                   // 必須：組合員等コード
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            // 数値/桁数チェックも既存同様
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            // 0自動セット
                            rec.RuiKbn = "0";
                            break;

                        case "11": // 水稲
                                   // 必須：組合員等コード、類区分
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            if (!isInputRequired.IsValid(rec.RuiKbn))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("類区分");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }

                            break;

                        case "30": // 麦
                                   // 必須：組合員等コード、類区分、用途区分（現状どおり）
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            if (!isInputRequired.IsValid(rec.RuiKbn))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("類区分");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            break;
                    }
                }

                // トランザクション開始
                NskAppContext dbContext = getJigyoDb<NskAppContext>();
                transaction = dbContext.Database.BeginTransaction();

                var delRecords = model.SearchResult.GetDeleteRecs();

                Console.WriteLine($"【削除候補件数】{delRecords.Count}");
                foreach (var rec in delRecords)
                {
                    Console.WriteLine($"削除対象: Index={rec.Index}, KumiaiintoCd={rec.KumiaiintoCd}, IsDelRec={rec.IsDelRec}, IsNewRec={rec.IsNewRec}");
                }

                int delCount = 0;
                if (delRecords.Count > 0)
                {
                    delCount += model.SearchResult.DeleteUriwatashi(ref dbContext, sessionInfo, ref delRecords);
                }

                model.SearchResult.Reindex();

                int updCount = 0;
                List<D204020ResultRecord> updRecords = model.SearchResult.GetUpdateRecs(ref dbContext, sessionInfo);
                if (updRecords.Count > 0)
                {
                    updCount += model.SearchResult.UpdateUriwatashi(
                        ref dbContext,
                        sessionInfo,
                        GetUserId(),
                        DateUtil.GetSysDateTime(),
                        ref updRecords);
                }

                int insCount = 0;
                List<D204020ResultRecord> addRecords = model.SearchResult.GetAddRecs();
                if (addRecords.Count > 0)
                {
                    insCount += model.SearchResult.AppendUriwatashi(
                        ref dbContext,
                        sessionInfo,
                        GetUserId(),
                        DateUtil.GetSysDateTime(),
                        ref addRecords);
                }

                foreach (var rec in model.SearchResult.DispRecords)
                {
                    rec.IsNewRec = false;
                }

                if (delCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "削除");
                }
                if (updCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "更新");
                }
                if (insCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "登録");
                }
                if (delCount == 0 && updCount == 0 && insCount == 0)
                {
                    errMessage = MessageUtil.Get("MI00012");
                }

                transaction.CommitAsync();

                SessionUtil.Set(SESS_D204020, model, HttpContext);
            }
            catch (Exception ex)
            {
                transaction?.RollbackAsync();

                if (string.IsNullOrEmpty(errMessage))
                {
                    if (ex is DBConcurrencyException)
                    {
                        errMessage = !string.IsNullOrEmpty(ex.Message)
                            ? MessageUtil.Get(ex.Message)
                            : MessageUtil.Get("ME10081");
                    }
                    else if (ex is DbUpdateException)
                    {
                        errMessage = MessageUtil.Get("ME10081");
                    }
                    else
                    {
                        errMessage = MessageUtil.Get("MF00001");
                    }
                }
            }

            return Json(new { message = errMessage });
        }

        #endregion


        #region 戻るイベント
        /// <summary>
        /// 戻る
        /// ポータルへ遷移する。
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Back()
        {
            // ポータル

            return Json(new { result = "success" });
        }
        #endregion


        /// <summary>
        /// 組合員等名更新
        /// </summary>
        /// <param name="kumiaiintoCd">組合員等コード</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult UpdateKumiaiintoName(string kumiaiintoCd)
        {
            // 組合員等名を取得 
            // t_農業者情報から「組合員等コード」に該当する「氏名又は法人名」を取得する。
            D204020SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);
            NskAppContext dbContext = getJigyoDb<NskAppContext>();
            VNogyosha? kumiaiinto = dbContext.VNogyoshas.SingleOrDefault(x =>
                (x.TodofukenCd == sessionInfo.TodofukenCd) &&
                (x.KumiaitoCd == sessionInfo.KumiaitoCd) &&
                (x.KumiaiintoCd == kumiaiintoCd)
                );
            string kumiaiintoNm = kumiaiinto?.HojinFullNm ?? string.Empty;

            // 「組合員等名」をJSON化して返送する。
            return Json(new { kumiaiintoNm });
        }

        /// <summary>
        /// 指定された収穫量確認方法および類区分に基づき、
        /// 政府保険認定区分のドロップダウンリスト（SelectListItem）を構築する。
        /// 以下の条件に合致するレコードを M20160 テーブルから抽出：
        /// ・組合等コード、年産、共済目的コード が一致
        /// ・引受方式 = 3（全相殺）
        /// ・青申フラグ（m_00070から導出）
        /// ・共済目的が水稲 or 麦（共済目的コード ≠ 20）の場合、類区分による絞り込みあり
        /// </summary>
        /// <param name="dbContext">データベースコンテキスト</param>
        /// <param name="sessionInfo">セッション情報（年産、共済目的コードなど）</param>
        /// <param name="syukakuryo">収穫量確認方法</param>
        /// <param name="ruiKbn">類区分</param>
        /// <returns>ドロップダウン用のリスト（value, text）形式</returns>
        private List<SelectListItem> BuildSeihuHokenNinteiList(NskAppContext dbContext, D204020SessionInfo sessionInfo, string syukakuryo, string ruiKbn)
        {
            // 収穫量確認方法が未指定の場合は空リストを返却
            if (string.IsNullOrEmpty(syukakuryo)) return new();

            // 青申区分（m_00070）から「青申フラグ」（2→1, その他→0）を判定
            string aoshinFlg = dbContext.M00070収穫量確認方法名称s
                .Where(x => x.収穫量確認方法 == syukakuryo)
                .Select(x => x.青申区分 == "2" ? "1" : "0")
                .FirstOrDefault();

            if (string.IsNullOrEmpty(aoshinFlg)) return new();

            // 条件に合致する政府保険認定区分レコードを抽出し、ドロップダウンリストに変換
            return dbContext.M20160政府保険認定区分s
                .Where(x =>
                    x.組合等コード == sessionInfo.KumiaitoCd &&
                    x.年産 == sessionInfo.Nensan &&
                    x.共済目的コード == sessionInfo.KyosaiMokutekiCd &&
                    x.引受方式 == "3" &&
                    (x.共済目的コード == "20" || x.類区分 == ruiKbn) &&
                    x.青申フラグ == aoshinFlg)
                .OrderBy(x => x.政府保険認定区分)
                .Select(x => new SelectListItem($"{x.政府保険認定区分} {x.短縮名称}", x.政府保険認定区分))
                .ToList();
        }

        /// <summary>
        /// 指定された結果行ごとに、「政府保険認定区分」のドロップダウンリストを再構築し、
        /// `selectLists` に1行ずつ対応する形で格納する。
        /// （初期表示・検索・行追加のたびに呼び出されることを想定）
        /// </summary>
        /// <param name="records">検索結果や追加行のデータ</param>
        /// <param name="selectLists">行ごとのドロップダウンリスト（出力先）</param>
        /// <param name="dbContext">データベースコンテキスト</param>
        /// <param name="sessionInfo">セッション情報</param>
        private void RebuildSeihuSelectLists(
            List<D204020ResultRecord> records,
            List<List<SelectListItem>> selectLists,
            NskAppContext dbContext,
            D204020SessionInfo sessionInfo)
        {
            // 出力リストを初期化
            selectLists.Clear();

            // 各行に対し、該当条件でドロップダウンリストを生成・追加
            foreach (var rec in records)
            {
                var list = BuildSeihuHokenNinteiList(dbContext, sessionInfo, rec.SyukakuryoKakunin, rec.RuiKbn);
                selectLists.Add(list);
            }
        }

        /// <summary>
        /// （JavaScriptなどからのAjax呼び出し用）
        /// 指定行の収穫量確認方法・類区分に応じた「政府保険認定区分リスト」を JSON 形式で返却する。
        /// 主に画面で収穫量確認方法や類区分が変更されたときに呼び出される。
        /// </summary>
        /// <param name="rowIndex">行インデックス（どの行にセットするかの識別用）</param>
        /// <param name="syukakuryo">収穫量確認方法</param>
        /// <param name="ruiKbn">類区分</param>
        /// <returns>行番号 + ドロップダウンリスト（value, text）のJSON</returns>
        [HttpPost]
        public ActionResult GetSeihuHokenNinteiList(int rowIndex, string syukakuryo, string ruiKbn)
        {
            // セッション情報の取得（年産、共済目的コード、組合等コードなど）
            var sessionInfo = new D204020SessionInfo();
            sessionInfo.GetInfo(HttpContext);

            using var dbContext = getJigyoDb<NskAppContext>();

            // 共通関数を使ってドロップダウンリスト構築
            var list = BuildSeihuHokenNinteiList(dbContext, sessionInfo, syukakuryo, ruiKbn);

            // JSON形式で返却（クライアントで value/text に使える形式）
            var jsonList = list.Select(x => new { value = x.Value, text = x.Text }).ToList();
            return Json(new { rowIndex, list = jsonList });
        }

        /// <summary>
        /// CheckSelect が true の行に対して IsDelRec = true を設定する
        /// </summary>
        private void ApplyCheckSelectToDeleteFlag(List<D204020ResultRecord> dispRecords)
        {
            for (int i = 0; i < dispRecords.Count; i++)
            {
                var rec = dispRecords[i];
                if (rec.CheckSelect)
                {
                    rec.IsDelRec = true;
                    Console.WriteLine($"[削除フラグ設定] Index={i}, 組合員等コード={rec.KumiaiintoCd}");
                }
            }
        }

        /// <summary>
        /// POSTされたチェック状態（CheckSelect）をセッション側に反映する共通メソッド（Indexベース）
        /// 削除済み行も含め、Indexに一致する行のCheckSelectを上書きする。
        /// </summary>
        private void ApplyCheckSelectFromPost(List<D204020ResultRecord> from, List<D204020ResultRecord> to)
        {
            foreach (var postRow in from)
            {
                int idx = postRow.Index;
                if (idx < to.Count)
                {
                    Console.WriteLine($"★ApplyCheckSelect: Index={idx}, FromPost={postRow.CheckSelect}");
                    to[idx].CheckSelect = postRow.CheckSelect;
                }
            }
        }

        /// <summary>
        /// 指定された部分ビューをHTML文字列としてレンダリングします。
        /// JavaScriptからのAjaxで部分更新するために使用します。
        /// </summary>
        /// <param name="viewName">部分ビューの名前（例：_D204020SearchResult）</param>
        /// <param name="model">ビューに渡すモデルオブジェクト</param>
        /// <returns>レンダリングされたHTML文字列</returns>
        protected string RenderPartialViewToString(string viewName, object model)
        {
            ViewData.Model = model;

            using var sw = new StringWriter();

            // ビューを探す（注：ViewEngineではなく _viewEngine）
            var viewResult = _viewEngine.FindView(ControllerContext, viewName, false);
            if (viewResult.View == null)
            {
                throw new ArgumentNullException($"ビュー '{viewName}' が見つかりません。");
            }

            var viewContext = new ViewContext(
                ControllerContext,
                viewResult.View,
                ViewData,
                TempData,
                sw,
                new HtmlHelperOptions()
            );

            viewResult.View.RenderAsync(viewContext).Wait();

            return sw.ToString();
        }
    }
}
