﻿using System.Collections.Generic;
using System.Data;
using System.Text.RegularExpressions;
using CoreLibrary.Core.Attributes;
using CoreLibrary.Core.Base;
using CoreLibrary.Core.Consts;
using CoreLibrary.Core.Exceptions;
using CoreLibrary.Core.Extensions;
using CoreLibrary.Core.Utility;
using CoreLibrary.Core.Validator;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using ModelLibrary.Models;
using Npgsql;
using NpgsqlTypes;
using NskAppModelLibrary.Context;
using NskWeb.Areas.F204.Consts;
using NskWeb.Areas.F204.Models.D204150;
using NuGet.Protocol.Core.Types;

namespace NskWeb.Areas.F204.Controllers
{
    [AllowAnonymous]
    [ExcludeAuthCheck]
    [Area("F204")]
    public class D204150Controller : CoreController
    {
        /// <summary>
        /// セッションキー(D204150)
        /// </summary>
        private const string SESS_D204150 = $"{F204Const.SCREEN_ID_D204150}_SCREEN";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="viewEngine"></param>
        public D204150Controller(ICompositeViewEngine viewEngine) : base(viewEngine)
        {
        }

        // GET: F204/D204150
        public ActionResult Index()
        {
            if (ConfigUtil.Get(CoreConst.D0000_DISPLAY_FLAG) == "true")
            {
                // 画面表示モードを設定
                SetScreenModeFromQueryString();

            }

            return RedirectToAction("Init", F204Const.SCREEN_ID_D204150, new { area = "F204" });
        }

        /// <summary>
        /// 初期表示
        /// </summary>
        /// <returns>加入申込書入力（水稲）画面表示結果</returns>
        public ActionResult Init()
        {

            // １．セッション情報をチェックする。
            // １．１．セッション情報が取得できなかった場合、業務エラー画面を表示する。
            D204150Model model = SessionUtil.Get<D204150Model>(SESS_D204150, HttpContext);

            if (model is not null)
            {
                // セッション検索条件 あり
                // 検索結果をセッションから削除
                SessionUtil.Remove(SESS_D204150, HttpContext);
            }

            D204150SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);
            model = new(Syokuin, sessionInfo.ShishoLists);

            // ２．ログインユーザの参照・更新可否判定
            // ２．１．画面参照可否制御
            // ログインユーザの権限が「参照」「更新権限」いずれも許可されていない場合、メッセージを設定し業務エラー画面を表示する。
            bool dispKengen = ScreenSosaUtil.CanReference(F204Const.SCREEN_ID_D204150, HttpContext);
            bool updKengen = ScreenSosaUtil.CanUpdate(F204Const.SCREEN_ID_D204150, HttpContext);

            model.DispKengen = F204Const.Authority.None;
            model.UpdateKengenFlg = false;  // ← 初期値として false を設定

            if (updKengen)
            {
                model.DispKengen = F204Const.Authority.Update;// "更新権限";
                model.UpdateKengenFlg = true;                  // JS用
            }
            else if (dispKengen)
            {
                model.DispKengen = F204Const.Authority.ReadOnly;// "参照権限";
            }
            else
            {
                throw new AppException("ME10075", MessageUtil.Get("ME10075"));
            }

            NskAppContext dbContext = getJigyoDb<NskAppContext>();

            // ３．画面表示情報をDBから取得
            // ３．１．「共済目的名称」を取得する。
            model.KyosaiMokuteki = dbContext.M00010共済目的名称s.SingleOrDefault(x =>
                (x.共済目的コード == sessionInfo.KyosaiMokutekiCd))?.共済目的名称 ?? string.Empty;

            // ３．４．共済目的名称が取得できなかった場合
            if (string.IsNullOrWhiteSpace(model.KyosaiMokuteki))
            {
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // 「類区分情報リスト」を取得する。
            model.SearchCondition.RuiKbnLists.AddRange(dbContext.M00020類名称s.Where(m =>
                (m.共済目的コード == sessionInfo.KyosaiMokutekiCd))?.
                OrderBy(m => m.類区分).
                Select(m => new SelectListItem($"{m.類区分} {m.類名称}", $"{m.類区分}")));
            SelectListItem ruiSelected = model.SearchCondition.RuiKbnLists.First();

            // 「用途区分リスト」を取得する。 （共済目的コードでフィルタ）
            // 用途区分リストの構築
            model.SearchCondition.YoutoKbnLists = dbContext.M10110用途区分名称s
                .Where(m => m.共済目的コード == sessionInfo.KyosaiMokutekiCd)
                .OrderBy(m => m.用途区分)
                .Select(m => new SelectListItem($"{m.用途区分} {m.用途名称}", $"{m.用途区分}"))
                .ToList();

            // ※選択状態が必要なら（類区分と同様に）先頭をselectedにすることも可能
            var youtoSelected = model.SearchCondition.YoutoKbnLists.FirstOrDefault();

            // ３．２．「支所リスト」を取得する。
            // 共通部品にて支所は取得されるため取得不要
            // 初期表示時、支所グループリストを持つ場合、初期選択状態を空欄に設定する。
            // [TODO] 共通部品に改修が入り処理が不要となった場合は削除をすること
            if (!model.SearchCondition.TodofukenDropDownList.ShishoList.IsNullOrEmpty())
            {
                model.SearchCondition.TodofukenDropDownList.ShishoCd = "";
            }
            else
            {
                // ３．４．支所リストが取得できなかった場合
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // ３．３．「大地区リスト」を取得する。
            var daichikuList = DaichikuUtil.GetDaichikuList(
                model.SearchCondition.TodofukenDropDownList.TodofukenCd,
                model.SearchCondition.TodofukenDropDownList.KumiaitoCd
            );

            // ３．４．大地区リストが取得できなかった場合
            // 空チェックして業務エラー
            if (daichikuList == null || !daichikuList.Any())
            {
                throw new AppException("MF00001", MessageUtil.Get("MF00001"));
            }

            // 画面項目設定
            // ポータルから連係された値を設定。
            model.KyosaiMokutekiCd = sessionInfo.KyosaiMokutekiCd;
            model.Nensan = $"{sessionInfo.Nensan}";

            // [画面：表示数]、[画面：表示順１]、[画面：表示順２]、[画面：表示順３]を設定する。
            // 表示順リストを共済目的コードごとに切り替える
            // ３．３．表示順リストを設定する。（共済目的コードに関係なく固定）
            model.SearchCondition.DisplaySortLists = new List<SelectListItem>
            {
                new SelectListItem { Text = "支所", Value = D204150SearchCondition.DisplaySortType.Shisyo.ToString() },
                new SelectListItem { Text = "大地区", Value = D204150SearchCondition.DisplaySortType.Daichiku.ToString() },
                new SelectListItem { Text = "小地区", Value = D204150SearchCondition.DisplaySortType.Shochiku.ToString() },
                new SelectListItem { Text = "組合員等コード", Value = D204150SearchCondition.DisplaySortType.KumiaiintoCd.ToString() }
            };

            // 検索結果を初期化（明示的に空データで構築）
            model.SearchResult = new(model.SearchCondition);

            // セッションに保存する
            SessionUtil.Set(SESS_D204150, model, HttpContext);

            ModelState.Clear();

            // ４．画面に制御を移す。
            // 税務申告書類等調査入力（全相殺）画面を表示する
            return View(F204Const.SCREEN_ID_D204150, model);        
        }

        #region ページャーイベント
        /// <summary>
        /// 検索結果ページャー
        /// </summary>
        /// <param name="id">ページID</param>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult ResultPager(string id)
        {
            // ページIDは数値以外のデータの場合
            if (!Regex.IsMatch(id, @"^[0-9]+$") || F204Const.PAGE_0 == id)
            {
                return BadRequest();
            }

            // セッションから共済金額設定モデルを取得する
            D204150Model model = SessionUtil.Get<D204150Model>(SESS_D204150, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }
            // メッセージをクリアする
            model.MessageArea1 = string.Empty;
            model.MessageArea2 = string.Empty;

            // モデル状態ディクショナリからすべての項目を削除します。
            ModelState.Clear();

            // 検索結果を取得する
            NskAppContext dbContext = getJigyoDb<NskAppContext>();
            D204150SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);
            model.SearchResult.GetPageDataList(dbContext, sessionInfo, int.Parse(id));

            model.SearchResult.ApplyInputAndRebuild(model.SearchResult.DispRecords, model.SearchCondition);
            model.SearchResult.Reindex();

            // 検索条件と検索結果をセッションに保存する
            SessionUtil.Set(SESS_D204150, model, HttpContext);

            return PartialViewAsJson("_D204150SearchResult", model);
        }
        #endregion

        /// <summary>
        /// 共済金額設定を検索する。													
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Search(D204150Model dispModel)
        {
            Console.WriteLine("Search呼ばれた");

            D204150SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            // セッションから加入申込書入力（水稲）モデルを取得する
            D204150Model model = SessionUtil.Get<D204150Model>(SESS_D204150, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }

            // 画面入力値 → モデルに反映
            model.SearchCondition.ApplyInput(dispModel.SearchCondition);
            // 結果表示フラグ 初期化
            model.SearchCondition.IsResultDisplay = false;

            // 検索結果クリア
            model.SearchResult = new(model.SearchCondition);
            // メッセージクリア
            model.MessageArea1 = string.Empty;
            model.MessageArea2 = string.Empty;
            ModelState.Clear();

            // ２．入力チェック
            // ２．１．属性チェック
            // 画面入力値をセッションモデルに反映
            model.SearchCondition.ApplyInput(dispModel.SearchCondition);
            // 必須チェック用クラス
            InputRequiredAttribute isInputRequired = new InputRequiredAttribute();

            // 組合員等コード（開始）
            if (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdFrom))
            {
                // 入力ありの場合属性チェック
                // 半角数値チェック用クラス
                NumericAttribute isNumeric = new NumericAttribute();
                // 桁数チェック用クラス
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                if (!isNumeric.IsValid(model.SearchCondition.KumiaiinToCdFrom))
                {
                    // 半角数値チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isNumeric.FormatErrorMessage("組合員等コード（開始）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                } 
                else if (!isDigitLength.IsValid(model.SearchCondition.KumiaiinToCdFrom))
                {
                    // 桁数チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isDigitLength.FormatErrorMessage("組合員等コード（開始）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
            }
            // 組合員等コード（終了）
            if (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdTo))
            {
                // 入力ありの場合属性チェック
                // 半角数値チェック用クラス
                NumericAttribute isNumeric = new NumericAttribute();
                // 桁数チェック用クラス
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                if (!isNumeric.IsValid(model.SearchCondition.KumiaiinToCdTo))
                {
                    // 半角数値チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isNumeric.FormatErrorMessage("組合員等コード（終了）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
                else if (!isDigitLength.IsValid(model.SearchCondition.KumiaiinToCdTo))
                {
                    // 桁数チェック
                    // エラーメッセージを「メッセージエリア１」に設定する。
                    model.MessageArea1 = isDigitLength.FormatErrorMessage("組合員等コード（終了）");
                    ModelState.AddModelError("MessageArea1", model.MessageArea1);
                }
            }

            // ２．２．独自チェック
            // ２．２．１．[画面：小地区（終了）]<[画面：小地区（開始）]の場合、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            if ((!string.IsNullOrEmpty(model.SearchCondition.TodofukenDropDownList.ShochikuCdFrom) &&
                (!string.IsNullOrEmpty(model.SearchCondition.TodofukenDropDownList.ShochikuCdTo))) &&
                (model.SearchCondition.TodofukenDropDownList.ShochikuCdFrom.CompareTo(
                 model.SearchCondition.TodofukenDropDownList.ShochikuCdTo) > 0))
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME10020", "小地区");

                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }

            // (２．２．２．[画面：組合員等コード（終了）]<[画面：組合員等コード（開始）]の場合、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            if ((!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdFrom) &&
                (!string.IsNullOrEmpty(model.SearchCondition.KumiaiinToCdTo))) &&
                (model.SearchCondition.KumiaiinToCdFrom.CompareTo(
                 model.SearchCondition.KumiaiinToCdTo) > 0))
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME10020", "組合員等コード");

                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }

            // ２．２．３．［画面：表示順］の選択値に重複がある場合（以下のいずれかの条件に該当する場合）、
            // エラーと判定し「メッセージリスト」にメッセージを設定する。
            List<D204150SearchCondition.DisplaySortType> sortTypes = new List<D204150SearchCondition.DisplaySortType>();

            Console.WriteLine("DisplaySort1 = " + model.SearchCondition.DisplaySort1);
            Console.WriteLine("DisplaySort2 = " + model.SearchCondition.DisplaySort2);
            Console.WriteLine("DisplaySort3 = " + model.SearchCondition.DisplaySort3);

            // ［画面：表示順］が選択されている場合、配列に格納
            if (model.SearchCondition.DisplaySort1.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort1.Value);
            }
            if (model.SearchCondition.DisplaySort2.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort2.Value);
            }
            if (model.SearchCondition.DisplaySort3.HasValue)
            {
                sortTypes.Add(model.SearchCondition.DisplaySort3.Value);
            }

            // 配列に格納した表示順の件数と重複除外した件数が一致するか判定し
            // 判定しない場合は重複と判断しエラーと判定する
            bool hasDuplicates = sortTypes.Count != sortTypes.Distinct().Count();

            if (hasDuplicates)
            {
                // エラーメッセージを「メッセージエリア１」に設定する。
                model.MessageArea1 = MessageUtil.Get("ME90018", "表示順");
                ModelState.AddModelError("MessageArea1", model.MessageArea1);
            }

            // 表示数の設定
            model.SearchResult.DisplayCount = model.SearchCondition.DisplayCount ?? CoreConst.PAGE_SIZE; ;

            // ２．３．「メッセージリスト」のメッセージの有無で下記の処理を行う。
            if (ModelState.IsValid)
            {
                // ３．データ検索SQLを実行（ログ出力：あり）
                // ３．１．「検索結果情報リスト」を取得する。
                NskAppContext dbContext = getJigyoDb<NskAppContext>();
                model.SearchResult.GetPageDataList(dbContext, sessionInfo, F204Const.PAGE_1);

                // データ取得失敗時のチェック
                if (model.SearchResult.DispRecords == null)
                {
                    model.MessageArea2 = MessageUtil.Get("ME01645", "データの取得");
                    ModelState.AddModelError("MessageArea2", model.MessageArea2);

                    return Json(new
                    {
                        resultArea = "",
                        messageArea2 = ModelState["MessageArea2"]
                    });
                }

                // ★ここでログ出力
                Console.WriteLine($"[Search] 検索件数: {model.SearchResult.AllRecCount}");
                foreach (var rec in model.SearchResult.DispRecords)
                {
                    Console.WriteLine($"[Search] 組合員コード: {rec.KumiaiintoCd}, 氏名: {rec.FullNm}");
                }

                ApplyInputAndRebuild(dispModel);
                model.SearchResult.Reindex();

                // ４．検索結果の表示
                if (model.SearchResult.AllRecCount == 0)
                {
                    // エラーメッセージを「メッセージエリア２」に設定する。
                    model.MessageArea2 = MessageUtil.Get("MI00011");
                    ModelState.AddModelError("MessageArea2", model.MessageArea2);
                }

                // 結果表示フラグON
                model.SearchCondition.IsResultDisplay = true;
            }

            // ５．検索条件、検索結果件数の保持
            // ５．１．検索条件、検索結果件数をセッションに保存する。
            SessionUtil.Set(SESS_D204150, model, HttpContext);

            JsonResult resultArea = PartialViewAsJson("_D204150SearchResult", model);

            // ６．画面操作制御区分による表示
            // ６．１．画面操作制御区分により、下表の画面項目の活性制御を行う。

            return Json(new { resultArea = resultArea.Value, messageArea1 = ModelState["MessageArea1"], messageArea2 = ModelState["MessageArea2"] });
        }


        /// <summary>
        /// 行挿入処理
        /// </summary>
        /// <param name="dispModel">画面から送られてきたモデル（検索結果）</param>
        /// <returns>追加行のインデックスと再描画用HTMLを返却</returns>
        public ActionResult AddNewRowBtn(D204150Model dispModel)
        {
            // DBコンテキスト取得（業務DB）
            var dbContext = getJigyoDb<NskAppContext>();

            // セッション情報取得（共済目的コードなどが格納されている）
            D204150SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            // セッションから画面モデルを取得（SearchResultなどが含まれる）
            D204150Model model = SessionUtil.Get<D204150Model>(SESS_D204150, HttpContext);

            // セッションに自画面のデータが存在しない場合
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }

            // POSTモデル・セッションモデル両方の Index を再付与
            for (int i = 0; i < dispModel.SearchResult.DispRecords.Count; i++)
            {
                dispModel.SearchResult.DispRecords[i].Index = i;
            }


            for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
            {
                model.SearchResult.DispRecords[i].Index = i;
            }

            // CheckSelect 状態を反映
            ApplyCheckSelectFromPost(dispModel.SearchResult.DispRecords, model.SearchResult.DispRecords);

            // 共済目的コードを明示的に補完
            model.SearchResult.SearchCondition.KyosaiMokutekiCd = model.KyosaiMokutekiCd;

            // モデル状態ディクショナリからすべての項目を削除します。
            ModelState.Clear();

            // １．[画面：明細：行選択]チェックボックスがオンになっている明細行の次行に空白行を追加する。
            // オン状態の[画面：明細：行選択]チェックボックスがない場合は、明細行の最後に空白行を追加する。空白行の[画面：明細：行追加フラグ（非表示）]をtrueとする。
            // オン状態の[画面：明細：行選択]チェックボックス複数存在する場合は、なにもしない。

            // 挿入インデックスの取得
            int insertIndex = -1;
            if (int.TryParse(HttpContext.Request.Form["insertIndex"], out int parsedIndex))
            {
                insertIndex = parsedIndex;
                Console.WriteLine($"★画面側Index = {insertIndex}（※変換なしで使用）");
            }

            // チェックされた行を取得
            var selectedList = model.SearchResult.DispRecords
                .Select((r, idx) => new { r.CheckSelect, r.IsDelRec, idx })
                .Where(x => x.CheckSelect && !x.IsDelRec)
                .ToList();

            // 0件 → 末尾に追加、1件 → その下に追加、それ以外は追加しない
            if (selectedList.Count > 1)
            {
                return Json(new { addRowIdx = -1, resultArea = PartialViewAsJson("_D204150SearchResult", model) });
            }
            else if (selectedList.Count == 1)
            {
                insertIndex = selectedList[0].idx + 1;
            }
            else
            {
                insertIndex = model.SearchResult.DispRecords.Count; // ← 末尾に追加
            }

            // 追加行のインデックスを取得
            int addRowIdx = model.SearchResult.AddPageData(insertIndex);

            // POSTモデル側に true をセット
            if (addRowIdx >= 0 && addRowIdx < dispModel.SearchResult.DispRecords.Count)
            {
                dispModel.SearchResult.DispRecords[addRowIdx].IsNewRec = true;
            }

            ApplyInputAndRebuild(dispModel);

            // Indexを再振り
            model.SearchResult.Reindex();

            // 表示対象行数を更新
            model.SearchResult.AllRecCount = model.SearchResult.DispRecords.Count(r => !r.IsDelRec);

            // 結果表示ON
            model.SearchCondition.IsResultDisplay = true;

            // 検索条件と検索結果をセッションに保存する
            SessionUtil.Set(SESS_D204150, model, HttpContext);

            // ２．フォーカスは追加行の先頭項目に当てる。
            return Json(new { addRowIdx, resultArea = PartialViewAsJson("_D204150SearchResult", model) });
        }

        /// <summary>
        /// チェックされた行を削除（非表示）する
        /// </summary>
        [HttpPost]
        public ActionResult DeleteSelectedRowsBtn(D204150Model dispModel)
        {
            // セッション取得
            var model = SessionUtil.Get<D204150Model>(SESS_D204150, HttpContext);
            if (model is null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
            }

            ModelState.Clear();

            // Index再振り（POSTモデル／セッションモデル双方）
            for (int i = 0; i < dispModel.SearchResult.DispRecords.Count; i++)
                dispModel.SearchResult.DispRecords[i].Index = i;

            for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
                model.SearchResult.DispRecords[i].Index = i;

            // チェック状態を反映
            ApplyCheckSelectFromPost(dispModel.SearchResult.DispRecords, model.SearchResult.DispRecords);

            // チェックされている未削除行がない場合は中止
            if (!model.SearchResult.DispRecords.Any(r => r.CheckSelect && !r.IsDelRec))
            {
                return Json(new { resultArea = (object?)null, message = "" });
            }

            // 未削除かつ選択されている行のみを削除
            for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
            {
                var row = model.SearchResult.DispRecords[i];
                if (row.CheckSelect && !row.IsDelRec)
                {
                    row.IsDelRec = true;
                }
            }

            // 未削除の行については選択解除（再表示後の混乱防止）
            foreach (var rec in model.SearchResult.DispRecords)
            {
                if (!rec.IsDelRec)
                {
                    rec.CheckSelect = false;
                }
            }

            // 表示対象ありフラグ
            model.SearchCondition.IsResultDisplay = true;

            // 非削除行の件数を再カウント
            model.SearchResult.AllRecCount = model.SearchResult.DispRecords.Count(r => !r.IsDelRec);

            model.SearchResult.Reindex();

            ApplyInputAndRebuild(dispModel);

            // セッション更新
            SessionUtil.Set(SESS_D204150, model, HttpContext);

            // 部分ビューをHTMLに変換して返却
            string html = RenderPartialViewToString("_D204150SearchResult", model);

            // 最初の未削除行のインデックス（フォーカス制御用）
            int firstRowIdx = model.SearchResult.DispRecords.FindIndex(r => !r.IsDelRec);

            return Json(new
            {
                resultArea = new { partialView = html },
                firstRowIdx
            });
        }

        #region 登録イベント

        /// <summary>
        /// 税務申告書類等調査入力（全相殺）を登録
        /// </summary>
        /// <returns></returns>
        public ActionResult Insert(D204150Model dispModel)
        {
            IDbContextTransaction? transaction = null;
            string errMessage = string.Empty;
            try
            {
                D204150SessionInfo sessionInfo = new();
                sessionInfo.GetInfo(HttpContext);

                // セッションからモデルを取得
                D204150Model model = SessionUtil.Get<D204150Model>(SESS_D204150, HttpContext);
                if (model is null)
                {
                    throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッションから画面情報を取得できませんでした"));
                }

                for (int i = 0; i < dispModel.SearchResult.DispRecords.Count; i++)
                {
                    var rec = dispModel.SearchResult.DispRecords[i];
                }

                // ApplyInputの前に、IsNewRec=true のIndexを保存
                var newRecIndexes = dispModel.SearchResult.DispRecords
                    .Select((r, idx) => new { r.IsNewRec, idx })
                    .Where(x => x.IsNewRec)
                    .Select(x => x.idx)
                    .ToHashSet(); // ← Set型で高速アクセス

                // 画面入力値をセッションモデルに反映
                model.SearchResult.ApplyInput(dispModel.SearchResult);

                // トランザクション開始
                NskAppContext dbContext = getJigyoDb<NskAppContext>();
                transaction = dbContext.Database.BeginTransaction();

                // 明細各行の「引受データ」の取得
                foreach (var rec in model.SearchResult.DispRecords)
                {
                    if (rec.IsDelRec) continue;

                    var dto = GetHikiukeDataInternal(dbContext, sessionInfo, rec.KumiaiintoCd, rec.RuiKbn, rec.YoutoKbn);
                    if (dto == null)
                    {
                        errMessage = MessageUtil.Get("ME10016", "引受", $"組合員等コード = {rec.KumiaiintoCd}");
                        model.MessageArea2 = errMessage;
                        ModelState.AddModelError("MessageArea2", errMessage);
                        return Json(new { message = errMessage });
                    }
                }

                foreach (var rec in model.SearchResult.DispRecords.Select((r, i) => new { r, i }))
                {
                    rec.r.IsNewRec = newRecIndexes.Contains(rec.i);
                }

                // ここで削除フラグを設定
                ApplyCheckSelectToDeleteFlag(model.SearchResult.DispRecords);

                // 再確認ログ（ApplyInput 後）
                for (int i = 0; i < model.SearchResult.DispRecords.Count; i++)
                {
                    var rec = model.SearchResult.DispRecords[i];
                }

                // 重複チェック（組合員等コード、類区分、用途区分）
                // 類区分：水稲・麦、用途区分：麦 のみチェック対象
                var duplicates = model.SearchResult.DispRecords
                    .Where(x => !x.IsDelRec) // 削除対象除外
                    .GroupBy(x => new
                    {
                        x.KumiaiintoCd,
                        RuiKbn = (model.KyosaiMokutekiCd == "11" || model.KyosaiMokutekiCd == "30") ? x.RuiKbn : null,
                        YoutoKbn = model.KyosaiMokutekiCd == "30" ? x.YoutoKbn : null
                    })
                    .Where(g => g.Count() > 1)
                    .ToList();

                if (duplicates.Any())
                {
                    errMessage = MessageUtil.Get("ME90018", "入力内容");
                    model.MessageArea2 = errMessage;
                    ModelState.AddModelError("MessageArea2", errMessage);
                    throw new AppException("ME90018", errMessage);
                }

                // 属性チェック
                InputRequiredAttribute isInputRequired = new InputRequiredAttribute();
                NumericAttribute isNumeric = new NumericAttribute();
                WithinDigitLengthAttribute isDigitLength = new WithinDigitLengthAttribute(13);

                string mokutekiCd = model.KyosaiMokutekiCd;

                // 必須チェック・0自動セット
                foreach (var rec in model.SearchResult.DispRecords)
                {
                    if (rec.IsDelRec) continue;
                    if (!rec.IsNewRec) continue; // 新規登録のみ

                    // 必須・0自動セット分岐
                    switch (mokutekiCd)
                    {
                        case "20": // 陸稲
                                   // 必須：組合員等コード
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            // 数値/桁数チェックも既存同様
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            // 0自動セット
                            rec.RuiKbn = "0";
                            rec.YoutoKbn = "0";
                            break;

                        case "11": // 水稲
                                   // 必須：組合員等コード、類区分
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            if (!isInputRequired.IsValid(rec.RuiKbn))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("類区分");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            // 0自動セット
                            rec.YoutoKbn = "0";
                            break;

                        case "30": // 麦
                                   // 必須：組合員等コード、類区分、用途区分（現状どおり）
                            if (!isInputRequired.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            if (!isNumeric.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isNumeric.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00003", errMessage);
                            }
                            if (!isDigitLength.IsValid(rec.KumiaiintoCd))
                            {
                                errMessage = isDigitLength.FormatErrorMessage("組合員等コード");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00016", errMessage);
                            }
                            if (!isInputRequired.IsValid(rec.RuiKbn))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("類区分");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            if (!isInputRequired.IsValid(rec.YoutoKbn))
                            {
                                errMessage = isInputRequired.FormatErrorMessage("用途区分");
                                model.MessageArea2 = errMessage;
                                ModelState.AddModelError("MessageArea2", errMessage);
                                throw new AppException("ME00001", errMessage);
                            }
                            break;
                    }
                }

                var delRecords = model.SearchResult.GetDeleteRecs();

                Console.WriteLine($"【削除候補件数】{delRecords.Count}");
                foreach (var rec in delRecords)
                {
                    Console.WriteLine($"削除対象: Index={rec.Index}, KumiaiintoCd={rec.KumiaiintoCd}, IsDelRec={rec.IsDelRec}, IsNewRec={rec.IsNewRec}");
                }

                int delCount = 0;
                if (delRecords.Count > 0)
                {
                    delCount += model.SearchResult.DeleteShinkoku(ref dbContext, sessionInfo, ref delRecords);
                }

                // 入力再反映・整合性再構築
                model.SearchResult.ApplyInputAndRebuild(model.SearchResult.DispRecords, model.SearchCondition);
                model.SearchResult.Reindex();

                int updCount = 0;
                List<D204150ResultRecord> updRecords = model.SearchResult.GetUpdateRecs(ref dbContext, sessionInfo);
                if (updRecords.Count > 0)
                {
                    updCount += model.SearchResult.UpdateShinkoku(
                        ref dbContext,
                        sessionInfo,
                        GetUserId(),
                        DateUtil.GetSysDateTime(),
                        ref updRecords);
                }

                int insCount = 0;
                List<D204150ResultRecord> addRecords = model.SearchResult.GetAddRecs();
                if (addRecords.Count > 0)
                {
                    insCount += model.SearchResult.AppendShinkoku(
                        ref dbContext,
                        sessionInfo,
                        GetUserId(),
                        DateUtil.GetSysDateTime(),
                        ref addRecords);
                }

                foreach (var rec in model.SearchResult.DispRecords)
                {
                    rec.IsNewRec = false;
                }

                if (delCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "削除");
                }
                if (updCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "更新");
                }
                if (insCount > 0)
                {
                    errMessage = MessageUtil.Get("MI00004", "登録");
                }
                if (delCount == 0 && updCount == 0 && insCount == 0)
                {
                    errMessage = MessageUtil.Get("MI00012");
                }

                transaction.CommitAsync();

                SessionUtil.Set(SESS_D204150, model, HttpContext);
            }
            catch (Exception ex)
            {
                transaction?.RollbackAsync();

                if (string.IsNullOrEmpty(errMessage))
                {
                    if (ex is DBConcurrencyException)
                    {
                        errMessage = !string.IsNullOrEmpty(ex.Message)
                            ? MessageUtil.Get(ex.Message)
                            : MessageUtil.Get("ME10081");
                    }
                    else if (ex is DbUpdateException)
                    {
                        errMessage = MessageUtil.Get("ME10081");
                    }
                    else
                    {
                        errMessage = MessageUtil.Get("MF00001");
                    }
                }
            }

            return Json(new { message = errMessage });
        }

        #endregion


        #region 戻るイベント
        /// <summary>
        /// 戻る
        /// ポータルへ遷移する。
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Back()
        {
            // ポータル

            return Json(new { result = "success" });
        }
        #endregion

        /// <summary>
        /// 組合員等名更新
        /// </summary>
        /// <param name="kumiaiintoCd">組合員等コード</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult UpdateKumiaiintoName(string kumiaiintoCd)
        {
            // 組合員等名を取得 
            // t_農業者情報から「組合員等コード」に該当する「氏名又は法人名」を取得する。
            D204150SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);
            NskAppContext dbContext = getJigyoDb<NskAppContext>();
            VNogyosha? kumiaiinto = dbContext.VNogyoshas.SingleOrDefault(x =>
                (x.TodofukenCd == sessionInfo.TodofukenCd) &&
                (x.KumiaitoCd == sessionInfo.KumiaitoCd) &&
                (x.KumiaiintoCd == kumiaiintoCd)
                );
            string kumiaiintoNm = kumiaiinto?.HojinFullNm ?? string.Empty;

            // 「組合員等名」をJSON化して返送する。
            return Json(new { kumiaiintoNm });
        }

        /// <summary>
        /// 類区分に応じた用途区分のリストを取得して返すAjax用アクション
        /// </summary>
        [HttpPost]
        public JsonResult GetYoutoKbnList(string ruiKbn)
        {
            var dbContext = getJigyoDb<NskAppContext>();
            D204150SessionInfo sessionInfo = new();
            sessionInfo.GetInfo(HttpContext);

            var result = GetYoutoKbnSelectList(dbContext, sessionInfo.KyosaiMokutekiCd, ruiKbn);
            return Json(new { list = result });
        }

        /// <summary>
        /// 類区分に応じた用途区分のドロップダウンリストを取得する共通関数。
        /// 共済目的コードに応じて、用途区分名称マスタ（m_10110）から用途区分を取得する。
        /// 類区分が指定されている場合は、用途区分選択マスタ（m_10120）との突合で絞り込む。
        /// </summary>
        /// <param name="dbContext">DBコンテキスト</param>
        /// <param name="kyosaiMokutekiCd">共済目的コード（セッションより取得）</param>
        /// <param name="ruiKbn">選択された類区分（空欄の場合は全件取得）</param>
        /// <returns>用途区分のSelectList（Value: 用途区分, Text: 用途短縮名称）</returns>
        private List<SelectListItem> GetYoutoKbnSelectList(NskAppContext dbContext, string kyosaiMokutekiCd, string ruiKbn)
        {
            var list = (
                from m in dbContext.M10110用途区分名称s
                where m.共済目的コード == kyosaiMokutekiCd &&
                      (string.IsNullOrEmpty(ruiKbn) || dbContext.M10120用途区分選択s
                          .Where(x => x.共済目的コード == kyosaiMokutekiCd && x.類区分 == ruiKbn)
                          .Select(x => x.用途区分).Contains(m.用途区分))
                select new SelectListItem
                {
                    Value = m.用途区分,
                    Text = m.用途名称
                }).ToList();

            return list;
        }

        /// <summary>
        /// 画面からの入力値をセッションモデルに反映し、DropDownListも再構築
        /// </summary>
        /// <param name="dispModel">画面入力モデル</param>
        private void ApplyInputAndRebuild(D204150Model dispModel)
        {
            D204150Model sessionModel = SessionUtil.Get<D204150Model>(SESS_D204150, HttpContext);
            if (sessionModel == null)
            {
                throw new AppException("MF00005", MessageUtil.Get("MF00005", "セッション"));
            }

                sessionModel.SearchResult.ApplyInputAndRebuild(
                dispModel.SearchResult.DispRecords,
                sessionModel.SearchCondition
            );
        }

        /// <summary>
        /// CheckSelect が true の行に対して IsDelRec = true を設定する
        /// </summary>
        private void ApplyCheckSelectToDeleteFlag(List<D204150ResultRecord> dispRecords)
        {
            for (int i = 0; i < dispRecords.Count; i++)
            {
                var rec = dispRecords[i];
                if (rec.CheckSelect)
                {
                    rec.IsDelRec = true;
                }
            }
        }

        /// <summary>
        /// POSTされたチェック状態（CheckSelect）をセッション側に反映する共通メソッド（Indexベース）
        /// 削除済み行も含め、Indexに一致する行のCheckSelectを上書きする。
        /// </summary>
        private void ApplyCheckSelectFromPost(List<D204150ResultRecord> from, List<D204150ResultRecord> to)
        {
            foreach (var postRow in from)
            {
                int idx = postRow.Index;
                if (idx < to.Count)
                {
                    to[idx].CheckSelect = postRow.CheckSelect;
                }
            }
        }

        /// <summary>
        /// 指定された部分ビューをHTML文字列としてレンダリングします。
        /// JavaScriptからのAjaxで部分更新するために使用します。
        /// </summary>
        /// <param name="viewName">部分ビューの名前（例：_D204150SearchResult）</param>
        /// <param name="model">ビューに渡すモデルオブジェクト</param>
        /// <returns>レンダリングされたHTML文字列</returns>
        protected string RenderPartialViewToString(string viewName, object model)
        {
            ViewData.Model = model;

            using var sw = new StringWriter();

            // ビューを探す（注：ViewEngineではなく _viewEngine）
            var viewResult = _viewEngine.FindView(ControllerContext, viewName, false);
            if (viewResult.View == null)
            {
                throw new ArgumentNullException($"ビュー '{viewName}' が見つかりません。");
            }

            var viewContext = new ViewContext(
                ControllerContext,
                viewResult.View,
                ViewData,
                TempData,
                sw,
                new HtmlHelperOptions()
            );

            viewResult.View.RenderAsync(viewContext).Wait();

            return sw.ToString();
        }

        /// <summary>
        /// 引受データをAjax経由で取得し、画面に反映するためのアクションメソッドです。
        /// 「組合員等コード」「類区分」「用途区分」を元に、最新の引受データ（基準収穫量、補償割合コード、組合員氏名）を取得します。
        /// 条件に一致するデータが存在すれば、指定行にセットするためのJSONを返却します。
        /// </summary>
        /// <param name="rowIndex">変更対象の行インデックス（画面上の行番号）</param>
        /// <param name="kumiaiintoCd">画面入力された組合員等コード</param>
        /// <param name="ruiKbn">画面入力された類区分</param>
        /// <param name="youtoKbn">画面入力された用途区分（共済目的が麦の場合）</param>
        /// <returns>成功可否・取得データを含むJSON</returns>
        public JsonResult GetHikiukeData(string rowIndex, string kumiaiintoCd, string ruiKbn, string youtoKbn)
        {
            try
            {
                // １．セッションから基本条件を取得
                var sessionInfo = new D204150SessionInfo();
                sessionInfo.GetInfo(HttpContext);

                string kumiaiCd = sessionInfo.KumiaitoCd;                   // 組合等コード
                string kyosaiMokutekiCd = sessionInfo.KyosaiMokutekiCd;     // 共済目的コード
                short nensan = (short)sessionInfo.Nensan;                   // 年産
                string todofukenCd = sessionInfo.TodofukenCd;               // 都道府県コード

                bool isMugi = kyosaiMokutekiCd == "30";
                bool isRikuto = kyosaiMokutekiCd == "20";
                bool isSuito = kyosaiMokutekiCd == "11" || isMugi;

                int? ruiKbnInt = int.TryParse(ruiKbn, out var rk) ? rk : null;
                int? youtoKbnInt = int.TryParse(youtoKbn, out var yk) ? yk : null;

                if (string.IsNullOrWhiteSpace(kumiaiintoCd)
                    || (isSuito && ruiKbnInt == null)
                    || (isMugi && youtoKbnInt == null))
                {
                    return Json(new { success = false, message = "入力が不足しています。" });
                }

                using (var db = getJigyoDb<NskAppContext>())
                {
                    // ２．最新の引受回を取得
                    var hikiukeKai = (from t00010 in db.T00010引受回s
                                      join t12040 in db.T12040組合員等別引受情報s on
                                          new { t00010.組合等コード, t00010.共済目的コード, t00010.年産, t00010.支所コード }
                                          equals new { t12040.組合等コード, t12040.共済目的コード, t12040.年産, t12040.支所コード }
                                      join t11090 in db.T11090引受耕地s on
                                          new { t12040.組合等コード, t12040.共済目的コード, t12040.年産, t12040.組合員等コード, t12040.類区分 }
                                          equals new { t11090.組合等コード, t11090.共済目的コード, t11090.年産, t11090.組合員等コード, t11090.類区分 }
                                      where t12040.組合等コード == kumiaiCd
                                        && t12040.共済目的コード == kyosaiMokutekiCd
                                        && t12040.年産 == nensan
                                        && t12040.組合員等コード == kumiaiintoCd
                                        && (!isRikuto && t12040.類区分 == ruiKbnInt.ToString())
                                        && (isMugi ? t11090.用途区分 == youtoKbnInt.ToString() : true)
                                        && t12040.引受方式 == "3"
                                        && t12040.引受対象フラグ == "1"
                                      select t00010.引受回).DefaultIfEmpty().Max();

                    // ３．引受データ取得
                    var sql = $@"
                        SELECT 
                            nogyosha.hojin_full_nm AS KumiaiinNm,
                            m_20030.補償割合短縮名称 AS HoshoWariai,
                            t_12040.基準収穫量計 AS KijyunSyukakuryo,
                            t_21130.収穫量 AS HonnenSyukakuryo,
                            t_21130.事業消費数量 AS JigyoShohiSuryo,
                            t_21130.廃棄亡失数量 AS HaikiSuryo,
                            t_21130.期末棚卸数量 AS KimatsuSyukakuryo,
                            t_21130.売上数量 AS UriageSuryo,
                            t_21130.期首棚卸数量 AS KishuSyukakuryo,
                            (t_21130.xmin::text)::bigint AS Xmin
                        FROM t_12040_組合員等別引受情報 t_12040
                        INNER JOIN t_11090_引受耕地 t_11090
                            ON t_11090.組合等コード = t_12040.組合等コード
                            AND t_11090.年産 = t_12040.年産
                            AND t_11090.共済目的コード = t_12040.共済目的コード
                            AND t_11090.組合員等コード = t_12040.組合員等コード
                            AND t_11090.類区分 = t_12040.類区分
                            {(isMugi ? "AND t_11090.用途区分 = @youtoKbnInt" : "")}
                        INNER JOIN nouho_nsk_03.v_nogyosha nogyosha
                            ON nogyosha.todofuken_cd = @todofukenCd
                            AND nogyosha.kumiaito_cd = t_12040.組合等コード
                            AND nogyosha.kumiaiinto_cd = t_12040.組合員等コード
                        LEFT JOIN m_20030_補償割合名称 m_20030
                            ON m_20030.補償割合コード = t_12040.補償割合コード
                        LEFT JOIN t_21130_税務申告全数調査 t_21130
                            ON t_21130.組合等コード = t_11090.組合等コード
                            AND t_21130.年産 = t_11090.年産
                            AND t_21130.共済目的コード = t_11090.共済目的コード
                            AND t_21130.組合員等コード = t_11090.組合員等コード
                            AND t_21130.類区分 = t_11090.類区分
                            {(isMugi ? "AND t_21130.用途区分 = @youtoKbnInt" : "")}
                        WHERE t_12040.組合等コード = @kumiaiCd
                          AND t_12040.共済目的コード = @kyosaiMokutekiCd
                          AND t_12040.年産 = @nensan
                          AND t_12040.組合員等コード = @kumiaiintoCd
                          {(isMugi || isSuito ? "AND t_12040.類区分 = @ruiKbnInt" : "")}
                          {(isMugi ? "AND t_11090.用途区分 = @youtoKbnInt" : "")}
                          AND t_12040.引受回 = @hikiukeKai";

                    var parameters = new[]
                    {
                        new NpgsqlParameter("@todofukenCd", NpgsqlDbType.Varchar) { Value = todofukenCd },
                        new NpgsqlParameter("@kumiaiCd", NpgsqlDbType.Varchar) { Value = kumiaiCd },
                        new NpgsqlParameter("@kyosaiMokutekiCd", NpgsqlDbType.Varchar) { Value = kyosaiMokutekiCd },
                        new NpgsqlParameter("@nensan", NpgsqlDbType.Smallint) { Value = nensan },
                        new NpgsqlParameter("@kumiaiintoCd", NpgsqlDbType.Varchar) { Value = kumiaiintoCd },
                        new NpgsqlParameter("@ruiKbnInt", NpgsqlDbType.Varchar)
                            { Value = (object?)ruiKbnInt?.ToString() ?? DBNull.Value },
                        new NpgsqlParameter("@youtoKbnInt", NpgsqlDbType.Varchar)
                            { Value = (object?)youtoKbnInt?.ToString() ?? DBNull.Value },
                        new NpgsqlParameter("@isMugi", NpgsqlDbType.Integer) { Value = isMugi ? 1 : 0 },
                        new NpgsqlParameter("@hikiukeKai", NpgsqlDbType.Smallint)
                            { Value = (object?)hikiukeKai ?? DBNull.Value }
                    };

                    D204150HikiukeResultDto result = null;
                    var conn = db.Database.GetDbConnection();
                    conn.Open();

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = sql;
                        cmd.CommandType = CommandType.Text;

                        foreach (var p in parameters)
                            cmd.Parameters.Add(p);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                result = new D204150HikiukeResultDto
                                {
                                    KumiaiinNm = reader["KumiaiinNm"]?.ToString(),
                                    HoshoWariai = reader["HoshoWariai"]?.ToString(),
                                    KijyunSyukakuryo = reader["KijyunSyukakuryo"] as decimal?,
                                    HonnenSyukakuryo = reader["HonnenSyukakuryo"] as decimal?,
                                    JigyoShohiSuryo = reader["JigyoShohiSuryo"] as decimal?,
                                    HaikiSuryo = reader["HaikiSuryo"] as decimal?,
                                    KimatsuSyukakuryo = reader["KimatsuSyukakuryo"] as decimal?,
                                    UriageSuryo = reader["UriageSuryo"] as decimal?,
                                    KishuSyukakuryo = reader["KishuSyukakuryo"] as decimal?,
                                    Xmin = reader["Xmin"] != DBNull.Value ? Convert.ToUInt32(reader["Xmin"]) : (uint?)null
                                };
                            }
                        }
                    }

                    // ４．正常取得時の返却
                    return Json(new
                    {
                        success = true,
                        rowIndex,
                        kumiaiinNm = result.KumiaiinNm,
                        hoshoWariai = result.HoshoWariai,
                        kijyunSyukakuryo = result.KijyunSyukakuryo,
                        honnenSyukakuryo = result.HonnenSyukakuryo,
                        jigyoShohiSuryo = result.JigyoShohiSuryo,
                        haikiSuryo = result.HaikiSuryo,
                        kimatsuSyukakuryo = result.KimatsuSyukakuryo,
                        kishuSyukakuryo = result.KishuSyukakuryo,
                        uriageSuryo = result.UriageSuryo,
                        xmin = result.Xmin
                    });
                }
            }
            catch (Exception ex)
            {
                // ５．例外発生時の返却
                return Json(new { success = false, message = "エラーが発生しました。" });
            }
        }

        /// <summary>
        /// 引受データ取得の共通内部関数（Insert()などから利用）
        /// 条件に一致する場合は D204150HikiukeResultDto を返し、取得できなければ null を返す
        /// </summary>
        private D204150HikiukeResultDto? GetHikiukeDataInternal(
            NskAppContext db,
            D204150SessionInfo session,
            string kumiaiintoCd,
            string ruiKbn,
            string youtoKbn)
        {
            string kumiaiCd = session.KumiaitoCd;
            string kyosaiMokutekiCd = session.KyosaiMokutekiCd;
            short nensan = (short)session.Nensan;
            string todofukenCd = session.TodofukenCd;

            bool isMugi = kyosaiMokutekiCd == "30";
            bool isRikuto = kyosaiMokutekiCd == "20";
            bool isSuito = kyosaiMokutekiCd == "11" || isMugi;

            int? ruiKbnInt = int.TryParse(ruiKbn, out var rk) ? rk : null;
            int? youtoKbnInt = int.TryParse(youtoKbn, out var yk) ? yk : null;

            if (string.IsNullOrWhiteSpace(kumiaiintoCd)
                || (isSuito && ruiKbnInt == null)
                || (isMugi && youtoKbnInt == null))
            {
                return null;
            }

            var hikiukeKai = (from t00010 in db.T00010引受回s
                              join t12040 in db.T12040組合員等別引受情報s
                                on new { t00010.組合等コード, t00010.共済目的コード, t00010.年産, t00010.支所コード }
                                equals new { t12040.組合等コード, t12040.共済目的コード, t12040.年産, t12040.支所コード }
                              join t11090 in db.T11090引受耕地s
                                on new { t12040.組合等コード, t12040.共済目的コード, t12040.年産, t12040.組合員等コード, t12040.類区分 }
                                equals new { t11090.組合等コード, t11090.共済目的コード, t11090.年産, t11090.組合員等コード, t11090.類区分 }
                              where t12040.組合等コード == kumiaiCd
                                && t12040.共済目的コード == kyosaiMokutekiCd
                                && t12040.年産 == nensan
                                && t12040.組合員等コード == kumiaiintoCd
                                && (!isRikuto && t12040.類区分 == ruiKbnInt.ToString())
                                && (isMugi ? t11090.用途区分 == youtoKbnInt.ToString() : true)
                                && t12040.引受方式 == "3"
                                && t12040.引受対象フラグ == "1"
                              select t00010.引受回).DefaultIfEmpty().Max();

            if (hikiukeKai == null) return null;

            var sql = @"
                SELECT 
                    nogyosha.hojin_full_nm AS KumiaiinNm,
                    m_20030.補償割合短縮名称 AS HoshoWariai,
                    t_12040.基準収穫量計 AS KijyunSyukakuryo,
                    t_21130.収穫量 AS HonnenSyukakuryo,
                    t_21130.事業消費数量 AS JigyoShohiSuryo,
                    t_21130.廃棄亡失数量 AS HaikiSuryo,
                    t_21130.期末棚卸数量 AS KimatsuSyukakuryo,
                    t_21130.売上数量 AS UriageSuryo,
                    t_21130.期首棚卸数量 AS KishuSyukakuryo,
                    (t_21130.xmin::text)::bigint AS Xmin
                FROM t_12040_組合員等別引受情報 t_12040
                INNER JOIN t_11090_引受耕地 t_11090
                    ON t_11090.組合等コード = t_12040.組合等コード
                    AND t_11090.年産 = t_12040.年産
                    AND t_11090.共済目的コード = t_12040.共済目的コード
                    AND t_11090.組合員等コード = t_12040.組合員等コード
                    AND t_11090.類区分 = t_12040.類区分
                    " + (isMugi ? "AND t_11090.用途区分 = @youtoKbnInt" : "") + @"
                INNER JOIN nouho_nsk_03.v_nogyosha nogyosha
                    ON nogyosha.todofuken_cd = @todofukenCd
                    AND nogyosha.kumiaito_cd = t_12040.組合等コード
                    AND nogyosha.kumiaiinto_cd = t_12040.組合員等コード
                LEFT JOIN m_20030_補償割合名称 m_20030
                    ON m_20030.補償割合コード = t_12040.補償割合コード
                LEFT JOIN t_21130_税務申告全数調査 t_21130
                    ON t_21130.組合等コード = t_11090.組合等コード
                    AND t_21130.年産 = t_11090.年産
                    AND t_21130.共済目的コード = t_11090.共済目的コード
                    AND t_21130.組合員等コード = t_11090.組合員等コード
                    AND t_21130.類区分 = t_11090.類区分
                    " + (isMugi ? "AND t_21130.用途区分 = @youtoKbnInt" : "") + @"
                WHERE t_12040.組合等コード = @kumiaiCd
                  AND t_12040.共済目的コード = @kyosaiMokutekiCd
                  AND t_12040.年産 = @nensan
                  AND t_12040.組合員等コード = @kumiaiintoCd
                  " + (isMugi || isSuito ? "AND t_12040.類区分 = @ruiKbnInt" : "") + @"
                  " + (isMugi ? "AND t_11090.用途区分 = @youtoKbnInt" : "") + @"
                  AND t_12040.引受回 = @hikiukeKai";

            var parameters = new[]
            {
                new NpgsqlParameter("@todofukenCd", NpgsqlDbType.Varchar) { Value = todofukenCd },
                new NpgsqlParameter("@kumiaiCd", NpgsqlDbType.Varchar) { Value = kumiaiCd },
                new NpgsqlParameter("@kyosaiMokutekiCd", NpgsqlDbType.Varchar) { Value = kyosaiMokutekiCd },
                new NpgsqlParameter("@nensan", NpgsqlDbType.Smallint) { Value = nensan },
                new NpgsqlParameter("@kumiaiintoCd", NpgsqlDbType.Varchar) { Value = kumiaiintoCd },
                new NpgsqlParameter("@ruiKbnInt", NpgsqlDbType.Varchar) { Value = (object?)ruiKbnInt?.ToString() ?? DBNull.Value },
                new NpgsqlParameter("@youtoKbnInt", NpgsqlDbType.Varchar) { Value = (object?)youtoKbnInt?.ToString() ?? DBNull.Value },
                new NpgsqlParameter("@hikiukeKai", NpgsqlDbType.Smallint) { Value = (object?)hikiukeKai ?? DBNull.Value }
            };

            var conn = db.Database.GetDbConnection();

            // 破棄済みオブジェクトに対する操作を防止
            if (conn.State == ConnectionState.Closed)
            {
                try
                {
                    conn.Open();
                }
                catch (ObjectDisposedException)
                {
                    throw new InvalidOperationException("データベース接続が既に破棄されています。GetHikiukeDataInternal() の呼び出し元で dbContext が有効な範囲内であることを確認してください。");
                }
            }

            using var cmd = conn.CreateCommand();
            cmd.CommandText = sql;
            cmd.CommandType = CommandType.Text;
            foreach (var p in parameters)
                cmd.Parameters.Add(p);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new D204150HikiukeResultDto
                {
                    KumiaiinNm = reader["KumiaiinNm"]?.ToString(),
                    HoshoWariai = reader["HoshoWariai"]?.ToString(),
                    KijyunSyukakuryo = reader["KijyunSyukakuryo"] as decimal?,
                    HonnenSyukakuryo = reader["HonnenSyukakuryo"] as decimal?,
                    JigyoShohiSuryo = reader["JigyoShohiSuryo"] as decimal?,
                    HaikiSuryo = reader["HaikiSuryo"] as decimal?,
                    KimatsuSyukakuryo = reader["KimatsuSyukakuryo"] as decimal?,
                    UriageSuryo = reader["UriageSuryo"] as decimal?,
                    KishuSyukakuryo = reader["KishuSyukakuryo"] as decimal?,
                    Xmin = reader["Xmin"] != DBNull.Value ? Convert.ToUInt32(reader["Xmin"]) : (uint?)null
                };
            }

            return null;
        }
    }
}
