﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using CoreLibrary.Core.Validator;
using NskWeb.Common.Models;

namespace NskWeb.Areas.F204.Models.D204130
{
    //　検索結果1件分のデータ定義。テーブル1行分の内容を定義。
    public class D204130ResultRecord : BasePagerRecord
    {
        /// <summary>組合員等コード</summary>
        [Display(Name = "組合員等コード")]
        [NumberSign(13)]
        [Required]
        public string KumiaiintoCd { get; set; } = string.Empty;

        /// <summary>氏名</summary>
        [Display(Name = "氏名")]
        public string FullNm { get; set; } = string.Empty;

        // 今回いらない？
        /// <summary>共済金額</summary>
        //[Display(Name = "共済金額")]
        //[NumberSign(13)]
        //[Required]
        //[DisplayFormat(DataFormatString = "{0:#,##0}", ApplyFormatInEditMode = true)]
        //public decimal? KyousaiKingaku { get; set; } = 0;

        public uint? Xmin { get; set; }

        /// <summary>類区分</summary>
        [Display(Name = "類区分")]
        public string RuiKbn { get; set; } = string.Empty;

        /// <summary>用途区分</summary>
        [Display(Name = "用途区分")]
        public string YoutoKbn { get; set; } = string.Empty;

        /// <summary>補償割合</summary>
        [Display(Name = "補償割合")]
        public string HoshoWariai { get; set; } = string.Empty;

        /// <summary>受託者等</summary>
        [Display(Name = "受託者等")]
        public string Jyutakusyato { get; set; } = string.Empty;

        /// <summary>受託者等受託者等コード</summary>
        [Display(Name = "受託者等コード")]
        public string JyutakusyatoCd { get; set; } = string.Empty;

        /// <summary>基準収穫量</summary>
        [Display(Name = "基準収穫量")]
        public string KijyunSyukakuryo { get; set; } = string.Empty;

        /// <summary>売渡数量</summary>
        [Display(Name = "売渡数量")]
        public decimal? UriwatashiSuryo { get; set; }

        /// <summary>削除フラグ</summary>
        [Display(Name = "削除フラグ")]
        [NotMapped]
        public new bool IsDelRec { get; set; } = false;

        /// <summary>行選択（チェックボックス）</summary>
        [Display(Name = "選択")]
        [NotMapped]
        public new bool CheckSelect { get; set; } = false;

        ///// <summary>新規追加行フラグ（オプション）</summary>
        //public bool IsNewRec { get; set; } = false;

        ///// <summary>
        ///// srcオブジェクトとの比較
        ///// </summary>
        ///// <param name="src"></param>
        ///// <returns></returns>
        //public bool Compare(D204130ResultRecord src)
        //{
        //    return (
        //        ($"{this.KumiaiintoCd}" == $"{src.KumiaiintoCd}") &&
        //        ($"{this.KyousaiKingaku}" == $"{src.KyousaiKingaku}")
        //    );
        //}
    }
}