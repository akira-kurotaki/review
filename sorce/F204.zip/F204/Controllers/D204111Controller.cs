﻿using CoreLibrary.Core.Attributes;
using CoreLibrary.Core.Base;
using CoreLibrary.Core.Consts;
using CoreLibrary.Core.Dto;
using CoreLibrary.Core.Exceptions;
using CoreLibrary.Core.Utility;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using ModelLibrary.Models;
using NskAppModelLibrary.Context;
using NskAppModelLibrary.Models;
using NskWeb.Areas.F000.Models.D000000;
using NskWeb.Areas.F000.Models.D000999;
using NskWeb.Areas.F204.Models.D204111;
using NskWeb.Common.Consts;
using Pipelines.Sockets.Unofficial.Arenas;

namespace NskWeb.Areas.F204.Controllers
{
    /// <summary>
    /// NSK_204111D_施設搬入収穫量結果入力（全相殺）
    /// </summary>
    /// <remarks>
    /// 作成日：2025/04/16
    /// 作成者：ネクスト松嶋
    /// </remarks>
    [ExcludeAuthCheck]
    [AllowAnonymous]
    [Area("F204")]
    public class D204111Controller : CoreController
    {
        #region メンバー定数
        /// <summary>
        /// 画面ID(D204111)
        /// </summary>
        private static readonly string SCREEN_ID_D204111 = "D204111";

        /// <summary>
        /// セッションキー(D204111)
        /// </summary>
        private static readonly string SESS_D204111 = "D204111_SCREEN";

        private string テスト農業者ID = "1111111";
        private string テスト用途区分 = "1";
        private string テスト類区分 = "1";

        #endregion

        // GET: F204/D204111/Init
        public ActionResult Init()
        {
            SessionUtil.Remove(SESS_D204111, HttpContext);
            ModelState.Clear();
            // ログインユーザの参照・更新可否判定
            // 画面IDをキーとして、画面マスタ、画面機能権限マスタを参照し、ログインユーザに本画面の権限がない場合は業務エラー画面を表示する。
            if (!ScreenSosaUtil.CanReference(SCREEN_ID_D204111, HttpContext))
            {
                throw new AppException("ME90003", MessageUtil.Get("ME90003"));
            }

            var syokuin = SessionUtil.Get<Syokuin>("_D9000_LOGIN_USER", HttpContext);
            if (syokuin == null)
            {
                ModelState.AddModelError("MessageArea", MessageUtil.Get("ME01033"));
                D000999Model d000999Model = GetInitModel();
                d000999Model.UserId = "";
                return View("D000999_Pre", d000999Model);
            }
            //// モデル初期化 D206021Model 
            D204111Model model = new D204111Model
            {
                // 「ログイン情報」を取得する
                VSyokuinRecords = getJigyoDb<NskAppContext>().VSyokuins.Where(t => t.UserId == Syokuin.UserId).Single()
            };
            var updateKengen = ScreenSosaUtil.CanUpdate(SCREEN_ID_D204111, HttpContext);
            model.UpdateKengenFlg = updateKengen;

            NSKPortalInfoModel md = SessionUtil.Get<NSKPortalInfoModel>(AppConst.SESS_NSK_PORTAL, HttpContext);
            if (md != null)
            {
                model.KyosaiMokutekiCd = md.SKyosaiMokutekiCd;
                model.Nensan = md.SNensanHyoka;
            }

            // DB 接続情報（各環境に合わせる）
            var dbConnectionInfo = DBUtil.GetDbConnectionInfo(
                ConfigUtil.Get("SystemKbn"), syokuin.TodofukenCd, syokuin.KumiaitoCd, syokuin.ShishoCd);

            using (var db = new NskAppContext(dbConnectionInfo.ConnectionString, dbConnectionInfo.DefaultSchema))
            {
                try
                {
                    // 農業者IDから情報を取得
                    var nogyoshaInfo = db.VNogyoshas
                                        .Where(x => x.NogyoshaId.ToString() == テスト農業者ID)
                                        .FirstOrDefault();

                    if (nogyoshaInfo != null)
                    {
                        // 組合員等コード
                        model.KumiaiintoCd = nogyoshaInfo.KumiaiintoCd;

                        // 組合等コード
                        model.KumiaitoCd = nogyoshaInfo.KumiaitoCd;

                        // 氏名
                        model.HojinFullNm = nogyoshaInfo.HojinFullNm;

                        // 支所
                        var shishoNm = ShishoUtil.GetShishoNm(
                            nogyoshaInfo.TodofukenCd,
                            nogyoshaInfo.KumiaitoCd,
                            nogyoshaInfo.ShishoCd
                        );

                        model.ShishoCd = nogyoshaInfo.ShishoCd;
                        model.ShishoNm = shishoNm;

                        //市町村
                        var shichosonNm = ShichosonUtil.GetShichosonNm(
                            nogyoshaInfo.TodofukenCd,
                            nogyoshaInfo.KumiaitoCd,
                            nogyoshaInfo.ShichosonCd
                        );

                        model.ShichosonCd = nogyoshaInfo.ShichosonCd;
                        model.ShichosonNm = shichosonNm;

                        //大地区
                        var daichikuNm = DaichikuUtil.GetDaichikuNm(
                            nogyoshaInfo.TodofukenCd,
                            nogyoshaInfo.KumiaitoCd,
                            nogyoshaInfo.DaichikuCd
                        );

                        model.DaichikuCd = nogyoshaInfo.DaichikuCd;
                        model.DaichikuNm = daichikuNm;

                        //小地区
                        var ShochikuNm = ShochikuUtil.GetShochikuNm(
                            nogyoshaInfo.TodofukenCd,
                            nogyoshaInfo.KumiaitoCd,
                            nogyoshaInfo.DaichikuCd,
                            nogyoshaInfo.ShochikuCd
                        );

                        model.ShochikuCd = nogyoshaInfo.ShochikuCd;
                        model.ShochikuNm = ShochikuNm;

                        // 用途区分から用途短縮名称を取得
                        model.YotoCd = テスト用途区分;

                        var yotoNm = getJigyoDb<NskAppContext>().M10110用途区分名称s
                                        .Where(t => t.共済目的コード == md.SKyosaiMokutekiCd && t.用途区分.Trim() == model.YotoCd.Trim())
                                        .Select(t => t.用途短縮名称)
                                        .FirstOrDefault();

                        model.YotoKbn = yotoNm;

                        // 類区分から類短縮名称を取得
                        model.RuiKbn = テスト類区分;
                        var ruiName = getJigyoDb<NskAppContext>().M00020類名称s
                                        .Where(t => t.共済目的コード == md.SKyosaiMokutekiCd && t.類区分 == model.RuiKbn)
                                        .Select(t => t.類短縮名称)
                                        .Single();

                        model.RuiNm = ruiName;

                        var result = GetShisetsuHannyuSyukakuryoKekka(db, model);
                        if (result != null)
                        {
                            model.ShisetsuHannyuSyukakuryoKekka = result.Value.ShisetsuValue?.ToString("0");
                            model.Xmin = result.Value.Xmin;
                        }
                    }
                }
                catch (Exception ex)
                {
                    logger.Debug(ex.StackTrace);
                    throw new AppException("MF80002", MessageUtil.Get("MF80002", "対象データ"));
                }
            }

            try
            {
                var kyosai = getJigyoDb<NskAppContext>().M00010共済目的名称s
                              .Where(t => t.共済目的コード == md.SKyosaiMokutekiCd)
                              .Single();

                model.KyosaiMokutekiMeisho = kyosai.共済目的名称;
            }
            catch (Exception ex)
            {
                logger.Debug(ex.StackTrace);
                throw new AppException("MF80002", MessageUtil.Get("MF80002", "共済目的"));
            }

            // 初期表示情報をセッションに保存する
            SessionUtil.Set(SESS_D204111, model, HttpContext);
            return View(SCREEN_ID_D204111, model);
        }

        #region 登録メソッド
        /// <summary>
        /// 登録イベント
        /// </summary>
        /// <param name="model">ビューモデル</param>
        /// <returns>結果メッセージ</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(D204111Model model)
        {
            //属性チェック
            var resultMessage = string.Empty;
            // ※ セッションからユーザ情報などを取得（例）
            var syokuin = SessionUtil.Get<Syokuin>(CoreConst.SESS_LOGIN_USER, HttpContext);

            // DB 接続情報（各環境に合わせる）
            var dbConnectionInfo = DBUtil.GetDbConnectionInfo(
                ConfigUtil.Get("SystemKbn"), syokuin.TodofukenCd, syokuin.KumiaitoCd, syokuin.ShishoCd);

            using (var db = new NskAppContext(dbConnectionInfo.ConnectionString, dbConnectionInfo.DefaultSchema))
            {
                var transaction = db.Database.BeginTransaction();
                try
                {
                    // 未入力チェック
                    if (string.IsNullOrWhiteSpace(model.ShisetsuHannyuSyukakuryoKekka))
                    {
                        var errorMsg = MessageUtil.Get("ME00001", "施設搬入収穫量結果", "");
                        ModelState.AddModelError(nameof(model.ShisetsuHannyuSyukakuryoKekka), errorMsg);
                        return Json(new { message = errorMsg });
                    }

                    // 対象レコードを検索（複合キーで検索）
                    var record = db.T21120施設搬入収穫量s
                        .Where(r => r.組合等コード == model.KumiaitoCd &&
                                    r.年産 == short.Parse(model.Nensan) &&
                                    r.共済目的コード == model.KyosaiMokutekiCd &&
                                    r.類区分 == model.RuiKbn &&
                                    r.用途区分 == model.YotoCd &&
                                    r.組合員等コード == model.KumiaiintoCd)
                        .SingleOrDefault();

                    if (record != null)
                    {
                        // xmin チェック
                        if ((uint)record.Xmin != model.Xmin)
                        {
                            transaction.Rollback();
                            resultMessage = MessageUtil.Get("ME10082"); // 排他エラー
                            return Json(new { message = resultMessage });
                        }
                        // 更新
                        record.直接施設搬入収穫量 = decimal.Parse(model.ShisetsuHannyuSyukakuryoKekka);
                        record.更新日時 = DateTime.Now;
                        record.更新ユーザid = syokuin.UserId;
                        db.Update(record);
                    }
                    else
                    {
                        // 新規追加
                        var newRecord = new T21120施設搬入収穫量
                        {
                            組合等コード = model.KumiaitoCd,
                            年産 = short.Parse(model.Nensan),
                            共済目的コード = model.KyosaiMokutekiCd,
                            類区分 = model.RuiKbn,
                            用途区分 = model.YotoCd,
                            組合員等コード = model.KumiaiintoCd,
                            直接施設搬入収穫量 = decimal.Parse(model.ShisetsuHannyuSyukakuryoKekka),
                            登録日時 = DateTime.Now,
                            登録ユーザid = syokuin.UserId
                        };
                        db.Add(newRecord);
                    }

                    // SaveChanges() の結果（影響を受けた行数）を取得
                    int affectedRows = db.SaveChanges();
                    if (affectedRows == 0)
                    {
                        // 更新や挿入が 0 件の場合
                        transaction.Rollback();
                        resultMessage = MessageUtil.Get("ME01645", "更新");
                        return Json(new { message = resultMessage });
                    }
                    transaction.Commit();
                }
                catch (DbUpdateConcurrencyException e)
                {
                    logger.Error(e.StackTrace);
                    transaction.Rollback();
                    resultMessage = MessageUtil.Get("ME10082");
                    return Json(new { message = resultMessage });
                }
                catch (Exception e)
                {
                    logger.Error(e.StackTrace);
                    transaction.Rollback();
                    resultMessage = MessageUtil.Get("ME01645", "更新");
                    return Json(new { message = resultMessage });
                }
            }

            resultMessage = MessageUtil.Get("MI10005");

            return Json(new { message = resultMessage });
        }
        #endregion

        #region 削除メソッド
        /// <summary>
        /// 削除イベント
        /// </summary>
        /// <param name="model">ビューモデル</param>
        /// <returns>結果メッセージ</returns>
        [HttpPost]
        public ActionResult Delete(D204111Model model)
        {
            var resultMessage = string.Empty;
            // ※ セッションからユーザ情報などを取得（例）
            var syokuin = SessionUtil.Get<Syokuin>(CoreConst.SESS_LOGIN_USER, HttpContext);

            // DB 接続情報（各環境に合わせる）
            var dbConnectionInfo = DBUtil.GetDbConnectionInfo(
                ConfigUtil.Get("SystemKbn"), syokuin.TodofukenCd, syokuin.KumiaitoCd, syokuin.ShishoCd);

            using (var db = new NskAppContext(dbConnectionInfo.ConnectionString, dbConnectionInfo.DefaultSchema))
            {
                var transaction = db.Database.BeginTransaction();
                try
                {
                    // 対象レコードを検索（複合キーで検索）
                    var record = db.T21120施設搬入収穫量s
                        .Where(r => r.組合等コード == model.KumiaitoCd &&
                                    r.年産 == short.Parse(model.Nensan) &&
                                    r.共済目的コード == model.KyosaiMokutekiCd &&
                                    r.類区分 == model.RuiKbn &&
                                    r.用途区分 == model.YotoCd &&
                                    r.組合員等コード == model.KumiaiintoCd)
                        .SingleOrDefault();

                    if (record == null)
                    {
                        // 該当レコードが存在しない場合
                        transaction.Rollback();
                        resultMessage = MessageUtil.Get("ME01645", "削除");
                        return Json(new { message = resultMessage });
                    }
                    // xmin チェック
                    var deleteTargetVersion = GetShisetsuHannyuSyukakuryoKekka(db, model);
                    if (deleteTargetVersion == null || deleteTargetVersion.Value.Xmin != model.Xmin)
                    {
                        transaction.Rollback();
                        resultMessage = MessageUtil.Get("ME10082"); // 排他エラー
                        return Json(new { message = resultMessage });
                    }
                    // レコードの削除
                    db.Remove(record);

                    // SaveChanges() の結果（影響を受けた行数）を確認
                    int affectedRows = db.SaveChanges();
                    if (affectedRows == 0)
                    {
                        transaction.Rollback();
                        resultMessage = MessageUtil.Get("ME01645", "削除");
                        return Json(new { message = resultMessage });
                    }

                    transaction.Commit();
                }
                catch (Exception e)
                {
                    logger.Error(e.StackTrace);
                    transaction.Rollback();
                    resultMessage = MessageUtil.Get("ME01645", "削除");
                    return Json(new { message = resultMessage });
                }
            }

            resultMessage = MessageUtil.Get("MI00004", "削除");

            return Json(new { message = resultMessage });
        }
        #endregion


        #region 戻るイベント
        /// <summary>
        /// イベント名：戻る 
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpGet]
        public ActionResult Back()
        {
            // セッション情報から検索条件、検索結果件数をクリアする
            SessionUtil.Remove(SESS_D204111, HttpContext);

            return Json(new { result = "success" });
        }
        #endregion

        /// <summary>
        /// 初期モデルの取得メソッド。
        /// </summary>
        /// <returns>初期モデル</returns>
        private D000999Model GetInitModel()
        {
            D000999Model model = new D000999Model();

            List<MTodofuken> todofukenList = TodofukenUtil.GetTodofukenList().ToList();
            if (todofukenList.Count() > 0)
            {
                model.TodofukenCd = todofukenList[0].TodofukenCd;
                model.TodofukenNm = todofukenList[0].TodofukenNm;
                List<MKumiaito> kumiaitoList = KumiaitoUtil.GetKumiaitoList(model.TodofukenCd);
                if (kumiaitoList.Count() > 0)
                {
                    model.KumiaitoCd = kumiaitoList[0].KumiaitoCd;
                    model.KumiaitoNm = kumiaitoList[0].KumiaitoNm;
                    List<MShishoNm> shishoList = ShishoUtil.GetShishoList(model.TodofukenCd, model.KumiaitoCd);
                    if (shishoList.Count() > 0)
                    {
                        model.ShishoCd = shishoList[0].ShishoCd;
                        model.ShishoNm = shishoList[0].ShishoNm;
                    }
                }
            }

            model.ScreenMode = "1";

            return model;
        }

        /// <summary>
        /// T21120施設搬入収穫量テーブルから、
        /// 「直接施設搬入収穫量」および「xmin（内部バージョン）」を取得するためのDTOクラス。
        /// ※ Entity Framework の FromSqlRaw() で使用する目的専用のクラス。
        /// </summary>
        public class T21120ResultDto
        {
            /// <summary>
            /// 直接施設搬入収穫量（numeric 型 → decimal に対応）
            /// </summary>
            public decimal? Shisetsu { get; set; }

            /// <summary>
            /// PostgreSQL のシステムカラム「xmin」
            /// ※ 楽観的同時実行制御に使用される内部バージョン番号
            /// </summary>
            public int Xmin { get; set; }
        }


        /// <summary>
        /// 施設搬入収穫量結果と xmin を取得する
        /// </summary>
        private (decimal? ShisetsuValue, uint Xmin)? GetShisetsuHannyuSyukakuryoKekka(NskAppContext db, D204111Model model)
        {
            if (string.IsNullOrWhiteSpace(model.KumiaitoCd) ||
                string.IsNullOrWhiteSpace(model.Nensan) ||
                string.IsNullOrWhiteSpace(model.KyosaiMokutekiCd) ||
                string.IsNullOrWhiteSpace(model.RuiKbn) ||
                string.IsNullOrWhiteSpace(model.YotoCd) ||
                string.IsNullOrWhiteSpace(model.KumiaiintoCd))
            {
                return null;
            }

            string sql = @"
                SELECT 
                    ""直接施設搬入収穫量"",
                    xmin
                FROM ""t_21120_施設搬入収穫量""
                WHERE ""組合等コード"" = @p0
                  AND ""年産"" = @p1
                  AND ""共済目的コード"" = @p2
                  AND ""類区分"" = @p3
                  AND ""用途区分"" = @p4
                  AND ""組合員等コード"" = @p5
                LIMIT 1";

            using (var command = db.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = sql;
                command.CommandType = System.Data.CommandType.Text;

                // パラメータ追加
                var parameters = new object[]
                {
                    model.KumiaitoCd,
                    short.Parse(model.Nensan),
                    model.KyosaiMokutekiCd,
                    model.RuiKbn,
                    model.YotoCd,
                    model.KumiaiintoCd
                };

                for (int i = 0; i < parameters.Length; i++)
                {
                    var param = command.CreateParameter();
                    param.ParameterName = $"@p{i}";
                    param.Value = parameters[i];
                    command.Parameters.Add(param);
                }

                if (command.Connection.State != System.Data.ConnectionState.Open)
                {
                    command.Connection.Open();
                }

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        decimal? shisetsu = reader.IsDBNull(0) ? (decimal?)null : reader.GetDecimal(0);
                        uint xmin = Convert.ToUInt32(reader.GetFieldValue<uint>(1)); 

                        return (shisetsu, xmin);
                    }
                }
            }

            return null;
        }
    }
}