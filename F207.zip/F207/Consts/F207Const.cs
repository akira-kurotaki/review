namespace NskWeb.Areas.F207.Consts
{
    /// <summary>
    /// F207機能共通定数クラス
    /// </summary>
    public class F207Const
    {
        // D207020

        /// <summary>
        /// 画面ID(D207020)
        /// </summary>
        public const string SCREEN_ID_D207020 = "D207020";

        /// <summary>
        /// セッションキー(D207020)
        /// </summary>
        public const string SESS_D207020 = "D207020_SCREEN";

        /// <summary>
        /// 予約を実行した処理名(207020D)
        /// </summary>
        public const string SCREEN_ID_NSK_D207020 = "NSK_207020D";

        /// <summary>
        /// バッチID(207021B)
        /// </summary>
        public const string BATCH_ID_NSK_207021B = "NSK_207021B";


        // D207030

        /// <summary>
        /// 画面ID(D207030)
        /// </summary>
        public const string SCREEN_ID_D207030 = "D207030";

        /// <summary>
        /// セッションキー(D207030)
        /// </summary>
        public const string SESS_D207030 = "D207030_SCREEN";

        /// <summary>
        /// 予約を実行した処理名(207023D)
        /// </summary>
        public const string SCREEN_ID_NSK_D207030 = "NSK_207030D";

        /// <summary>
        /// バッチID(207031B)
        /// </summary>
        public const string BATCH_ID_NSK_207031B = "NSK_207031B";
    }
}
